// Manual icon movement is independent of building footprints and work areas.
// Keep the public signature for older clients; only photo bounds constrain the point.
export function limitWorkMove(task,point,regions,frame){return point.map(value=>Math.max(0,Math.min(1,value)));}
