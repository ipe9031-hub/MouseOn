// Stable review tokens track source content and physical geometry, independently of icon spacing.
export function warningVersion(pair,tasks,regions=[]){
 const ids=new Set(pair.taskIds),related=tasks.filter(t=>ids.has(t.id)).sort((a,b)=>a.id.localeCompare(b.id)),regionIds=new Set(related.map(t=>t.workRegionId||t.regionId).filter(Boolean));
 const payload=JSON.stringify([related.map(t=>[t.id,t.sourceEventKey||t.sourceKey,t.date,t.original||t.title,t.detail,t.icon,t.equipment,t.workArea,t.workAnchor,t.workRegionId||t.regionId,t.placement,t.shape,t.points,t.positionCleared,(!t.workArea&&!t.regionId&&!t.workRegionId)?[t.x,t.y]:null]),regions.filter(r=>regionIds.has(r.id)).sort((a,b)=>a.id.localeCompare(b.id)).map(r=>[r.id,r.points,r.pieces])]);
 let a=2166136261,b=2246822519;for(let i=0;i<payload.length;i++){const c=payload.charCodeAt(i);a=Math.imul(a^c,16777619);b=Math.imul(b^c,3266489917);}return (a>>>0).toString(16).padStart(8,'0')+(b>>>0).toString(16).padStart(8,'0');
}
export function warningHidden(room,pair,regions){const version=warningVersion(pair,room.tasks,regions);return (room.warningDismissals||[]).some(d=>d.key===pair.id&&d.version===version);}
export function clearTaskPosition(task){Object.assign(task,{positionCleared:true,requiresPositionConfirmation:true,manuallyPlaced:false,x:null,y:null,regionId:null,shape:'point',points:[],extras:[]});delete task.workRegionId;delete task.workAnchor;delete task.workArea;task.reasons=[...(task.reasons||[]).filter(s=>!s.includes('위치 확인 필요')),'위치 지정 해제 · 위치 확인 필요'];return task;}
