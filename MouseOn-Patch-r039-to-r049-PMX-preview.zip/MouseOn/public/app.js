import {setupPmxUI} from '/pmx-ui.js';
import {warningVersion,warningHidden} from '/review-state.js';
import {limitWorkMove} from '/work-area.js';
import {arrangeTaskMarkers} from '/marker-layout.js';
import {photoFrame,zoomScrubber,editorPhotoView} from '/photo-view.js';
import {photoThumbnail,arrangePhotoCards} from '/photos.js';
import {regionPieces,regionRings,regionPath,regionArea,mapRegionRings,withPieces} from '/region-geometry.js';
import {defaultHazards,hazardColors} from '/hazards.js';
import {defaultOutline,validateOutline,addSiteRegion,partitionSite,withinOutline,constrainToOutline,insertManualRegion,snapToOutline,reshapeSiteRegion,snapRegionEditPoint,addRegionPointAt,outlineInputAllowed,latchRegionPoint,latchRegionTranslation,translateSiteRegion} from '/site-partition.js';
import {conformRegions,validMesh,meshProblem,moveSharedNodes,insertSharedPoint,removeSharedPoint,mergeDeletedRegion,nodeKey} from '/region-mesh.js';
import {tiledRegions,boundsOf,transformRegion} from '/region-layout.js';
import {kindInfo,regionPoint,classifyWork,isPumpConcrete,hasConcreteRoute,verticalConflictPairs,safetyTasksForDates,insideRegion} from '/interpret.js';
import {equipmentIcon,isTower,iconType,workTileStyle} from '/icons.js';
import {schedule,validDate,stepWorkday} from '/calendar.js';
const $ = id => document.getElementById(id);
let bulkDeleting=false;const bulkSelected=new Set();
let photoMove=null,photoHold=null;
let myInkOwner='';let workAreaEdit=null,pendingPlacementId=null,suppressPlacementClick=false;
let room, socket, mode='pan', zoom=1, joined=false, retry, toastTimer;
let activeRegionBoxId=null;let pumpRouteTaskId=null,pumpRoutePoints=[];let rectangleGesture=null;
let regionTransforming=false,regionTransformSnapshot=null,regionTransformGesture=null;
let penWidth=Math.max(1,Math.min(16,Number(sessionStorage.getItem('mouseon-pen-width'))||5));
let keptGeometry=[];
const viewHistory=[];let areaGesture=null,lastWheelTime=0;
let panX=0,panY=0,fitMode='cover',myColor='#d45743',myName='',site={version:1,revision:0,name:'우리 현장',regions:[]},siteDraft=null,regionPicking=false,regionEditId=null;
let selectedDates=schedule().dates, activeId=null,pinnedId=null,picking=false,draft=[];
const ctx=$('ink').getContext('2d');
const roomId=new URLSearchParams(location.search).get('room');
const inkTab=sessionStorage.getItem('mouseon-ink-tab')||Array.from(crypto.getRandomValues(new Uint8Array(16)),v=>v.toString(16).padStart(2,'0')).join('');sessionStorage.setItem('mouseon-ink-tab',inkTab);
if(roomId) { $('enter').textContent='회의 참여 →'; $('welcome').querySelector('h2').textContent='진행 중인 회의에 참여하세요'; }
let hostSetup=false;
const fragment=new URLSearchParams(location.hash.slice(1));
if(fragment.has('host')){sessionStorage.setItem('mouseon-host',fragment.get('host'));history.replaceState(null,'',location.pathname+location.search);}
const hostHeaders={'X-Mouseon-Host':sessionStorage.getItem('mouseon-host')||''};
const roomQuery=()=>'?room='+encodeURIComponent(new URLSearchParams(location.search).get('room')||'');
let passwordRequired=false,canClearInk=false;
const accessReady=fetch('/api/access'+roomQuery(),{headers:hostHeaders}).then(r=>{if(!r.ok)throw Error('접속 상태를 확인하지 못했습니다.');return r.json();}).then(state=>{
 hostSetup=state.hostSetup;canClearInk=Boolean(state.canClearInk);$('siteSettingsButton').hidden=state.hostSetup&&!canClearInk;updatePenTools();
 $('passwordLabel').textContent=hostSetup&&!roomId?'회의 비밀번호 지정 (4자 이상)':'회의 비밀번호';
 passwordRequired=state.passwordRequired&&!state.authenticated;
 $('passwordField').hidden=!passwordRequired;$('password').required=passwordRequired;
}).catch(error=>{toast(error.message);});
$('name').value=sessionStorage.getItem('mouseon-name')||'';
function toast(text){$('toast').textContent=text;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),3500);}
function send(m){if(socket?.readyState===WebSocket.OPEN){socket.send(JSON.stringify(m));return true;}toast('연결을 확인하고 다시 시도해주세요.');return false;}
function connected(ok,text){$('led').classList.toggle('on',ok);$('status').textContent=text;}
$('entry').onsubmit=async e=>{e.preventDefault();$('enter').disabled=true;try{
  const name=$('name').value.trim();if(!name)throw Error('이름을 입력해주세요.');sessionStorage.setItem('mouseon-name',name);
  await accessReady;
  if(passwordRequired && !(hostSetup&&!new URLSearchParams(location.search).get('room'))){
    const login=await fetch('/api/login'+roomQuery(),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('password').value})});
    const result=await login.json();if(!login.ok)throw Error(result.error||'로그인하지 못했습니다.');
    passwordRequired=false;$('password').value='';$('password').required=false;$('passwordField').hidden=true;
  }
  let id=new URLSearchParams(location.search).get('room');
  if(!id){const res=await fetch('/api/rooms',{method:'POST',headers:{...hostHeaders,'Content-Type':'application/json'},body:JSON.stringify({password:$('password').value})});if(!res.ok){const error=await res.json();throw Error(error.error||'회의를 만들지 못했습니다.');}id=(await res.json()).id;history.replaceState(null,'','?room='+id);}
  $('password').value='';passwordRequired=false;
  connect(id,name);
}catch(err){toast(err.message);$('enter').disabled=false;}};
function connect(id,name){
  clearTimeout(retry);connected(false,'연결 중');
  socket=new WebSocket(`${location.protocol==='https:'?'wss:':'ws:'}//${location.host}/?room=${encodeURIComponent(id)}&name=${encodeURIComponent(name)}&ink=${encodeURIComponent(inkTab)}`);
  socket.onopen=()=>{connected(true,'실시간 연결됨');};
  socket.onmessage=event=>{const m=JSON.parse(event.data);
    if(m.type==='state'){
      if(m.identity){myColor=m.identity.color;myName=m.identity.person;myInkOwner=m.identity.inkOwner||'';}
      if(room&&room.image!==m.room.image){stopActiveTool('image');viewGesture=null;touchPoints.clear();pinch=null;pinchBlocking=false;}
      room=m.room;document.body.classList.add('in-meeting');if(!joined){joined=true;$('welcome').hidden=true;$('workspace').hidden=false;$('share').disabled=false;syncMobileFrame();$('toolRail').hidden=true;$('menuToggle').setAttribute('aria-expanded','false');}
      render();setZoom();if(!siteDraft)loadSite();if(m.notice)toast(m.notice);
    } else if(m.type==='site'){site=m.site;siteDraft=structuredClone(site);renderSite();toast('현장 설정이 갱신되었습니다.');}
    else if(m.type==='stroke' && m.image===room.image){room.strokes.push(m.stroke);paint(m.stroke);updatePenTools();}
    else if(m.type==='notice')toast(m.message);
    else if(m.type==='presence')$('presence').textContent=`· ${m.count}명 참여`;
    else if(m.type==='error')toast(m.message);
  };
  socket.onclose=e=>{connected(false,'연결 끊김');$('enter').disabled=false;
    if(e.code===1008){toast(e.reason||'참여할 수 없습니다. 주소와 비밀번호를 확인해주세요.');joined=false;$('welcome').hidden=false;$('workspace').hidden=true;$('share').disabled=true;passwordRequired=true;$('passwordField').hidden=false;$('password').required=true;return;}
    toast('연결이 끊겼습니다. 다시 연결 중입니다.');retry=setTimeout(()=>connect(id,name),1800);
  };
  socket.onerror=()=>connected(false,'서버 연결 확인 중');
}
function el(tag,cls,text){const node=document.createElement(tag);if(cls)node.className=cls;if(text!==undefined)node.textContent=text;return node;}
function isTop(){return room.image===room.topImage;}
function render(){if(photoMove&&(!isTop()||!room.photos?.some(p=>p.id===photoMove.id)))cancelPhotoMove();
 if(bulkDeleting&&!isTop())endBulkDelete();if(mode==='move'&&!isTop())selectMode('pan');
 for(const id of bulkSelected)if(!room.tasks.some(t=>t.id===id&&selectedDates.includes(t.date)))bulkSelected.delete(id);
 if(workAreaEdit&&(!isTop()||!room.tasks.some(t=>t.id===workAreaEdit.id)))cancelWorkArea();
 if(pumpRouteTaskId&&(!isTop()||!room.tasks.some(t=>t.id===pumpRouteTaskId)))cancelPumpRoute();
 $('canvasActionMenu').hidden=true;
  const image=room.image||'/sample.svg';if($('background').getAttribute('src')!==image){$('background').src=image;zoom=1;panX=0;panY=0;viewHistory.length=0;updateViewButtons();setZoom();}
  $('viewTitle').textContent=isTop()?'현장 탑뷰':'상세 사진';$('imageNote').textContent=room.image?(isTop()?'업로드한 현장 탑뷰':'공유 중인 상세 사진'):'샘플 배치도';
  $('back').disabled=isTop();$('returnTop').hidden=isTop();$('tasks').replaceChildren();$('routeLayer').replaceChildren();$('sequence').replaceChildren();$('taskCount').textContent=room.tasks.length;
  const visibleTasks=room.tasks.filter(t=>selectedDates.includes(t.date||schedule().dates[0])).map(t=>t.sourceKey?{...t,...classifyWork(t.original||[t.title,t.detail].join(' '),t.calendar,site.hazards||[])}:t);
  renderPending();
  updateTitle();
  renderVerticalWarnings(safetyTasksForDates(room.tasks,selectedDates));
  const groups=Map.groupBy(visibleTasks,t=>t.equipment);
  for(const [equipment,tasks] of groups){
    const group=el('section','equipment');group.append(el('h3','',equipment));
    tasks.forEach((task,i)=>{
      const row=el('div','task-row');
      const info=el('div','task-info');const label=el('b','');label.append(equipmentIcon(task),document.createTextNode(task.title));info.append(label,el('small','',task.detail));row.append(info);
      const controls=el('div','order-buttons');
      for(const [d,label] of [[-1,'↑'],[1,'↓']]){const button=el('button','',label);button.setAttribute('aria-label',task.title+(d===-1?' 순서 올리기':' 순서 내리기'));button.disabled=d===-1?i===0:i===tasks.length-1;button.onclick=()=>send({type:'reorder',id:task.id,direction:d,revision:room.revision});if(!isTower(task))controls.append(button);}
      const remove=el('button','delete-task','삭제');remove.setAttribute('aria-label',task.title+' 삭제');remove.onclick=()=>deleteTask(task);controls.append(remove);row.append(controls);group.append(row);
      if(isTop()&&Number.isFinite(task.x)&&Number.isFinite(task.y)){
        const marker=el('button','marker');marker.classList.toggle('risk-high',task.riskLevel==='high'||Boolean(task.hazardId));marker.dataset.id=task.id;marker.dataset.kind=iconType(task);const tile=workTileStyle(task);marker.style.setProperty('--tile-background',tile.background);marker.style.setProperty('--tile-foreground',tile.foreground);if(task.hazardId)marker.dataset.customHazard='1';marker.style.left=(task.displayPoint?.[0]??task.x)*100+'%';marker.style.top=(task.displayPoint?.[1]??task.y)*100+'%';if(task.shape==='area'&&task.points?.length){const xs=task.points.map(p=>p[0]),ys=task.points.map(p=>p[1]);marker.classList.add('area-marker');marker.style.width='min(220px, '+Math.max(5,(Math.max(...xs)-Math.min(...xs))*80)+'%)';}marker.setAttribute('aria-label',`${task.title} 위치`);
        const icon=el('span','marker-icon');icon.append(equipmentIcon(task));marker.append(icon);marker.append(el('span','marker-label',task.title));
        marker.querySelector('.marker-label').textContent=cleanTaskTitle(task.title);
        if(task.riskLevel&&(task.sourceKey||task.riskLevel==='high')){const meta=el('small','work-risk-label'+(task.riskLevel==='high'?' high':''),task.riskLevel==='high'?'고위험 작업':'일반 작업');marker.querySelector('.marker-label').append(meta);}
        if(task.equipmentHint)marker.querySelector('.marker-label').append(el('small','equipment-hint',task.equipmentHint));
        if(task.shape==='area'&&task.detail)marker.append(el('span','area-detail',task.detail));const color=task.hazardColor||kindInfo[iconType(task)]?.[1]||kindInfo.other[1];marker.style.setProperty('--task-color',color);
        if(task.reasons?.length)marker.querySelector('.marker-label').append(el('small','work-notes',task.reasons.filter(reason=>!reason.startsWith('고위험 작업의')).join(' · ')));

        pmxUI.decorate(marker,task);
        marker.onpointerenter=()=>{if(mobileView())return;activeId=task.id;reveal();};marker.onpointerleave=()=>{activeId=null;reveal();};
        marker.onfocus=()=>{if(mobileView())return;activeId=task.id;reveal();};marker.onblur=()=>{activeId=null;reveal();};
        marker.onpointerdown=e=>{if(bulkDeleting){e.stopPropagation();return;}if(!mobileView()||mode!=='pan'||picking||regionPicking||regionTransforming)return;e.preventDefault();e.stopPropagation();gesture={type:'move',id:task.id,marker,startX:e.clientX,startY:e.clientY,original:[task.x,task.y],originalStyle:{left:marker.style.left,top:marker.style.top},ready:false,mobileHold:true};const current=gesture;current.timer=setTimeout(()=>{if(gesture!==current)return;current.ready=true;marker.dataset.skipClickUntil=String(performance.now()+1000);marker.classList.add('moving');navigator.vibrate?.(25);},1500);marker.setPointerCapture(e.pointerId);};
        marker.onclick=e=>{if(bulkDeleting){e.stopPropagation();bulkSelected.has(task.id)?bulkSelected.delete(task.id):bulkSelected.add(task.id);updateBulkDelete();return;}if(suppressPlacementClick){suppressPlacementClick=false;return;}if(Number(marker.dataset.skipClickUntil||0)>performance.now())return;if(mode!=='move'){if(pinnedId!==task.id)resetFloatingPosition($('taskActions'));pinnedId=pinnedId===task.id?null:task.id;reveal();if(pinnedId&&!mobileView()){const r=marker.getBoundingClientRect();placeNear($('taskActions'),r.x+r.width/2,r.y+r.height/2,300);}}};$('tasks').append(marker);
        [{shape:task.shape,points:task.points},...(task.workArea?.length?[{shape:'area',purpose:'work-area',points:task.workArea}]:[]),...(task.extras||[])].forEach((geometry,index)=>appendTaskGeometry(task,geometry,index));
      }
    });$('sequence').append(group);
  }
  reveal();drawSiteRegions();renderPhotos();updateBulkDelete();requestAnimationFrame(layoutTaskMarkers);
  $('inkAuthor').hidden=true;
  resizeInk();updatePenTools();pmxUI.render();
}
function resizeInk(){const rect=$('scene').getBoundingClientRect();const canvas=$('ink');const scale=Math.min(devicePixelRatio,4096/Math.max(1,rect.width),4096/Math.max(1,rect.height));const w=Math.max(1,Math.round(rect.width*scale)),h=Math.max(1,Math.round(rect.height*scale));if(canvas.width!==w)canvas.width=w;if(canvas.height!==h)canvas.height=h;ctx.clearRect(0,0,w,h);if(room)room.strokes.forEach(paint);}
function paint(stroke){const c=$('ink');ctx.strokeStyle=stroke.color;ctx.lineWidth=(stroke.width||3)*c.width/Math.max(1,$('scene').getBoundingClientRect().width);ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();stroke.points.forEach(([x,y],i)=>i?ctx.lineTo(x*c.width,y*c.height):ctx.moveTo(x*c.width,y*c.height));ctx.stroke();}
$('background').onload=()=>{const img=$('background');$('scene').style.aspectRatio=`${img.naturalWidth} / ${img.naturalHeight}`;setZoom();resizeInk();};
new ResizeObserver(resizeInk).observe($('scene'));
function point(e){const r=$('scene').getBoundingClientRect();return [Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),Math.max(0,Math.min(1,(e.clientY-r.top)/r.height))];}
function rawPhotoPoint(e,element){const r=element.getBoundingClientRect();return [(e.clientX-r.x)/Math.max(1,r.width),(e.clientY-r.y)/Math.max(1,r.height)];}
function mainInputAllowed(e){return Boolean(e.target.closest('.marker'))||mode==='draw'&&!picking&&!regionPicking||mode==='move'||gesture?.type==='move'||siteInputAllowed(e);}
function siteInputAllowed(e){return !room||!isTop()||outlineInputAllowed(site.outline,rawPhotoPoint(e,$('scene')),$('scene').getBoundingClientRect());}
function editorInputAllowed(e){return wizardStep===1||outlineInputAllowed(wizardOutline,rawPhotoPoint(e,wizardSvg),wizardSvg.getBoundingClientRect());}

let gesture=null,lastSent=0;
$('scene').onpointerdown=e=>{if(photoMove)return;
  if(bulkDeleting)return;
  if(e.target.closest('.photo-pin,.vertical-warning'))return;
  if(workAreaEdit||pumpRouteTaskId||regionTransforming)return;
  if(regionPicking){draft.push(point(e));renderSiteDraft();return;}
  if(picking){if(mobileView()&&$('taskShape').value==='area')return;const p=point(e);draft.push(p);renderDraft();showPlacementActions(e);return;}
  if(mode==='pan')return;
  if(!e.target.closest('.marker')){pinnedId=null;activeId=null;reveal();}
  if(!room||socket?.readyState!==WebSocket.OPEN)return;
  const marker=e.target.closest('.marker'), p=point(e);
  if(mode==='move'&&marker){
    e.preventDefault();const task=room.tasks.find(t=>t.id===marker.dataset.id);
    gesture={type:'move',id:task.id,marker,startX:e.clientX,startY:e.clientY,original:[task.x,task.y],originalStyle:{left:marker.style.left,top:marker.style.top},ready:e.pointerType!=='touch'};
    if(!gesture.ready)gesture.timer=setTimeout(()=>{if(gesture){gesture.ready=true;navigator.vibrate?.(25);}},1500);
  }else if(mode==='draw'){e.preventDefault();gesture={type:'draw',image:room.image,origin:p,hadInk:Boolean(room.strokes.length),moved:false,last:p,width:penWidth,id:crypto.randomUUID()};}
  if(gesture){$('scene').setPointerCapture(e.pointerId);updatePenTools();}
};
$('scene').onpointermove=e=>{
  hoverInkAuthor(e);
  if(!room||picking||regionPicking)return;const p=point(e), now=performance.now();
  if(gesture?.type==='move'){
    if(!gesture.ready){if(Math.hypot(e.clientX-gesture.startX,e.clientY-gesture.startY)>12){clearTimeout(gesture.timer);if(gesture.mobileHold)gesture.marker.dataset.skipClickUntil=String(performance.now()+600);Object.assign(gesture.marker.style,gesture.originalStyle);gesture=null;}return;}
    const q=limitWorkMove(room.tasks.find(t=>t.id===gesture.id),p,site.regions,$('scene').getBoundingClientRect());gesture.marker.style.left=q[0]*100+'%';gesture.marker.style.top=q[1]*100+'%';return;
  }
  if(gesture?.type==='draw'&&gesture.image!==room.image){gesture=null;return;}
  if(gesture?.type==='draw'){const box=$('scene').getBoundingClientRect();if(Math.hypot((p[0]-gesture.origin[0])*box.width,(p[1]-gesture.origin[1])*box.height)>4)gesture.moved=true;}
  if(now-lastSent<25)return;lastSent=now;
  if(gesture?.type==='draw'){if(!gesture.last){gesture.last=p;return;}if(!gesture.moved)return;const stroke={points:[gesture.last,p],color:myColor,person:myName,owner:myInkOwner,width:gesture?.width||penWidth};if(send({type:'stroke',points:stroke.points,image:room.image,width:stroke.width,id:gesture.id})){room.strokes.push(stroke);paint(stroke);updatePenTools();}gesture.last=p;}
};
function finish(e,cancel=false){if(!gesture)return;clearTimeout(gesture.timer);const g=gesture;gesture=null;updatePenTools();
 if(g.type==='move'){g.marker.classList.remove('moving');if(g.mobileHold&&g.ready)g.marker.dataset.skipClickUntil=String(performance.now()+600);if(!cancel&&g.ready){const box=$('scene').getBoundingClientRect(),task=room.tasks.find(t=>t.id===g.id),p=limitWorkMove(task,point(e),site.regions,box);send({type:'move',id:g.id,x:p[0],y:p[1],frame:{width:box.width,height:box.height}});if(mode==='move')showMoveComplete(e);}else{Object.assign(g.marker.style,g.originalStyle);}}
 if(g.type==='draw'&&!cancel&&g.image===room.image&&g.last){const end=point(e),box=$('scene').getBoundingClientRect();if(Math.hypot((end[0]-g.origin[0])*box.width,(end[1]-g.origin[1])*box.height)>4)g.moved=true;if(!g.moved){showCanvasActions(e);return;}const p=point(e);const stroke={points:[g.last,p],color:myColor,person:myName,owner:myInkOwner,width:gesture?.width||g?.width||penWidth};if(send({type:'stroke',points:stroke.points,image:room.image,width:stroke.width,id:gesture?.id||g?.id})){room.strokes.push(stroke);paint(stroke);updatePenTools();}}
}
$('scene').onpointerup=e=>finish(e);$('scene').onpointercancel=e=>finish(e,true);$('scene').addEventListener('lostpointercapture',e=>finish(e,true));
function selectMode(next){if($('moveCompleteTools'))$('moveCompleteTools').hidden=true;if(bulkDeleting)endBulkDelete();if(pendingPlacementId)cancelPendingPlacement();if(workAreaEdit)cancelWorkArea();if(pumpRouteTaskId)cancelPumpRoute();if(regionTransforming)closeRegionTransform(true);
 if(gesture?.timer)clearTimeout(gesture.timer);gesture=null;cancelAreaZoom();
 mode=next;document.querySelectorAll('button[data-mode]').forEach(b=>{b.classList.toggle('active',b.dataset.mode===mode);b.setAttribute('aria-pressed',String(b.dataset.mode===mode));});$('scene').dataset.mode=mode;$('personalAreaZoom').classList.toggle('active',mode==='zoom');$('personalAreaZoom').setAttribute('aria-pressed',String(mode==='zoom'));
 updatePenTools();$('inkAuthor').hidden=true;
 $('modeHint').textContent={draw:'사진 위에 그리기 · 펜을 다시 누르면 사진 이동',move:'아이콘을 길게 눌러 위치를 옮기세요',pan:'휠로 확대·축소, 드래그로 이동, 모서리로 크기 조절',zoom:'사진에서 확대할 구간을 드래그하세요 · Esc로 취소'}[mode];
}
for(const button of document.querySelectorAll('button[data-mode]'))button.onclick=()=>selectMode(button.dataset.mode==='draw'&&mode==='draw'?idleMode():button.dataset.mode);
function mobileView(){return matchMedia('(max-width:900px), (pointer:coarse)').matches;}
function idleMode(){return 'pan';}
function minimumZoom(){return mobileView()?1:.2;}
function updatePenTools(){$('canvasDraw').hidden=mode==='draw';$('canvasActionMenu').dataset.mode=mode;$('canvasEraseOwn').hidden=(!mobileView()&&canClearInk)||mode!=='draw';$('canvasEraseOwn').disabled=!myInkOwner||!room?.strokes.some(stroke=>stroke.owner===myInkOwner);if($('canvasActionMenu').hidden&&$('clearInk').parentElement!==$('penActions'))$('penActions').append($('clearInk'));$('workspace').classList.toggle('pen-active',mode==='draw');$('penActions').hidden=gesture?.type==='draw'||mobileView()||!canClearInk||!room?.strokes.length;$('clearInk').hidden=gesture?.type==='draw'||!canClearInk||mobileView()||!room?.strokes.length;}
async function clearAllInk(){try{const response=await fetch('/api/rooms/'+room.id+'/ink/clear',{method:'POST',headers:{...hostHeaders,'Content-Type':'application/json'},body:JSON.stringify({person:myName,image:room.image})});const result=await response.json();if(!response.ok)throw Error(result.error||'그림을 지우지 못했습니다.');$('canvasActionMenu').hidden=true;selectMode('pan');}catch(error){toast(error.message);}}
$('scene').dataset.mode=mode;
$('back').onclick=$('returnTop').onclick=()=>send({type:'top'});
function setZoom(){zoom=Math.max(minimumZoom(),Math.min(8,zoom));const r=$('viewport').getBoundingClientRect(),frame=photoFrame(r,$('background'),zoom),{width,limitX,limitY}=frame;panX=Math.max(-limitX,Math.min(limitX,panX));panY=Math.max(-limitY,Math.min(limitY,panY));$('scene').style.setProperty('--marker-scale','1');$('scene').style.width=width+'px';$('scene').style.transform=`translate(-50%,-50%) translate(${panX}px,${panY}px)`;$('zoomLabel').textContent=Math.round(zoom*100)+'%';$('personalZoomLevel').textContent=Math.round(zoom*100)+'%';$('viewToolsToggle').textContent=Math.round(zoom*100)+'%';$('zoomOut').disabled=$('personalZoomOut').disabled=zoom<=minimumZoom();requestAnimationFrame(()=>{layoutTaskMarkers();clampMobileTaskLabels();layoutPhotos();});}

$('zoomIn').onclick=()=>{rememberView();zoom=Math.min(8,zoom*1.2);setZoom();};$('zoomOut').onclick=()=>{rememberView();zoom=Math.max(minimumZoom(),zoom/1.2);setZoom();};
let uploading=false,photoAnchor=null;
for(const [input,kind] of [['topFile','top'],['photoFile','photo']])$(input).onchange=async()=>{
 const file=$(input).files[0];if(!file)return;
 if(uploading){toast('진행 중인 업로드가 끝난 뒤 다시 선택해주세요.');$(input).value='';return;}
 if(file.size>50*1024*1024){toast('사진은 최대 50MB까지 지원합니다.');$(input).value='';return;}
 uploading=true;const anchor=kind==='photo'?photoAnchor:null;photoAnchor=null;const params=new URLSearchParams({kind});let thumbnail='';
 if(kind==='photo'){params.set('save','1');params.set('title',file.name.slice(0,120));params.set('date',selectedDates[0]);if(anchor){params.set('x',anchor[0]);params.set('y',anchor[1]);}thumbnail=await photoThumbnail(file);}
 const xhr=new XMLHttpRequest();xhr.open('POST',`/api/rooms/${room.id}/image?${params}`);xhr.timeout=180000;if(thumbnail)xhr.setRequestHeader('X-Mouseon-Thumbnail',thumbnail);
 xhr.upload.onprogress=e=>{if(e.lengthComputable)toast(`사진 업로드 중 · ${Math.round(e.loaded/e.total*100)}%`);};
 xhr.onload=()=>{let result;try{result=JSON.parse(xhr.responseText);}catch{}toast(xhr.status===200?'사진을 공유했습니다.':result?.error||'업로드에 실패했습니다.');};
 xhr.onerror=()=>toast('업로드 연결을 확인해주세요.');xhr.ontimeout=()=>toast('업로드 시간이 초과되었습니다. 다시 시도해주세요.');xhr.onloadend=()=>{uploading=false;$(input).value='';};xhr.send(file);
};
let sharePoll;
function updateShare(){
 const address=$('networkAddress').value;
 if(!address){$('qr').hidden=true;$('joinUrl').hidden=true;$('copy').disabled=true;return;}
 const link=address+'/?room='+room.id;
 $('joinUrl').value=link;$('joinUrl').hidden=false;$('qr').hidden=false;
 const src='/api/qr?url='+encodeURIComponent(link)+'&room='+room.id;if($('qr').getAttribute('src')!==src)$('qr').src=src;
 $('copy').disabled=false;
}
$('networkAddress').onchange=updateShare;
async function refreshShare(){
 try{
   const res=await fetch('/api/network'+roomQuery(),{headers:hostHeaders});if(!res.ok)throw Error('참여 주소 확인에 실패했습니다. 다시 로그인하거나 연결 상태를 확인해주세요.');
   const {addresses,tunnel}=await res.json();let choices=[];
   if(tunnel.status!=='local'){
     if(tunnel.status==='ready'&&tunnel.url){choices=[tunnel.url];$('shareStatus').textContent='인터넷 연결됨 · 휴대폰 LTE·5G에서도 참여할 수 있습니다.';}
     else $('shareStatus').textContent=tunnel.message||'인터넷 주소 연결 중입니다. 잠시 기다려주세요.';
   } else {
     const loopback=['localhost','127.0.0.1','[::1]'].includes(location.hostname);
     choices=loopback?addresses:[location.origin];
     $('shareStatus').textContent=choices.length?'로컬 연결 · PC와 휴대폰이 같은 네트워크에 있어야 합니다.':'휴대폰용 주소를 찾지 못했습니다. PC의 Wi-Fi 또는 유선 연결을 확인해주세요.';
   }
   const previous=$('networkAddress').value;
   $('networkAddress').replaceChildren(...choices.map(address=>{const option=el('option','',address);option.value=address;return option;}));
   if(choices.includes(previous))$('networkAddress').value=previous;
   $('networkAddress').hidden=!choices.length;updateShare();
 }catch(error){$('shareStatus').textContent=error.message;$('networkAddress').replaceChildren();updateShare();}
}
$('share').onclick=()=>{
 if($('shareDialog').open){$('shareDialog').close();return;}stopActiveTool('share');if(!$('sidePanel').hidden){if($('sidePanel').dataset.section==='work')cancelTaskRegistration();else panel(false);}$('railShare').classList.add('active');$('railShare').setAttribute('aria-expanded','true');
 $('networkAddress').replaceChildren();updateShare();$('shareDialog').show();
 refreshShare();clearInterval(sharePoll);sharePoll=setInterval(refreshShare,2000);
};
$('closeShare').onclick=()=>$('shareDialog').close();
$('shareDialog').addEventListener('close',()=>{if($('shareDialog').open)return;clearInterval(sharePoll);$('railShare').classList.remove('active');$('railShare').setAttribute('aria-expanded','false');});
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('shareDialog').open){$('shareDialog').close();e.preventDefault();e.stopImmediatePropagation();}},true);
$('copy').onclick=async()=>{try{await navigator.clipboard.writeText($('joinUrl').value);toast('참여 링크를 복사했습니다.');}catch{$('joinUrl').select();toast('주소를 선택했습니다. 길게 누르거나 Ctrl+C로 복사해주세요.');}};

function panel(open){if(open){$('workspace').classList.remove('view-tools-open');$('viewToolsToggle').setAttribute('aria-expanded','false');}cancelAreaZoom();$('workspace').classList.toggle('panel-open',open);$('sidePanel').hidden=!open;if(open&&$('sidePanel').dataset.section!=='site')$('toolRail').hidden=false;$('menuToggle').setAttribute('aria-expanded',String(!$('toolRail').hidden));for(const button of document.querySelectorAll('#toolRail [data-section],#siteSettingsButton')){const selected=open&&$('sidePanel').dataset.section===(button.id==='siteSettingsButton'?'site':button.dataset.section);button.classList.toggle('active',selected);button.setAttribute('aria-expanded',String(selected));}measureMobilePanel();setZoom();}
$('menuToggle').onclick=()=>{if(mobileView()&&!$('sidePanel').hidden){panel(false);$('toolRail').hidden=false;$('menuToggle').setAttribute('aria-expanded','true');return;}const opening=$('toolRail').hidden;$('toolRail').hidden=!opening;if(!opening)panel(false);$('menuToggle').setAttribute('aria-expanded',String(opening));};$('menuClose').onclick=()=>{if($('sidePanel').dataset.section==='work')cancelTaskRegistration();else panel(false);};
function openToolSection(section){stopActiveTool(section);if($('shareDialog').open)$('shareDialog').close();if(section!=='work')$('nearTaskCancel').hidden=true;if(section==='works'){section='site';$('worksPanel').open=true;}$('sidePanel').dataset.section=section;$('sidePanel').querySelector('.side-heading b').textContent=({all:'회의 도구',work:'작업 등록',site:'현장 설정',photo:'상세 사진',works:'웍스 연동'})[section]||'회의 도구';$('workspace').classList.toggle('site-settings-open',section==='site');for(const [name,id]of Object.entries({site:'sitePanel',work:'registration',works:'worksPanel'}))if(name===section)$(id).open=true;panel(true);}
function stopActiveTool(next){if(photoMove)cancelPhotoMove();if(photoHold){clearTimeout(photoHold.timer);photoHold=null;}if(bulkDeleting)endBulkDelete();if(pendingPlacementId)cancelPendingPlacement();if(workAreaEdit)cancelWorkArea();if($('pendingPopover'))closePending();
 if(pumpRouteTaskId)cancelPumpRoute();
 if(regionTransforming)closeRegionTransform(false);
 if(regionPicking||regionEditId)cancelRegionDraft();
 if(picking||(!$('sidePanel').hidden&&$('sidePanel').dataset.section==='work'&&next!=='work'))cancelTaskRegistration();
 if(mode!=='pan'||gesture)selectMode('pan');$('canvasActionMenu').hidden=true;
}
function toggleToolSection(section){if(!$('sidePanel').hidden&&$('sidePanel').dataset.section===section){if(section==='work')cancelTaskRegistration();else panel(false);return false;}openToolSection(section);return true;}
for(const button of document.querySelectorAll('#toolRail [data-section]'))button.onclick=e=>{if(button.dataset.section==='photo'){chooseDetailPhoto();return;}if(!toggleToolSection(button.dataset.section))return;if(button.dataset.section==='work'){placeNear($('nearTaskCancel'),e.clientX+36,e.clientY,90);}};
$('siteSettingsButton').onclick=()=>{if(toggleToolSection('site')){$('sidePanel').scrollTop=0;void refreshCloudStatus();}};
$('pendingWorksButton').onclick=()=>{const opening=$('pendingPopover').hidden;closePending();if(opening){stopActiveTool('pending');if(!$('sidePanel').hidden)panel(false);$('pendingPopover').hidden=false;$('pendingWorksButton').setAttribute('aria-expanded','true');placePending();}};
$('railShare').onclick=()=>$('share').click();$('railShare').setAttribute('aria-label','참여 QR');
for(const b of document.querySelectorAll('button[data-mode]')){const previous=b.onclick;b.onclick=()=>{if(b.dataset.mode!==mode||picking||regionPicking||regionTransforming||!$('sidePanel').hidden)stopActiveTool(b.dataset.mode);previous();panel(false);};}
$('fullScreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{toast('이 브라우저는 전체화면을 지원하지 않습니다.');}};
function updateTitle(){const dates=selectedDates.map(d=>d.replaceAll('-','.')+' '+['일','월','화','수','목','금','토'][new Date(d+'T12:00:00Z').getUTCDay()]);$('meetingTitle').textContent='명일 작업사항 ('+dates.join(' · ')+')';}
function chooseDates(dates){if(bulkDeleting)endBulkDelete();if(pumpRouteTaskId)cancelPumpRoute();selectedDates=dates;$('worksDate').value=dates[0];$('viewDate').value=dates.length===1?dates[0]:'';if(room)render();else updateTitle();renderDateChoices();}
function renderDateChoices(){const plan=schedule();$('dateChoices').replaceChildren();for(const date of plan.options){const b=el('button',selectedDates.includes(date)?'active':'',date.slice(5).replace('-','/')+' '+['일','월','화','수','목','금','토'][new Date(date+'T12:00:00Z').getUTCDay()]);b.onclick=()=>chooseDates([date]);$('dateChoices').append(b);}}
$('viewDate').onchange=()=>{if(validDate($('viewDate').value))chooseDates([$('viewDate').value]);};$('defaultDates').onclick=()=>chooseDates(schedule().dates);
$('taskDate').value=selectedDates[0];$('worksDate').value=selectedDates[0];chooseDates(selectedDates);
function reveal(){if($('pmxTaskCheck'))pmxUI.updateAction();requestAnimationFrame(clampMobileTaskLabels);const id=activeId||pinnedId;const selected=room?.tasks.find(t=>t.id===pinnedId);$('taskActions').hidden=bulkDeleting||!selected||Boolean(pumpRouteTaskId)||Boolean(workAreaEdit);if(selected)$('selectedTaskName').textContent=selected.title;if($('clearTaskPosition'))$('clearTaskPosition').hidden=!selected||!isTop()||!selected.sourceKey&&!selected.positionConfirmed&&!selected.requiresPositionConfirmation;
 $('pumpRouteButton').textContent='차량 동선';$('pumpRouteButton').hidden=!selected||!hasConcreteRoute(selected);for(const svg of $('routeLayer').children)svg.classList.toggle('revealed',svg.dataset.task===(svg.dataset.mixerRoute?(mobileView()?pinnedId:activeId):id));for(const marker of $('tasks').children){marker.classList.toggle('selected',marker.dataset.id===id);marker.classList.toggle('actions-open',!$('taskActions').hidden&&marker.dataset.id===pinnedId);}}
function renderDraft(){const svg=$('draftLayer');svg.replaceChildren();const shape=document.createElementNS(svg.namespaceURI,$('taskShape').value==='area'?'polygon':'polyline');shape.setAttribute('points',draft.map(p=>p.map(v=>v*1000).join(',')).join(' '));svg.append(shape);for(const [x,y] of draft){const dot=document.createElementNS(svg.namespaceURI,'circle');dot.setAttribute('cx',x*1000);dot.setAttribute('cy',y*1000);dot.setAttribute('r',6);svg.append(dot);}$('geometryCount').textContent=mobileView()&&$('taskShape').value==='area'?(draft.length?'사각형 지정됨':'사각형을 끌어서 지정'):draft.length+'점 지정';}
$('pickGeometry').onclick=e=>{$('nearTaskCancel').hidden=true;if(!isTop()){toast('탑뷰로 복귀한 뒤 위치를 지정해주세요.');return;}draft=[];picking=true;renderDraft();panel(false);$('cancelTaskPlacement').hidden=false;$('finishGeometry').hidden=false;$('finishGeometry').classList.add('floating-finish');showPlacementActions(e);toast(mobileView()&&$('taskShape').value==='area'?'사진을 대각선으로 끌어 사각형을 지정하고 완료를 누르세요.':'지도에서 위치를 찍고 위치 지정 완료를 누르세요.');};
// The finish control is outside the collapsed menu while selecting geometry.
$('workspace').append($('finishGeometry'));
$('finishGeometry').onclick=()=>{if($('taskShape').value==='area'&&draft.length<3){toast('사각형 영역을 먼저 지정해주세요.');return;}picking=false;$('cancelTaskPlacement').hidden=true;$('finishGeometry').hidden=true;panel(true);};
if(mobileView()){$('taskShape').value='point';document.querySelectorAll('button[data-mode=pan]').forEach(b=>b.textContent='✋ 사진 이동');}
$('taskShape').onchange=()=>{draft=[];renderDraft();};
$('taskForm').onsubmit=e=>{e.preventDefault();if(!draft.length&&!keptGeometry.length){toast('먼저 지도에서 작업 위치를 지정해주세요.');return;}let primary={shape:$('taskShape').value,points:draft};let extras=keptGeometry;if(!draft.length){primary=keptGeometry[0];extras=keptGeometry.slice(1);}const shape=primary.shape;if((shape==='area'&&primary.points.length<3)||(shape==='route'&&primary.points.length<2)){toast('영역은 3점, 동선은 2점 이상 찍어주세요.');return;}
 const date=$('taskDate').value;const hazard=(site.hazards||defaultHazards()).find(h=>'hazard:'+h.id===$('taskIcon').value);const task={title:$('taskTitle').value,detail:$('taskDetail').value,equipment:$('taskEquipment').value,icon:hazard?.icon||$('taskIcon').value,...(hazard?{hazardId:hazard.id}:{}),date,shape,points:primary.points,extras,attention:$('taskAttention').value,x:shape==='area'?(Math.min(...primary.points.map(p=>p[0]))+Math.max(...primary.points.map(p=>p[0])))/2:primary.points[0][0],y:shape==='area'?(Math.min(...primary.points.map(p=>p[1]))+Math.max(...primary.points.map(p=>p[1])))/2:primary.points[0][1]};
 if(send({type:'addTask',task})){$('nearTaskCancel').hidden=true;chooseDates([date]);draft=[];keptGeometry=[];$('keptGeometryCount').textContent='';$('taskAttention').value='';renderDraft();$('taskTitle').value='';$('taskDetail').value='';$('taskEquipment').value='';selectMode('pan');activeId=pinnedId=null;$('canvasActionMenu').hidden=true;panel(false);}
};
window.addEventListener('resize',setZoom);document.addEventListener('fullscreenchange',setZoom);

const zoomTools=$('zoomIn').parentElement;zoomTools.className='zoom-tools';$('sidePanel').append(zoomTools);

function deleteTask(task){if(confirm('“'+task.title+'” 작업을 삭제할까요?')){send({type:'deleteTask',id:task.id});if(pinnedId===task.id)pinnedId=null;activeId=null;}}
$('deleteSelected').onclick=()=>{const task=room?.tasks.find(t=>t.id===pinnedId);if(task)deleteTask(task);};
let viewGesture=null,spaceHeld=false;
const viewport=$('viewport');
const touchPoints=new Map();let pinch=null,pinchBlocking=false;
function beginPinch(){const [a,b]=[...touchPoints.values()],box=viewport.getBoundingClientRect();if(gesture?.timer)clearTimeout(gesture.timer);gesture=null;viewGesture=null;cancelAreaZoom();if(rectangleGesture){draft=rectangleGesture.previous;rectangleGesture=null;renderDraft();}rememberView();pinch={distance:Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)),zoom,panX,panY,cx:(a.x+b.x)/2-box.left-box.width/2,cy:(a.y+b.y)/2-box.top-box.height/2};pinchBlocking=true;for(const id of touchPoints.keys())viewport.setPointerCapture(id);}
viewport.addEventListener('pointerdown',e=>{if(!workAreaEdit||!e.target.closest('#scene')||e.button!==0||pinchBlocking)return;if(e.pointerType==='touch'){touchPoints.set(e.pointerId,{x:e.clientX,y:e.clientY});if(touchPoints.size>=2){if(workAreaEdit.drag){workAreaEdit.points=workAreaEdit.drag.before;workAreaEdit.drag=null;renderWorkArea();}e.preventDefault();e.stopImmediatePropagation();beginPinch();return;}}e.preventDefault();e.stopImmediatePropagation();if(!siteInputAllowed(e))return;workAreaEdit.drag={pointer:e.pointerId,start:point(e),before:structuredClone(workAreaEdit.points)};viewport.setPointerCapture(e.pointerId);},true);
viewport.addEventListener('pointermove',e=>{if(pinchBlocking||!workAreaEdit?.drag||workAreaEdit.drag.pointer!==e.pointerId)return;if(e.pointerType==='touch')touchPoints.set(e.pointerId,{x:e.clientX,y:e.clientY});e.preventDefault();e.stopImmediatePropagation();const [x,y]=workAreaEdit.drag.start,[u,v]=point(e);workAreaEdit.points=[[Math.min(x,u),Math.min(y,v)],[Math.max(x,u),Math.min(y,v)],[Math.max(x,u),Math.max(y,v)],[Math.min(x,u),Math.max(y,v)]];renderWorkArea();},true);
for(const type of ['pointerup','pointercancel','lostpointercapture'])viewport.addEventListener(type,e=>{if(!workAreaEdit?.drag||workAreaEdit.drag.pointer!==e.pointerId)return;e.preventDefault();e.stopImmediatePropagation();const g=workAreaEdit.drag;workAreaEdit.drag=null;if(e.pointerType==='touch'&&type!=='lostpointercapture')touchPoints.delete(e.pointerId);const box=$('scene').getBoundingClientRect(),p=point(e);if(type!=='pointerup'||!siteInputAllowed(e)||Math.abs(p[0]-g.start[0])*box.width<3||Math.abs(p[1]-g.start[1])*box.height<3)workAreaEdit.points=g.before;else workAreaEdit.history.push(g.before);renderWorkArea();if(type==='pointerup')placeNear(workAreaTools,e.clientX,e.clientY);if(viewport.hasPointerCapture(e.pointerId))viewport.releasePointerCapture(e.pointerId);},true);
viewport.addEventListener('pointerdown',e=>{if(e.pointerType!=='touch')return;touchPoints.set(e.pointerId,{x:e.clientX,y:e.clientY});if(touchPoints.size>=2){e.preventDefault();e.stopImmediatePropagation();beginPinch();}else if(pinchBlocking){e.preventDefault();e.stopImmediatePropagation();}},true);
viewport.addEventListener('pointermove',e=>{if(e.pointerType!=='touch'||!touchPoints.has(e.pointerId))return;touchPoints.set(e.pointerId,{x:e.clientX,y:e.clientY});if(!pinchBlocking)return;e.preventDefault();e.stopImmediatePropagation();if(touchPoints.size<2||!pinch)return;const [a,b]=[...touchPoints.values()],box=viewport.getBoundingClientRect();zoom=Math.max(minimumZoom(),Math.min(8,pinch.zoom*Math.hypot(a.x-b.x,a.y-b.y)/pinch.distance));const scale=zoom/pinch.zoom;panX=(a.x+b.x)/2-box.left-box.width/2-(pinch.cx-pinch.panX)*scale;panY=(a.y+b.y)/2-box.top-box.height/2-(pinch.cy-pinch.panY)*scale;setZoom();},true);
for(const type of ['pointerup','pointercancel'])viewport.addEventListener(type,e=>{if(e.pointerType!=='touch')return;touchPoints.delete(e.pointerId);if(pinchBlocking){e.stopImmediatePropagation();if(!touchPoints.size){pinch=null;pinchBlocking=false;viewGesture=null;}}},true);
window.addEventListener('blur',()=>{touchPoints.clear();pinch=null;pinchBlocking=false;});

viewport.addEventListener('pointerdown',e=>{if(!picking||regionPicking||!mobileView()||$('taskShape').value!=='area'||!mainInputAllowed(e))return;e.preventDefault();e.stopImmediatePropagation();rectangleGesture={start:point(e),previous:structuredClone(draft)};draft=[];viewport.setPointerCapture(e.pointerId);},true);
viewport.addEventListener('pointermove',e=>{if(!rectangleGesture||!mainInputAllowed(e))return;e.preventDefault();e.stopImmediatePropagation();const [x,y]=rectangleGesture.start,[u,v]=point(e);draft=[[Math.min(x,u),Math.min(y,v)],[Math.max(x,u),Math.min(y,v)],[Math.max(x,u),Math.max(y,v)],[Math.min(x,u),Math.max(y,v)]];renderDraft();},true);
function finishRectangle(e,cancel=false){if(!rectangleGesture)return;if(!mainInputAllowed(e)){rectangleGesture=null;renderDraft();return;}e.stopImmediatePropagation();if(cancel)draft=rectangleGesture.previous;else{const [x,y]=rectangleGesture.start,[u,v]=point(e);draft=Math.abs(x-u)<.005||Math.abs(y-v)<.005?[]:[[Math.min(x,u),Math.min(y,v)],[Math.max(x,u),Math.min(y,v)],[Math.max(x,u),Math.max(y,v)],[Math.min(x,u),Math.max(y,v)]];}rectangleGesture=null;showPlacementActions(e);if(viewport.hasPointerCapture(e.pointerId))viewport.releasePointerCapture(e.pointerId);renderDraft();}
viewport.addEventListener('pointerup',e=>finishRectangle(e),true);viewport.addEventListener('pointercancel',e=>finishRectangle(e,true),true);
viewport.addEventListener('lostpointercapture',()=>{if(rectangleGesture){draft=rectangleGesture.previous;rectangleGesture=null;renderDraft();}});

viewport.addEventListener('wheel',e=>{if(!room||picking||regionPicking||regionTransforming)return;e.preventDefault();cancelAreaZoom();if(performance.now()-lastWheelTime>250)rememberView();lastWheelTime=performance.now();const box=viewport.getBoundingClientRect(),x=e.clientX-box.left-box.width/2,y=e.clientY-box.top-box.height/2;const next=Math.max(minimumZoom(),Math.min(8,zoom*Math.exp(-e.deltaY*.0015)));const factor=next/zoom;panX=x-(x-panX)*factor;panY=y-(y-panY)*factor;zoom=next;setZoom();},{passive:false});
viewport.addEventListener('pointerdown',e=>{
 if(photoMove||workAreaEdit||pumpRouteTaskId||!pendingPlacementId&&e.target.closest('.photo-pin,.vertical-warning'))return;
 if(mobileView()&&e.target.closest('[data-resize]'))return;
 if(picking||regionPicking||regionTransforming||(!spaceHeld&&mode!=='pan'&&e.button!==1&&!e.target.closest('[data-resize]')))return;
 if(!pendingPlacementId&&mode==='pan'&&e.target.closest('.marker,.vertical-warning,[data-site-region]')&&!spaceHeld&&e.button!==1)return;rememberView();e.preventDefault();e.stopPropagation();const rect=viewport.getBoundingClientRect();const cx=rect.x+rect.width/2+panX,cy=rect.y+rect.height/2+panY;
 viewGesture={tap:mode==='pan'&&!spaceHeld&&e.button===0&&Boolean(e.target.closest('#scene'))&&!e.target.closest('[data-resize]'),resize:!mobileView()&&Boolean(e.target.closest('[data-resize]')),x:e.clientX,y:e.clientY,px:panX,py:panY,zoom,distance:Math.hypot(e.clientX-cx,e.clientY-cy),cx,cy};viewport.setPointerCapture(e.pointerId);
},true);
viewport.addEventListener('pointermove',e=>{if(!viewGesture)return;e.preventDefault();const g=viewGesture;if(g.resize)zoom=Math.max(minimumZoom(),Math.min(8,g.zoom*Math.hypot(e.clientX-g.cx,e.clientY-g.cy)/Math.max(1,g.distance)));else{panX=g.px+e.clientX-g.x;panY=g.py+e.clientY-g.y;}setZoom();});
for(const type of ['pointerup','pointercancel','lostpointercapture'])viewport.addEventListener(type,e=>{const g=viewGesture;viewGesture=null;if(type==='pointerup'&&g?.tap&&Math.hypot(e.clientX-g.x,e.clientY-g.y)<9){panX=g.px;panY=g.py;setZoom();if(pendingPlacementId){if(siteInputAllowed(e)){const p=point(e);suppressPlacementClick=true;if(send({type:'move',id:pendingPlacementId,x:p[0],y:p[1]}))cancelPendingPlacement();}else toast('현장 사진의 작업 위치를 선택해주세요.');}else showCanvasActions(e);}});
window.addEventListener('keydown',e=>{if(e.code==='Space'&&!/INPUT|SELECT|TEXTAREA|BUTTON/.test(document.activeElement?.tagName)){spaceHeld=true;e.preventDefault();}});window.addEventListener('keyup',e=>{if(e.code==='Space')spaceHeld=false;});window.addEventListener('blur',()=>{spaceHeld=false;viewGesture=null;});
const fit=el('button','','화면 맞춤');fit.id='fitImage';fit.onclick=resetView;zoomTools.append(fit);

let worksEntries=[];
function showWorksEntry(){const entry=worksEntries[Number($('worksEntry').value)];$('worksOriginal').textContent=entry?entry.calendar+' · '+entry.date+'\n'+entry.text:'';}
$('worksFile').onchange=async()=>{const file=$('worksFile').files[0];if(!file)return;try{
 if(file.size>1024*1024)throw Error('가져오기 파일은 1MB까지 지원합니다.');const data=JSON.parse(await file.text());
 if(data.format!=='mouseon-works-preview/v1'||!Array.isArray(data.entries)||data.entries.length<1||data.entries.length>50||!data.entries.every(e=>typeof e.text==='string'&&e.text.trim()&&e.text.length<=1200&&validDate(e.date)&&typeof e.calendar==='string'&&e.calendar.length<=100))throw Error('선택 일정 미리보기 JSON 형식을 확인해주세요.');
 worksEntries=data.entries;$('worksEntry').replaceChildren(...worksEntries.map((entry,i)=>{const option=el('option','',entry.text.slice(0,65));option.value=String(i);return option;}));showWorksEntry();$('worksDialog').showModal();
 }catch(error){toast(error.message);}finally{$('worksFile').value='';}};
$('worksEntry').onchange=showWorksEntry;$('closeWorks').onclick=()=>$('worksDialog').close();
$('prepareWorks').onclick=()=>{const entry=worksEntries[Number($('worksEntry').value)];if(!entry)return;
 $('taskTitle').value=entry.text.replaceAll('\n',' ').slice(0,80);$('taskDetail').value=entry.text.length>80?entry.text.slice(80,260):'';$('taskDate').value=entry.date;
 $('taskIcon').value=classifyWork(entry.text).icon;
 draft=[];keptGeometry=[];$('keptGeometryCount').textContent='';renderDraft();$('taskShape').value='point';$('taskEquipment').value='';$('registration').open=true;$('worksDialog').close();panel(true);toast('자동 등록 전 단계입니다. 내용·날짜·위치를 확인하고 작업 저장을 눌러주세요.');
};

function cleanTaskTitle(text){return text.replace(/\d{4}[.\/-]\d{1,2}[.\/-]\d{1,2}/g,'').replace(/^\d+\.\s*/,'').replace(/\(?\d{1,2}[:：]\d{2}\)?/g,'').replace(/\d{1,2}시(?:\s*\d{1,2}분)?/g,'').replace(/\S*팀/g,'').replace(/\s+/g,' ').replace(/\s*[~∼-]\s*$/,'').trim();}
$('previousDay').onclick=()=>chooseDates([stepWorkday(selectedDates[0],-1)]);$('nextDay').onclick=()=>chooseDates([stepWorkday(selectedDates.at(-1),1)]);

async function api(route,body){const res=await fetch(route+roomQuery(),{method:body?'POST':'GET',headers:{...hostHeaders,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});const value=await res.json();if(!res.ok)throw Error(value.error||'요청 실패');return value;}
async function loadSite(){try{site=await api('/api/site');siteDraft=structuredClone(site);renderSite();}catch(error){toast(error.message);}}
function renderSite(){if(!siteDraft)return;siteDraft.hazards??=defaultHazards();renderHazards();$('siteFont').value=siteDraft.font||'system';document.documentElement.dataset.siteFont=siteDraft.font||'system';$('siteImageStatus').textContent=site.image?'기본 탑뷰 저장됨 · 다음 회의에서도 사용합니다. 교체 후 영역 위치를 확인하세요.':'기본 탑뷰를 등록하면 재실행·새 회의에서도 유지됩니다.';$('regionCount').value=siteDraft.regions.length;updateSiteSaveStatus();renderPending();drawSiteRegions();if(room)renderVerticalWarnings(safetyTasksForDates(room.tasks,selectedDates));$('siteName').value=siteDraft.name;$('regionList').replaceChildren();for(const region of siteDraft.regions){const row=el('div','site-region');row.dataset.regionId=region.id;const nameInput=el('input');nameInput.value=region.name;nameInput.maxLength=80;nameInput.setAttribute('aria-label','영역 이름 '+region.id);nameInput.oninput=()=>{region.name=nameInput.value;updateSiteSaveStatus();drawSiteRegions();renderRegionBoxes();};const nameLabel=el('span','region-name-label',region.name);row.append(nameLabel,nameInput);nameInput.addEventListener('input',()=>nameLabel.textContent=nameInput.value);const edit=el('button','','편집');edit.onclick=()=>{cancelRegionDraft(false);regionEditId=region.id;$('saveRegion').textContent='영역 편집 반영';$('regionName').value=region.name;$('regionAliases').value=region.aliases.join(', ');draft=structuredClone(region.points);renderSiteDraft();};row.append(edit);const remove=el('button','','삭제');remove.onclick=()=>{if(confirm(region.name+' 기본 영역을 삭제할까요? 저장 버튼을 눌러야 확정됩니다.')){if(regionEditId===region.id)cancelRegionDraft(false);siteDraft.regions=siteDraft.regions.filter(r=>r.id!==region.id);renderSite();}};row.append(remove);$('regionList').append(row);}renderRegionBoxes();}
function renderSiteDraft(){const svg=$('draftLayer');svg.replaceChildren();const polygon=document.createElementNS(svg.namespaceURI,'polygon');polygon.setAttribute('points',draft.map(p=>p.map(v=>v*1000).join(',')).join(' '));svg.append(polygon);for(const [x,y]of draft){const dot=document.createElementNS(svg.namespaceURI,'circle');dot.setAttribute('cx',x*1000);dot.setAttribute('cy',y*1000);dot.setAttribute('r',5);svg.append(dot);}}
$('pickRegion').onclick=()=>{if(!isTop()){toast('탑뷰로 돌아온 뒤 설정해주세요.');return;}regionPicking=true;picking=false;$('regionDrawingControls').hidden=false;draft=[];renderSiteDraft();panel(false);$('finishGeometry').hidden=false;toast('동·시설 경계를 3점 이상 찍고 완료를 누르세요.');};
$('finishGeometry').addEventListener('touchend',e=>{if(e.touches.length||$('finishGeometry').hidden)return;e.preventDefault();$('finishGeometry').click();},{passive:false});
const oldFinish=$('finishGeometry').onclick;$('finishGeometry').onclick=()=>{if(regionPicking){regionPicking=false;$('regionDrawingControls').hidden=true;$('finishGeometry').hidden=true;panel(true);}else oldFinish();};
$('saveRegion').onclick=()=>{const name=$('regionName').value.trim();if(!name||draft.length<3){toast('영역 이름과 경계점 3개 이상이 필요합니다.');return;}siteDraft.regions=siteDraft.regions.filter(r=>r.id!==regionEditId);siteDraft.regions.push({id:regionEditId||crypto.randomUUID(),name,aliases:$('regionAliases').value.split(',').map(s=>s.trim()).filter(Boolean),points:structuredClone(draft)});regionEditId=null;$('saveRegion').textContent='영역 추가';draft=[];$('draftLayer').replaceChildren();$('regionName').value='';$('regionAliases').value='';renderSite();};
$('saveSite').onclick=async()=>{try{if(regionTransforming){closeRegionTransform(true);}if(regionPicking||regionEditId||draft.length){toast('먼저 영역 추가·편집 반영 또는 영역 취소를 눌러주세요.');return;}if($('useSiteImage').checked&&site.image&&siteDraft.regions.length&&!confirm('기본 탑뷰를 바꾸면 기존 영역과 위치가 어긋날 수 있습니다. 영역을 확인한 상태인가요?'))return;const next=await api('/api/site',{site:{...siteDraft,name:$('siteName').value,font:$('siteFont').value},revision:site.revision,useCurrentImage:$('useSiteImage').checked});site=next;siteDraft=structuredClone(next);renderSite();toast('현장 기본 설정을 저장했습니다. 새 회의에서도 유지됩니다.');}catch(error){toast(error.message);}};
function downloadJSON(value,name){const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'})),a=el('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('backupSite').onclick=async()=>{try{downloadJSON(await api('/api/site/backup'),'MouseOn-site-backup.json');}catch(error){toast(error.message);}};
$('restoreSite').onchange=async()=>{const file=$('restoreSite').files[0];if(!file)return;try{if(file.size>72*1024*1024)throw Error('백업 파일이 너무 큽니다.');const input=JSON.parse(await file.text());if(!confirm('현장 기본 설정을 백업 내용으로 바꿀까요?'))return;const next=await api('/api/site/restore',{...input,revision:site.revision});site=next;siteDraft=structuredClone(next);renderSite();toast('복원했습니다. 새 회의에서 기본 탑뷰를 사용합니다.');}catch(error){toast(error.message);}finally{$('restoreSite').value='';}};
$('openWorksBrowser').onclick=async()=>{try{const result=await api('/api/works/open',{browser:$('worksBrowser').value});$('worksBatchStatus').textContent=result.message;}catch(error){$('worksBatchStatus').textContent=error.message;}};
let collectingWorks=false;
async function collectBatch(demo){
 if(collectingWorks)return;collectingWorks=true;$('collectWorks').disabled=$('demoWorks').disabled=true;
 $('worksBatchStatus').textContent='작업을 읽어 영역에 배치하고 있습니다…';
 try{const result=await api('/api/works/preview',{date:$('worksDate').value,calendar:$('worksCalendar').value,demo});
  const entries=result.entries;if(!entries.length){$('worksBatchStatus').textContent='읽어온 일정이 없습니다. 기존 작업은 유지합니다.';return;}
  const applied=await api('/api/works/apply',{entries});chooseDates([$('worksDate').value]);
  $('worksBatchStatus').textContent=(demo?'샘플 · ':'')+'작업 '+applied.added+'개 반영 · 기존 '+applied.skipped+'개 유지';toast($('worksBatchStatus').textContent);
 }catch(error){$('worksBatchStatus').textContent=error.message;}
 finally{collectingWorks=false;$('collectWorks').disabled=$('demoWorks').disabled=false;}
}
$('collectWorks').onclick=()=>collectBatch(false);$('demoWorks').onclick=()=>collectBatch(true);
function renderPending(){if(!$('pendingTasks')||!room)return;const pending=room.tasks.filter(t=>selectedDates.includes(t.date)&&(!Number.isFinite(t.x)||!Number.isFinite(t.y)));if(pendingPlacementId&&!pending.some(t=>t.id===pendingPlacementId))cancelPendingPlacement();$('pendingWorksButton').hidden=!pending.length||!isTop();if(!pending.length||!isTop())closePending();$('pendingWorksButton').textContent='위치 확인 '+pending.length;$('pendingPanel').hidden=!pending.length;$('pendingTasks').replaceChildren();for(const task of pending){const row=el('div','pending-task');const label=el('span','',task.title);if(task.materialDelivery)label.prepend(el('small','pending-kind','자재 반입'));row.append(label);const button=el('button','','위치 지정');button.setAttribute('aria-label',task.title+' 위치 지정');button.onclick=e=>{stopActiveTool('pending-place');if(!$('sidePanel').hidden)panel(false);selectMode('pan');pendingPlacementId=task.id;$('scene').classList.add('pending-placing');resetFloatingPosition(pendingPlacementTools);placeNear(pendingPlacementTools,e.clientX,e.clientY,90);toast('사진에서 작업 위치를 클릭·터치해주세요.');};row.append(button);$('pendingTasks').append(row);}}


function drawSiteRegions(){let svg=$('siteLayer');if(!svg){svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.id='siteLayer';svg.setAttribute('viewBox','0 0 1000 1000');svg.setAttribute('preserveAspectRatio','none');$('scene').insertBefore(svg,$('ink'));}svg.replaceChildren();for(const region of (siteDraft||site).regions){const text=document.createElementNS(svg.namespaceURI,'text');const [x,y]=region.labelPosition||regionPoint(region);text.setAttribute('x',x*1000);text.setAttribute('y',y*1000);text.textContent=region.name;svg.append(text);}svg.style.display=room&&isTop()?'':'none';}

function appendTaskGeometry(task,geometry,index){if(!geometry.points?.length||geometry.purpose==='mixer-route'&&!hasConcreteRoute(task))return;
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.dataset.task=task.id;if(geometry.shape==='area'&&geometry.purpose!=='work-area')svg.classList.add('area-geometry');svg.setAttribute('viewBox','0 0 1000 1000');svg.setAttribute('preserveAspectRatio','none');const color=task.hazardColor||kindInfo[iconType(task)]?.[1]||'#657f74';svg.style.setProperty('--geometry-color',color);svg.style.color=color;
 const shape=document.createElementNS(svg.namespaceURI,geometry.shape==='area'?'polygon':geometry.shape==='unloading'?'circle':'polyline');
 if(geometry.shape==='unloading'){shape.setAttribute('cx',geometry.points[0][0]*1000);shape.setAttribute('cy',geometry.points[0][1]*1000);shape.setAttribute('r',14);shape.classList.add('unloading-point');const label=document.createElementNS(svg.namespaceURI,'text');label.setAttribute('x',geometry.points[0][0]*1000+18);label.setAttribute('y',geometry.points[0][1]*1000+5);label.textContent='작업·하역';svg.append(label);}
 else shape.setAttribute('points',geometry.points.map(p=>p.map(v=>v*1000).join(',')).join(' '));
 if(geometry.shape==='route'){const defs=document.createElementNS(svg.namespaceURI,'defs');const id='arrow-'+task.id+'-'+index;defs.innerHTML='<marker id="'+id+'" markerWidth="9" markerHeight="9" refX="8" refY="4" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L8,4 L0,8 Z" fill="currentColor"/></marker>';svg.append(defs);shape.style.markerEnd='url(#'+id+')';}
 svg.append(shape);if(geometry.purpose==='mixer-route'){svg.dataset.mixerRoute='1';appendMixerIcons(svg,geometry.points);}
 $('routeLayer').append(svg);
}
$('keepGeometry').onclick=()=>{const shape=$('taskShape').value,needed=shape==='area'?3:shape==='route'?2:1;if(draft.length<needed){toast('현재 표시의 위치를 먼저 지정해주세요.');return;}if(keptGeometry.length>=10){toast('추가 표시는 최대 10개입니다.');return;}keptGeometry.push({shape,points:structuredClone(draft)});draft=[];renderDraft();$('keptGeometryCount').textContent=keptGeometry.length+'개 보관됨';toast('표시를 보관했습니다. 다음 동선이나 작업·하역 위치를 추가하세요.');};

$('siteName').oninput=()=>{if(siteDraft)siteDraft.name=$('siteName').value;updateSiteSaveStatus();};

function updateViewButtons(){for(const id of ['previousView','mobileViewBack'])if($(id))$(id).disabled=!viewHistory.length;}
function rememberView(){const current={zoom,panX,panY,fitMode};const previous=viewHistory.at(-1);if(!previous||JSON.stringify(current)!==JSON.stringify(previous)){viewHistory.push(current);if(viewHistory.length>30)viewHistory.shift();}updateViewButtons();}
function previousView(){cancelAreaZoom();const previous=viewHistory.pop();if(previous){({zoom,panX,panY,fitMode}=previous);setZoom();}updateViewButtons();}
function resetView(){cancelAreaZoom();rememberView();zoom=1;panX=0;panY=0;fitMode='cover';setZoom();}
function cancelAreaZoom(){areaGesture=null;$('zoomSelection').hidden=true;}
function selectionPoint(e){return [Math.max(areaGesture.left,Math.min(areaGesture.right,e.clientX)),Math.max(areaGesture.top,Math.min(areaGesture.bottom,e.clientY))];}
viewport.addEventListener('pointerdown',e=>{
 if(mode!=='zoom'||picking||regionPicking||regionTransforming||e.button!==0)return;
 const v=viewport.getBoundingClientRect(),image=$('scene').getBoundingClientRect();const left=Math.max(v.left,image.left),right=Math.min(v.right,image.right),top=Math.max(v.top,image.top),bottom=Math.min(v.bottom,image.bottom);
 if(e.clientX<left||e.clientX>right||e.clientY<top||e.clientY>bottom)return;
 e.preventDefault();e.stopImmediatePropagation();areaGesture={x:e.clientX,y:e.clientY,left,right,top,bottom,viewport:v};viewport.setPointerCapture(e.pointerId);$('zoomSelection').hidden=false;drawSelection(e);
},true);
function drawSelection(e){if(!areaGesture)return;const [x,y]=selectionPoint(e),g=areaGesture;g.endX=x;g.endY=y;Object.assign($('zoomSelection').style,{left:Math.min(g.x,x)-g.viewport.left+'px',top:Math.min(g.y,y)-g.viewport.top+'px',width:Math.abs(g.x-x)+'px',height:Math.abs(g.y-y)+'px'});}
viewport.addEventListener('pointermove',e=>{if(areaGesture){e.preventDefault();e.stopImmediatePropagation();drawSelection(e);}},true);
viewport.addEventListener('pointerup',e=>{
 if(!areaGesture)return;e.stopImmediatePropagation();drawSelection(e);const g=areaGesture,w=Math.abs(g.endX-g.x),h=Math.abs(g.endY-g.y);cancelAreaZoom();
 if(w<12||h<12){toast('확대할 구간을 사각형으로 드래그해주세요.');return;}
 rememberView();const target=Math.min((g.viewport.width-24)/w,(g.viewport.height-24)/h);const next=Math.max(minimumZoom(),Math.min(8,zoom*target)),factor=next/zoom;
 const x=(g.x+g.endX)/2-g.viewport.left-g.viewport.width/2,y=(g.y+g.endY)/2-g.viewport.top-g.viewport.height/2;
 panX=-(x-panX)*factor;panY=-(y-panY)*factor;zoom=next;setZoom();selectMode('pan');
},true);
viewport.addEventListener('pointercancel',cancelAreaZoom);viewport.addEventListener('lostpointercapture',()=>{if(areaGesture)cancelAreaZoom();});
window.addEventListener('keydown',e=>{if(e.key==='Escape'){if(regionTransforming){closeRegionTransform(false);return;}if(regionPicking||regionEditId){cancelRegionDraft();return;}cancelAreaZoom();if(mode==='zoom'||mode==='draw')selectMode(idleMode());}});


$('clearInk').onclick=clearAllInk;

function measureMobilePanel(){const mobile=matchMedia('(max-width:900px), (pointer:coarse)').matches;const height=mobile&&!$('sidePanel').hidden?Math.ceil($('sidePanel').getBoundingClientRect().height)+8:0;const value=height+'px';if($('workspace').style.getPropertyValue('--mobile-panel-height')!==value){$('workspace').style.setProperty('--mobile-panel-height',value);setZoom();}}
new ResizeObserver(measureMobilePanel).observe($('sidePanel'));window.addEventListener('resize',()=>{measureMobilePanel();updatePenTools();$('inkAuthor').hidden=true;});selectMode(idleMode());updateViewButtons();

let worksDiagnostic=null;
$('startWorksDiagnostic').onclick=async()=>{try{const result=await api('/api/works/diagnostic-start',{});$('worksBatchStatus').textContent=result.message;}catch(error){$('worksBatchStatus').textContent=error.message;}};
$('readWorksDiagnostic').onclick=async()=>{try{worksDiagnostic=null;$('saveDiagnostic').disabled=true;$('diagnosticReviewed').checked=false;const result=await api('/api/works/diagnostic-read',{includeText:$('diagnosticIncludeText').checked});if(result.format!=='mouseon-works-diagnostic/v1')throw Error('진단 형식을 확인하지 못했습니다.');worksDiagnostic=result;$('diagnosticPreview').textContent=JSON.stringify(result,null,2);$('diagnosticDialog').showModal();}catch(error){$('worksBatchStatus').textContent=error.message;}};
$('diagnosticReviewed').onchange=()=>$('saveDiagnostic').disabled=!$('diagnosticReviewed').checked||!worksDiagnostic;
$('saveDiagnostic').onclick=()=>{if(worksDiagnostic&&$('diagnosticReviewed').checked)downloadJSON(worksDiagnostic,'works-diagnostic.json');};
$('closeDiagnostic').onclick=()=>$('diagnosticDialog').close();

function updateSiteSaveStatus(){if(!siteDraft)return;const dirty=JSON.stringify({name:siteDraft.name,regions:siteDraft.regions,outline:siteDraft.outline,font:siteDraft.font,hazards:siteDraft.hazards})!==JSON.stringify({name:site.name,regions:site.regions,outline:site.outline,font:site.font,hazards:site.hazards||defaultHazards()});$('siteSaveStatus').textContent=dirty?'미저장 변경 있음 · 현장 설정 저장을 눌러주세요':'저장된 현장 설정';$('siteSaveStatus').classList.toggle('dirty',dirty);$('discardSiteChanges').disabled=!dirty;}
function cancelRegionDraft(openPanel=true){const wasPicking=regionPicking;regionPicking=false;regionEditId=null;draft=[];$('draftLayer').replaceChildren();$('regionDrawingControls').hidden=true;if(wasPicking)$('finishGeometry').hidden=true;$('regionName').value='';$('regionAliases').value='';$('saveRegion').textContent='영역 추가';if(openPanel){$('sitePanel').open=true;panel(true);toast('현재 영역 그리기·편집을 취소했습니다. 저장된 영역은 그대로입니다.');}}
$('cancelRegionDrawing').onclick=()=>cancelRegionDraft();$('cancelRegionEdit').onclick=()=>cancelRegionDraft();
$('undoRegionPoint').onclick=()=>{if(regionPicking&&draft.length){draft.pop();renderSiteDraft();}};
$('discardSiteChanges').onclick=()=>{if(!confirm('저장하지 않은 영역 추가·삭제·변경을 모두 취소할까요?'))return;cancelRegionDraft(false);siteDraft=structuredClone(site);renderSite();toast('저장된 현장 설정으로 돌아왔습니다.');};

function hasRegionPointDraft(){return regionPicking||regionEditId||draft.length;}
function makeRegion(index,points){return {id:crypto.randomUUID(),name:'',aliases:[],points};}
function siteAspect(){const img=$('background');return (img.naturalWidth||16)/(img.naturalHeight||10);}
$('applyRegionCount').onclick=()=>{if(hasRegionPointDraft()){toast('정밀 편집을 반영하거나 취소한 뒤 개수를 변경해주세요.');return;}const count=Number($('regionCount').value);let layout;try{layout=tiledRegions(count,siteAspect());}catch(error){toast(error.message);return;}const old=siteDraft.regions;
 if(count<old.length&&!confirm('뒤쪽 영역 '+old.slice(count).map(r=>r.name).join(', ')+'을 삭제할까요? 저장 전에는 변경 취소가 가능합니다.'))return;
 siteDraft.regions=old.slice(0,count);for(let i=old.length;i<count;i++)siteDraft.regions.push(makeRegion(i,layout[i].points));renderSite();toast('영역 '+count+'개 · 현장 설정 저장 전까지 임시 변경입니다.');};
$('addRegionBox').onclick=()=>{if(hasRegionPointDraft()){toast('정밀 편집을 먼저 반영하거나 취소해주세요.');return;}const count=siteDraft.regions.length;if(count>=100){toast('간편 배치는 100개까지 지원합니다.');return;}siteDraft.regions.push(makeRegion(count,tiledRegions(count+1,siteAspect())[count].points));renderSite();};
$('reflowRegions').onclick=()=>{if(hasRegionPointDraft()){toast('정밀 편집을 먼저 반영하거나 취소해주세요.');return;}if(!confirm('영역 이름은 유지하고 모든 위치·크기를 사진을 채우도록 다시 나눌까요?'))return;const layout=tiledRegions(siteDraft.regions.length,siteAspect());siteDraft.regions.forEach((r,i)=>r.points=layout[i].points);renderSite();};
function renderRegionBoxes(){let layer=$('regionBoxLayer');if(!layer){layer=el('div');layer.id='regionBoxLayer';$('scene').append(layer);}layer.hidden=!regionTransforming;layer.replaceChildren();if(!regionTransforming)return;
 for(const region of siteDraft.regions){const b=boundsOf(region.points),box=el('div','region-box');box.dataset.regionId=region.id;box.style.zIndex=region.id===activeRegionBoxId?'2':'1';box.classList.toggle('selected',region.id===activeRegionBoxId);box.setAttribute('aria-label',region.name+' 영역 조절');Object.assign(box.style,{left:b.left*100+'%',top:b.top*100+'%',width:(b.right-b.left)*100+'%',height:(b.bottom-b.top)*100+'%'});box.append(el('span','region-box-name',region.name));for(const corner of ['nw','ne','sw','se']){const handle=el('span','region-corner '+corner);handle.dataset.corner=corner;box.append(handle);}layer.append(box);}
}
function closeRegionTransform(keep){if(!regionTransforming)return;if(!keep&&regionTransformSnapshot)siteDraft.regions=regionTransformSnapshot;regionTransforming=false;regionTransformGesture=null;regionTransformSnapshot=null;$('regionTransformControls').hidden=true;renderRegionBoxes();renderSite();$('sitePanel').open=true;panel(true);toast(keep?'위치·크기 조절 완료 · 현장 설정 저장을 눌러주세요.':'이번 조절을 취소했습니다.');}
$('finishRegionTransform').onclick=()=>closeRegionTransform(true);$('cancelRegionTransform').onclick=()=>closeRegionTransform(false);
viewport.addEventListener('pointerdown',e=>{if(!regionTransforming||e.button!==0)return;const box=e.target.closest('.region-box');if(!box)return;const region=siteDraft.regions.find(r=>r.id===box.dataset.regionId);if(!region)return;e.preventDefault();e.stopImmediatePropagation();activeRegionBoxId=region.id;regionTransformGesture={id:region.id,points:structuredClone(region.points),corner:e.target.closest('[data-corner]')?.dataset.corner||null,x:e.clientX,y:e.clientY,rect:$('scene').getBoundingClientRect()};viewport.setPointerCapture(e.pointerId);renderRegionBoxes();},true);
viewport.addEventListener('pointermove',e=>{const g=regionTransformGesture;if(!g)return;e.preventDefault();e.stopImmediatePropagation();const region=siteDraft.regions.find(r=>r.id===g.id);if(!region)return;region.points=transformRegion(g.points,(e.clientX-g.x)/g.rect.width,(e.clientY-g.y)/g.rect.height,g.corner);drawSiteRegions();renderRegionBoxes();updateSiteSaveStatus();},true);
for(const event of ['pointerup','pointercancel','lostpointercapture'])viewport.addEventListener(event,e=>{if(regionTransformGesture&&event==='pointercancel'){const region=siteDraft.regions.find(r=>r.id===regionTransformGesture.id);if(region)region.points=regionTransformGesture.points;drawSiteRegions();renderRegionBoxes();}regionTransformGesture=null;},true);

let siteTopUploading=false;
$('siteTopFile').onchange=async()=>{const file=$('siteTopFile').files[0];if(!file)return;if(siteTopUploading){toast('기본 탑뷰를 업로드 중입니다.');$('siteTopFile').value='';return;}
 try{if(siteTopUploading)throw Error('기본 탑뷰를 업로드 중입니다.');if(file.size>50*1024*1024)throw Error('탑뷰는 50MB까지 지원합니다.');
 const dirty=JSON.stringify({name:siteDraft.name,regions:siteDraft.regions,outline:siteDraft.outline,font:siteDraft.font,hazards:siteDraft.hazards})!==JSON.stringify({name:site.name,regions:site.regions,outline:site.outline,font:site.font,hazards:site.hazards||defaultHazards()});if(dirty||regionPicking||regionEditId||regionTransforming||draft.length)throw Error('사진을 바꾸기 전에 현재 영역 변경을 저장하거나 취소해주세요.');
 if(site.regions.length&&!confirm('새 기본 탑뷰를 저장합니다. 동 이름·기존 영역은 보존되지만 사진 구도에 따라 위치가 어긋날 수 있습니다. 교체할까요?'))return;
 siteTopUploading=true;$('sitePanel').inert=true;$('siteImageStatus').textContent='기본 탑뷰 업로드·저장 중…';
 const res=await fetch('/api/site/topview'+roomQuery()+'&revision='+site.revision,{method:'POST',headers:hostHeaders,body:file});const result=await res.json();if(!res.ok)throw Error(result.error||'탑뷰 저장에 실패했습니다.');site=result;siteDraft=structuredClone(result);$('useSiteImage').checked=false;renderSite();toast('기본 탑뷰를 저장했습니다. 전경이 바뀌면 같은 버튼에서 교체하세요.');
 }catch(error){$('siteImageStatus').textContent=error.message;toast(error.message);}finally{siteTopUploading=false;$('sitePanel').inert=false;$('siteTopFile').value='';}
};

let meshRevision=0,meshRegions=[],meshSelected=null,meshNode=null,meshHistory=[],meshGesture=null,meshInsert=false;
function meshRemember(value=meshRegions){meshHistory.push(structuredClone(value));if(meshHistory.length>40)meshHistory.shift();}
function meshRegion(){return meshRegions.find(r=>r.id===meshSelected);}
function meshFit(){meshPhotoView.fit();}
function meshRender(){const svg=$('meshSvg');svg.replaceChildren();for(const r of meshRegions){const poly=document.createElementNS(svg.namespaceURI,r.pieces?'path':'polygon');poly.dataset.meshRegion=r.id;poly.classList.toggle('selected',r.id===meshSelected);if(r.pieces){poly.setAttribute('d',regionPath(r));poly.setAttribute('fill-rule','evenodd');}else poly.setAttribute('points',r.points.map(p=>p.map(v=>v*1000).join(',')).join(' '));svg.append(poly);const text=document.createElementNS(svg.namespaceURI,'text'),point=regionPoint(r);text.setAttribute('x',point[0]*1000);text.setAttribute('y',point[1]*1000);text.textContent=r.name||'이름 입력';svg.append(text);}
 const selected=meshRegion();$('meshName').disabled=!selected;$('meshAliases').disabled=!selected;$('meshDeleteRegion').disabled=!selected;$('meshDeletePoint').disabled=!meshNode;$('meshUndo').disabled=!meshHistory.length;$('meshAddPoint').classList.toggle('active',meshInsert);
 if(document.activeElement!==$('meshName'))$('meshName').value=selected?.name||'';if(document.activeElement!==$('meshAliases'))$('meshAliases').value=selected?.aliases.join(', ')||'';
 const edgeLayer=document.createElementNS(svg.namespaceURI,'g');svg.append(edgeLayer);if(selected)selected.points.forEach((p,i)=>{const circle=document.createElementNS(svg.namespaceURI,'circle');circle.dataset.meshPoint=String(i);circle.setAttribute('cx',p[0]*1000);circle.setAttribute('cy',p[1]*1000);circle.setAttribute('r',nodeKey(p)===meshNode?10:7);svg.append(circle);if(meshInsert){const b=selected.points[(i+1)%selected.points.length],edge=document.createElementNS(svg.namespaceURI,'line');edge.dataset.meshEdge=String(i);for(const [key,v]of Object.entries({x1:p[0]*1000,y1:p[1]*1000,x2:b[0]*1000,y2:b[1]*1000}))edge.setAttribute(key,v);edgeLayer.append(edge);}});
}
function openMeshEditor(id=null,anchor=null){openSiteWizard(id,anchor);}

$('meshImage').onload=meshFit;window.addEventListener('resize',meshFit);
const meshSvg=$('meshSvg');
function meshPoint(e){const r=meshSvg.getBoundingClientRect();return [Math.max(0,Math.min(1,(e.clientX-r.x)/r.width)),Math.max(0,Math.min(1,(e.clientY-r.y)/r.height))];}
meshSvg.onpointerdown=e=>{const vertex=e.target.closest('[data-mesh-point]'),poly=e.target.closest('[data-mesh-region]');if(!vertex&&poly&&poly.dataset.meshRegion!==meshSelected){$('meshName').blur();$('meshAliases').blur();meshSelected=poly.dataset.meshRegion;meshNode=null;meshRender();showMeshName(e.clientX,e.clientY);e.preventDefault();return;}const selected=meshRegion();if(!selected)return;const point=meshPoint(e);
 if(meshInsert&&!vertex){let index=0,distance=Infinity,t=.5;for(let i=0;i<selected.points.length;i++){const a=selected.points[i],b=selected.points[(i+1)%selected.points.length],dx=b[0]-a[0],dy=b[1]-a[1],f=Math.max(0,Math.min(1,((point[0]-a[0])*dx+(point[1]-a[1])*dy)/(dx*dx+dy*dy)));const d=Math.hypot(point[0]-a[0]-f*dx,point[1]-a[1]-f*dy);if(d<distance){index=i;distance=d;t=f;}}if(distance>.04){$('meshStatus').textContent='점을 추가할 경계 가까이를 눌러주세요.';return;}try{const inserted=insertSharedPoint(meshRegions,meshSelected,index,t);meshRemember();meshRegions=inserted.regions;meshNode=nodeKey(inserted.point);meshInsert=false;meshRender();$('meshStatus').textContent='점을 추가했습니다. 되돌리기로 취소하거나 선택 점 삭제를 사용할 수 있습니다.';}catch(error){$('meshStatus').textContent=error.message;}return;}
 const index=vertex?Number(vertex.dataset.meshPoint):null;if(index!==null)meshNode=nodeKey(selected.points[index]);$('meshName').blur();meshGesture={screenX:e.clientX,screenY:e.clientY,nodeIndex:index,regions:structuredClone(meshRegions),start:point,points:index===null?structuredClone(selected.points):[[...selected.points[index]]]};meshSvg.setPointerCapture(e.pointerId);e.preventDefault();meshRender();};
meshSvg.onpointermove=e=>{if(!meshGesture)return;const p=meshPoint(e),g=meshGesture;try{const moved=moveSharedNodes(g.regions,constrainToOutline(siteDraft.outline,g.points.map(from=>({from,to:[from[0]+p[0]-g.start[0],from[1]+p[1]-g.start[1]]}))));if(!withinOutline(moved,siteDraft.outline))throw Error('현장 외곽선 안에서 조절해주세요.');meshRegions=moved;$('meshStatus').textContent='공유 경계와 이웃 영역을 함께 조절했습니다. 저장 전 되돌릴 수 있습니다.';meshRender();}catch(error){$('meshStatus').textContent=error.message;}};
meshSvg.onpointerup=e=>{if(meshGesture){const nameClick=meshGesture.nodeIndex===null&&Math.hypot(e.clientX-meshGesture.screenX,e.clientY-meshGesture.screenY)<6;if(JSON.stringify(meshRegions)!==JSON.stringify(meshGesture.regions))meshRemember(meshGesture.regions);if(meshGesture.nodeIndex!==null)meshNode=nodeKey(meshRegion().points[meshGesture.nodeIndex]);meshGesture=null;meshRender();if(nameClick)showMeshName(e.clientX,e.clientY);}};meshSvg.onpointercancel=()=>{if(meshGesture){meshRegions=meshGesture.regions;meshGesture=null;meshRender();}};
$('meshAddPoint').onclick=()=>{meshInsert=!meshInsert;meshRender();$('meshStatus').textContent=meshInsert?'선택 영역의 경계 가까이를 누르면 점을 추가합니다. 다시 누르면 취소합니다.':'점 추가 모드를 취소했습니다.';};
$('meshDeletePoint').onclick=()=>{try{const next=removeSharedPoint(meshRegions,meshNode);meshRemember();meshRegions=next;meshNode=null;meshRender();}catch(error){$('meshStatus').textContent=error.message;}};
$('meshUndo').onclick=()=>{const previous=meshHistory.pop();if(previous){meshRegions=previous;meshNode=null;meshInsert=false;meshRender();}};
$('meshDeleteRegion').onclick=()=>{if(!meshSelected||!confirm('선택 영역을 삭제하고 맞닿은 이웃에 공간을 합칠까요?'))return;try{const next=mergeDeletedRegion(meshRegions,meshSelected);meshRemember();meshRegions=next;meshSelected=next[0]?.id||null;meshNode=null;meshRender();}catch(error){$('meshStatus').textContent=error.message;}};
for(const [id,field]of [['meshName','name'],['meshAliases','aliases']]){let before;$ (id).onfocus=()=>before=structuredClone(meshRegions);$(id).oninput=()=>{const r=meshRegion();if(r)r[field]=field==='name'?$(id).value:$(id).value.split(',').map(v=>v.trim()).filter(Boolean);meshRender();};$(id).onchange=()=>{if(before&&JSON.stringify(before)!==JSON.stringify(meshRegions))meshRemember(before);meshRender();};}
$('meshCancel').onclick=()=>$('regionEditorDialog').close();$('regionEditorDialog').addEventListener('cancel',e=>{if(meshInsert){e.preventDefault();meshInsert=false;meshRender();$('meshStatus').textContent='점 추가 모드를 취소했습니다.';}else if(meshGesture){e.preventDefault();meshRegions=meshGesture.regions;meshGesture=null;meshRender();}});
$('meshSave').onclick=async()=>{try{const next=await api('/api/site',{site:{...siteDraft,regions:meshRegions.map(r=>({...r,seed:regionPoint(r)}))},revision:meshRevision});site=next;siteDraft=structuredClone(next);renderSite();$('regionEditorDialog').close();toast('영역 설정을 저장했습니다.');}catch(error){$('meshStatus').textContent=error.message;}};

$('personalZoomOut').onclick=()=>$('zoomOut').click();$('personalZoomIn').onclick=()=>$('zoomIn').click();$('personalAreaZoom').onclick=()=>{if(mode==='zoom'){cancelAreaZoom();selectMode('pan');return;}stopActiveTool('zoom');selectMode('zoom');if(!$('sidePanel').hidden)panel(false);toast('내 화면에서 확대할 구간을 드래그하세요. 다른 화면은 바뀌지 않습니다.');};
$('penWidth').value=penWidth;$('penWidthLabel').textContent=penWidth;
$('penWidth').oninput=()=>{penWidth=Number($('penWidth').value);$('penWidthLabel').textContent=penWidth;sessionStorage.setItem('mouseon-pen-width',String(penWidth));};

let worksNetworkTimer=null,worksNetworkLast=null,worksNetworkBusy=false;
let worksUnifiedBusy=false,worksPendingImport=false,worksAwaitLogin=false,worksLoginUntil=0,worksLocalProblem=false;let worksQueuedImport=false;
const worksProblemPhases=new Set(['login','unconfirmed','unsupported']);
function worksProblem(message,persist=true){if(persist)worksLocalProblem=true;$('worksNetworkStatus').textContent=message;$('worksQuickActions').classList.add('has-problem');$('worksConnectionSettings').hidden=false;$('worksUnifiedImport').textContent='다시 불러오기';}
function setWorksBusy(value){worksUnifiedBusy=value;for(const id of ['worksUnifiedImport','worksNetworkSource','worksDate'])$(id).disabled=value;}
function worksSourceHasDate(source,date){return Boolean(source&&(source.dates?.includes(date)||(source.coverage||[]).some(c=>c.from<=date&&c.until>=date)));}
function selectedWorksSource(){return worksNetworkLast?.sources?.find(source=>source.id===$('worksNetworkSource').value);}
function rememberWorksChoice(){const source=selectedWorksSource();if(source){$('worksCalendar').value=source.calendarName;localStorage.setItem('mouseon-works-calendar',source.calendarId||source.calendarName);}}
function drawNetworkDates(){const source=selectedWorksSource();$('worksNetworkDate').replaceChildren();for(const date of source?.dates||[]){const option=el('option','',date);option.value=date;$('worksNetworkDate').append(option);}if(source?.dates.includes($('worksDate').value))$('worksNetworkDate').value=$('worksDate').value;$('selectWorksNetwork').disabled=!source;}
function showWorksNetwork(value){
 worksNetworkLast=value;if(value.autoGroupCalendars!==true){worksPendingImport=false;worksProblem('이전 연동 실행기가 켜져 있습니다. MouseOn 실행 창과 연동 엣지를 모두 닫고 패치한 실행기로 다시 열어주세요.');return;}const sources=value.sources||[],select=$('worksNetworkSource'),previous=select.value||value.scope?.sourceId;
 const choices=[['','현장 캘린더 선택'],...sources.map(source=>[source.id,source.calendarName])];
 if(JSON.stringify([...select.options].map(option=>[option.value,option.textContent]))!==JSON.stringify(choices)){
  select.replaceChildren();for(const [id,name]of choices){const option=el('option','',name);option.value=id;select.append(option);}
 }
 const saved=localStorage.getItem('mouseon-works-calendar'),remembered=sources.find(source=>(source.calendarId||source.calendarName)===saved);
 select.value=sources.some(source=>source.id===previous)?previous:remembered?.id||(sources.length===1?sources[0].id:'');drawNetworkDates();
 const sync=$('syncLabel');if(sync){sync.hidden=!value.automatic;sync.textContent=value.lastRead?'일정 갱신 '+new Date(value.lastRead).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'}):'일정 수집 중';}
 const problem=worksProblemPhases.has(value.phase)||Boolean(value.automatic&&value.automaticApply?.enabled===false);
 if(problem){worksPendingImport=false;worksProblem(value.message||value.automaticApply?.message||'로그인과 연결 상태를 확인해주세요.',false);}
 else if(!worksLocalProblem){
  $('worksQuickActions').classList.remove('has-problem');$('worksConnectionSettings').hidden=true;$('worksConnectionSettings').open=false;
  $('worksNetworkStatus').textContent=value.automatic?(value.lastRead?'자동 갱신 중 · '+(value.automaticApply?.message||'방금 반영')+(value.automaticSave?' · '+value.automaticSave.message:''):'일정을 불러오고 있습니다…'):sources.length?'캘린더와 작업 날짜를 선택해주세요.':worksPendingImport&&!worksAwaitLogin?'일정 내용을 읽고 있습니다… 로그인된 엣지 창을 유지해주세요.':worksAwaitLogin?'엣지에서 로그인해주세요. 로그인 후 자동으로 연결합니다.':'처음 연결할 때 엣지에서 로그인해주세요.';
  $('worksUnifiedImport').textContent=value.automatic?'지금 갱신':sources.length?'불러오기':'연결하고 불러오기';
 }
 if(worksPendingImport&&sources.length&&!worksUnifiedBusy){
  if(worksSourceHasDate(selectedWorksSource(),$('worksDate').value))queueMicrotask(()=>{if(!worksUnifiedBusy&&worksPendingImport){worksPendingImport=false;void importSelectedWorks();}});
  else{$('worksNetworkStatus').textContent=selectedWorksSource()?'선택한 날짜의 캘린더 화면을 확인하고 있습니다…':'현장 캘린더를 선택해주세요. 선택하면 바로 불러옵니다.';}
 }
}
async function importSelectedWorks(){
 const source=selectedWorksSource(),date=$('worksDate').value;
 if(!source){worksPendingImport=true;$('worksNetworkStatus').textContent='현장 캘린더를 선택해주세요.';return;}
 if(!worksSourceHasDate(source,date)){if(!worksNetworkLast.canReadScreen){worksProblem('선택한 날짜의 일정이 없습니다. 엣지 캘린더의 조회 기간과 작업 날짜를 확인해주세요. 기존 작업은 유지합니다.');return;}worksPendingImport=true;setWorksBusy(true);try{showWorksNetwork(await api('/api/works/network/start',{date}));watchWorksNetwork();}catch(error){worksPendingImport=false;worksProblem(error.message);}finally{setWorksBusy(false);if(worksPendingImport&&worksSourceHasDate(selectedWorksSource(),date)){worksPendingImport=false;void importSelectedWorks();}}return;}
 worksPendingImport=false;setWorksBusy(true);worksLocalProblem=false;rememberWorksChoice();
 try{const value=await api('/api/works/network/select',{sourceId:source.id,date,intervalSeconds:10,autoApply:true,includeFuture:true});showWorksNetwork(value);chooseDates([date]);if(room&&!isTop())send({type:'top'});watchWorksNetwork();}
 catch(error){worksProblem(error.message);}finally{setWorksBusy(false);}
}
async function pollWorksNetwork(){
 if(worksNetworkBusy||worksUnifiedBusy)return;worksNetworkBusy=true;
 try{
  if(worksAwaitLogin){
   if(Date.now()>worksLoginUntil){worksAwaitLogin=false;worksPendingImport=false;worksProblem('로그인 대기 시간이 지났습니다. 엣지에서 로그인한 뒤 다시 불러오기를 눌러주세요.');return;}
   try{const value=await api('/api/works/network/start',{date:$('worksDate').value});worksAwaitLogin=false;showWorksNetwork(value);}catch{$('worksNetworkStatus').textContent='엣지에서 로그인해주세요. 로그인 후 자동으로 연결합니다.';}
  }else showWorksNetwork(await api('/api/works/network/status'));
 }catch(error){worksPendingImport=false;worksProblem(error.message);clearInterval(worksNetworkTimer);worksNetworkTimer=null;}
 finally{worksNetworkBusy=false;if(worksQueuedImport){worksQueuedImport=false;void connectAndImportWorks();}}
}
function watchWorksNetwork(){clearInterval(worksNetworkTimer);worksNetworkTimer=setInterval(pollWorksNetwork,3000);}
async function connectAndImportWorks(){
 if(worksUnifiedBusy)return;if(worksNetworkBusy){worksQueuedImport=true;$('worksNetworkStatus').textContent='연결 확인 후 바로 불러옵니다…';return;}
 if(selectedWorksSource()&&!worksProblemPhases.has(worksNetworkLast?.phase)){await importSelectedWorks();return;}
 setWorksBusy(true);worksLocalProblem=false;worksPendingImport=true;$('worksNetworkStatus').textContent='연결을 확인하고 있습니다…';
 try{
  let value;try{value=await api('/api/works/network/start',{date:$('worksDate').value});}catch{
   await api('/api/works/open',{browser:'edge'});worksAwaitLogin=true;worksLoginUntil=Date.now()+120000;watchWorksNetwork();$('worksNetworkStatus').textContent='엣지에서 로그인해주세요. 로그인 후 자동으로 연결합니다.';return;
  }
  worksUnifiedBusy=false;showWorksNetwork(value);watchWorksNetwork();
 }catch(error){worksPendingImport=false;worksProblem(error.message);}
 finally{setWorksBusy(false);}
}
$('worksNetworkSource').onchange=()=>{drawNetworkDates();rememberWorksChoice();if(worksPendingImport&&selectedWorksSource()){worksPendingImport=false;void importSelectedWorks();}};
$('worksDate').addEventListener('change',drawNetworkDates);
$('startWorksNetwork').onclick=connectAndImportWorks;
$('selectWorksNetwork').onclick=()=>importSelectedWorks();
$('stopWorksNetwork').onclick=async()=>{worksPendingImport=false;worksAwaitLogin=false;worksLocalProblem=false;try{showWorksNetwork(await api('/api/works/network/stop',{}));clearInterval(worksNetworkTimer);worksNetworkTimer=null;$('worksNetworkStatus').textContent='자동 갱신을 중지했습니다.';}catch(error){worksProblem(error.message);}};
$('saveWorksNetworkDiagnostic').onclick=()=>{if(!worksNetworkLast){toast('먼저 연결하고 불러오기를 실행해주세요.');return;}downloadJSON({format:'mouseon-network-diagnostic/v1',phase:worksNetworkLast.phase,diagnostic:worksNetworkLast.diagnostic,sources:(worksNetworkLast.sources||[]).map(source=>({id:source.id,method:source.method,count:source.count,dateCount:source.dates.length}))},'works-network-diagnostic.json');};


function hoverInkAuthor(e){
 const tooltip=$('inkAuthor');if(mobileView()||e.pointerType!=='mouse'||gesture||viewGesture||picking||regionPicking||regionTransforming||e.target.closest('.marker')){tooltip.hidden=true;return;}
 const rect=$('scene').getBoundingClientRect(),x=e.clientX-rect.left,y=e.clientY-rect.top;let found=null;
 for(let i=(room?.strokes.length||0)-1;i>=0&&!found;i--){const stroke=room.strokes[i],threshold=(stroke.width||3)/2+5;for(let j=0;j<stroke.points.length;j++){const a=stroke.points[j],b=stroke.points[j+1]||a,ax=a[0]*rect.width,ay=a[1]*rect.height,dx=(b[0]-a[0])*rect.width,dy=(b[1]-a[1])*rect.height,d=dx*dx+dy*dy,t=d?Math.max(0,Math.min(1,((x-ax)*dx+(y-ay)*dy)/d)):0;if(Math.hypot(x-ax-t*dx,y-ay-t*dy)<=threshold){found=stroke;break;}}}
 tooltip.hidden=!found;if(found){tooltip.textContent=found.person||'작성자 정보 없음';tooltip.style.left=Math.max(8,Math.min(e.clientX+12,innerWidth-220))+'px';tooltip.style.top=Math.max(8,Math.min(e.clientY+16,innerHeight-45))+'px';tooltip.style.borderColor=found.color;}
}
$('scene').addEventListener('pointerleave',()=>$('inkAuthor').hidden=true);

function showMeshName(x,y){const popover=$('meshNamePopover');popover.hidden=false;const width=Math.min(280,innerWidth-16);popover.style.width=width+'px';popover.style.left=Math.max(8,Math.min(x+12,innerWidth-width-8))+'px';popover.style.top=Math.max(8,Math.min(y+12,innerHeight-70))+'px';$('meshName').value=meshRegion()?.name||'';if(matchMedia('(pointer:fine)').matches){$('meshName').focus();$('meshName').select();}}
$('meshNameDone').onclick=()=>{$('meshName').blur();$('meshNamePopover').hidden=true;meshRender();};
$('meshName').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('meshNameDone').click();}if(e.key==='Escape'){e.preventDefault();e.stopPropagation();$('meshNameDone').click();}});

$('siteFont').onchange=()=>{siteDraft.font=$('siteFont').value;document.documentElement.dataset.siteFont=siteDraft.font;updateSiteSaveStatus();};

let wizardEditBase=null,wizardOutlineBase=null,wizardCellNode=null,wizardCellInsert=false,wizardLastTap=null;
let wizardStep=1,wizardOutline=[],wizardRegions=[],wizardSelected=null,wizardAcceptedOutline='',wizardRevision=0,wizardBase=null;let wizardInsertMode=false,outlineSelection=null,outlineHistory=[],wizardLoadedOutline=false,wizardDrawingRegion=false,wizardRegionDraft=[];
const wizardSvg=$('wizardSvg');
let wizardEditing=false,wizardCellHistory=[],wizardDraftHistory=[],wizardDraftNode=null,wizardDraftAdding=true;
function rememberCell(){wizardCellHistory.push(structuredClone(wizardRegions));if(wizardCellHistory.length>50)wizardCellHistory.shift();}
function rememberDraft(){wizardDraftHistory.push(structuredClone(wizardRegionDraft));if(wizardDraftHistory.length>160)wizardDraftHistory.shift();}
function resetFloatingPosition(element){delete element.dataset.userPosition;}
function wizardDot(p,attribute,index,selected=false){const dot=document.createElementNS(wizardSvg.namespaceURI,'ellipse');dot.setAttribute('cx',p[0]*1000);dot.setAttribute('cy',p[1]*1000);dot.dataset[attribute]=String(index);dot.classList.add('edit-point');dot.classList.toggle('selected',selected);sizeWizardDot(dot,false);return dot;}
function sizeWizardDot(dot,near){const rect=wizardSvg.getBoundingClientRect(),radius=near?6:2.6;dot.setAttribute('rx',radius*1000/Math.max(1,rect.width));dot.setAttribute('ry',radius*1000/Math.max(1,rect.height));dot.classList.toggle('near',near);}
function nearestWizardDot(e){let nearest=null,distance=e.pointerType==='touch'?24:14;for(const dot of wizardSvg.querySelectorAll('.edit-point')){const rect=dot.getBoundingClientRect(),d=Math.hypot(e.clientX-rect.x-rect.width/2,e.clientY-rect.y-rect.height/2);if(d<distance){nearest=dot;distance=d;}}return nearest;}

function wizardFit(){wizardPhotoView.fit();}
function wizardPoint(e){const r=wizardSvg.getBoundingClientRect();return [Math.max(0,Math.min(1,(e.clientX-r.x)/r.width)),Math.max(0,Math.min(1,(e.clientY-r.y)/r.height))];}
function wizardRender(keepName=false){
 const outline=wizardStep===1,selected=wizardRegions.find(r=>r.id===wizardSelected);
 $('wizardStepTitle').textContent=outline?'현장 외곽선 편집':'현장 영역 편집';
 $('wizardPrev').hidden=false;$('wizardPrev').classList.toggle('active',outline);$('wizardPrev').setAttribute('aria-pressed',String(outline));$('wizardPrev').disabled=wizardDrawingRegion;
 $('wizardUndoPoint').hidden=$('wizardResetOutline').hidden=!outline;$('wizardAddRegion').hidden=outline;$('wizardSave').hidden=outline||wizardDrawingRegion;$('wizardOutlineActions').hidden=!outline;$('wizardNext').hidden=!outline;
 if(!keepName){$('wizardNamePopover').hidden=true;$('wizardRegionActions').hidden=true;}
 $('outlinePointTools').hidden=true;$('wizardInsertPoint').hidden=!outline;$('wizardDrawRegion').hidden=outline;

 $('wizardInsertPoint').classList.toggle('active',wizardInsertMode);$('wizardDrawRegion').classList.toggle('active',wizardDrawingRegion);
 $('wizardCancelRegion').hidden=!wizardDrawingRegion;$('wizardDraftPopover').hidden=!wizardDrawingRegion;$('wizardDraftName').hidden=true;
 $('wizardFinishRegion').hidden=!wizardDrawingRegion||wizardRegionDraft.length<3;$('wizardAddRegion').disabled=wizardDrawingRegion;$('wizardDeleteRegion').hidden=true;
 $('wizardDraftUndo').disabled=!wizardRegionDraft.length&&!wizardDraftHistory.length;$('wizardDraftDelete').disabled=wizardDraftNode===null;$('wizardDraftAdd').classList.toggle('active',wizardDraftAdding);
 $('wizardStartEdit').hidden=$('wizardContextDraw').hidden=wizardEditing;$('wizardStartEdit').disabled=!selected;
 for(const id of ['wizardEditDone','wizardEditCancel','wizardCellAddPoint','wizardCellDeletePoint','wizardCellUndo','wizardDeleteRegionNear']){$(id).hidden=!wizardEditing;$(id).disabled=!selected;}
 $('wizardCellUndo').disabled=!selected||!wizardCellHistory.length;$('wizardCellDeletePoint').disabled=!selected||wizardCellNode===null;$('wizardCellAddPoint').classList.toggle('active',wizardCellInsert);
 $('wizardStatus').textContent=outline?'현장 외곽을 찍거나 점을 끌어 조절하세요.':wizardEditing?'영역을 선택한 뒤 점을 조절하세요. 이름은 더블클릭으로 수정합니다.':`영역 ${wizardRegions.length}개 · 영역을 누르면 근처에 도구 메뉴가 열립니다.`;
 wizardSvg.replaceChildren();const ns=wizardSvg.namespaceURI;
 if(wizardOutline.length>=3){const outside=document.createElementNS(ns,'path');outside.setAttribute('d','M0 0H1000V1000H0Z M'+wizardOutline.map(p=>p.map(v=>v*1000).join(' ')).join('L')+'Z');outside.setAttribute('fill-rule','evenodd');outside.setAttribute('fill','#e6ece3');outside.setAttribute('fill-opacity','.24');outside.style.pointerEvents='none';wizardSvg.append(outside);}
 for(const r of (outline?[{points:wizardOutline}]:wizardRegions)){
  if(!r.points.length)continue;const poly=document.createElementNS(ns,r.pieces?'path':'polygon');
  if(r.pieces){poly.setAttribute('d',regionPath(r));poly.setAttribute('fill-rule','evenodd');}else poly.setAttribute('points',r.points.map(p=>p.map(v=>v*1000).join(',')).join(' '));
  if(r.id){poly.dataset.wizardRegion=r.id;poly.classList.toggle('selected',r.id===wizardSelected);}wizardSvg.append(poly);
  if(r.id){const pos=r.labelPosition||regionPoint(r),text=document.createElementNS(ns,'text');text.setAttribute('x',pos[0]*1000);text.setAttribute('y',pos[1]*1000);text.dataset.wizardLabel=r.id;text.textContent=r.name||'이름 입력';wizardSvg.append(text);}
 }
 if(!outline&&selected&&wizardEditing&&!wizardDrawingRegion)regionRings(selected).flat().forEach((p,index)=>wizardSvg.append(wizardDot(p,'cellPoint',index,nodeKey(p)===wizardCellNode)));
 if(outline)wizardOutline.forEach((p,index)=>wizardSvg.append(wizardDot(p,'outlinePoint',index,index===outlineSelection)));
 if(wizardDrawingRegion){$('wizardStatus').textContent=wizardDraftAdding?'점을 연속으로 찍으세요. 기존 점은 끌어 수정할 수 있습니다.':'점을 선택해 수정하거나 +로 점을 더 찍으세요.';
  if(wizardRegionDraft.length){const polygon=document.createElementNS(ns,wizardRegionDraft.length>=3?'polygon':'polyline');polygon.classList.add('building-draft');polygon.setAttribute('points',wizardRegionDraft.map(p=>p.map(v=>v*1000).join(',')).join(' '));polygon.style.pointerEvents='none';wizardSvg.append(polygon);wizardRegionDraft.forEach((p,index)=>wizardSvg.append(wizardDot(p,'draftPoint',index,index===wizardDraftNode)));}
 }
}
function openSiteWizard(id=null,anchor=null){if(!isTop()){toast('현장 전경에서 설정해주세요.');return;}if(hasRegionPointDraft()){toast('진행 중인 경계 찍기를 먼저 반영하거나 취소해주세요.');return;}wizardBase=structuredClone(siteDraft);wizardRevision=site.revision;wizardOutline=structuredClone(siteDraft.outline||[]);wizardAcceptedOutline=JSON.stringify(wizardOutline);wizardRegions=structuredClone(siteDraft.regions);wizardStep=wizardOutline.length>=3?2:1;wizardSelected=typeof id==='string'?id:null;wizardEditBase=null;wizardCellNode=null;wizardCellInsert=false;wizardLastTap=null;wizardEditing=false;wizardCellHistory=[];wizardDraftHistory=[];wizardDraftNode=null;wizardDraftAdding=true;for(const name of ['wizardRegionActions','wizardDraftPopover','wizardOutlineActions','outlinePointTools'])resetFloatingPosition($(name));wizardLastDrag=null;wizardDrag=null;wizardOutlineBase={outline:structuredClone(wizardOutline),regions:structuredClone(wizardRegions)};wizardInsertMode=false;outlineSelection=null;outlineHistory=[];wizardLoadedOutline=wizardOutline.length>=3;wizardDrawingRegion=false;wizardRegionDraft=[];$('wizardImage').src=$('background').src;$('siteWizardDialog').showModal();wizardPhotoView.reset();wizardRender();if(anchor&&wizardSelected)selectEditorRegion(wizardSelected,anchor.x,anchor.y);}
function placeNear(element,x,y,width=300){
 element.hidden=false;element.style.width='max-content';element.style.maxWidth='calc(100vw - 16px)';
 const rect=element.getBoundingClientRect(),offset=28;
 const left=element.dataset.userPosition?rect.left:x+offset,top=element.dataset.userPosition?rect.top:y+offset;
 element.style.left=Math.max(8,Math.min(left,innerWidth-rect.width-8))+'px';element.style.top=Math.max(8,Math.min(top,innerHeight-rect.height-8))+'px';
}
function showRegionActions(x,y){$('wizardCellDeletePoint').disabled=wizardCellNode===null;placeNear($('wizardRegionActions'),x,y);}
function selectEditorRegion(id,x,y,rename=false){if(wizardSelected!==id||!wizardEditBase){wizardEditBase=structuredClone(wizardRegions);wizardCellNode=null;wizardCellHistory=[];wizardEditing=false;}wizardSelected=id;if(rename)wizardEditing=true;wizardRender();showRegionActions(x,y);if(rename)wizardEditName(id,x,y);}
function wizardEditName(id,x,y){wizardSelected=id;if(!wizardEditBase)wizardEditBase=structuredClone(wizardRegions);$('wizardNamePopover').hidden=false;$('wizardName').value=wizardRegions.find(r=>r.id===id)?.name||'';showRegionActions(x,y);if(matchMedia('(pointer:fine)').matches){$('wizardName').focus();$('wizardName').select();}}
function finishRegionEdit(cancel=false){if(cancel&&wizardEditBase)wizardRegions=wizardEditBase;wizardEditBase=null;wizardSelected=null;wizardCellNode=null;wizardCellInsert=false;wizardCellHistory=[];wizardEditing=false;wizardRender();}
$('wizardStartEdit').onclick=()=>{if(!wizardSelected)return;const rect=$('wizardRegionActions').getBoundingClientRect();wizardEditing=true;wizardRender(true);placeNear($('wizardRegionActions'),rect.left-28,rect.top-28);};
$('wizardContextDraw').onclick=e=>{const anchor=$('wizardRegionActions').getBoundingClientRect();$('wizardDrawRegion').onclick({clientX:anchor.left,clientY:anchor.top});};
$('wizardCellUndo').onclick=()=>{wizardCellInsert=false;const previous=wizardCellHistory.pop();if(previous)wizardRegions=previous;wizardCellNode=null;wizardRender(true);};
$('wizardEditDone').onclick=()=>finishRegionEdit();$('wizardEditCancel').onclick=()=>finishRegionEdit(true);
$('wizardDeleteRegionNear').onclick=()=>$('wizardDeleteRegion').click();
$('wizardCellAddPoint').onclick=()=>{wizardCellInsert=!wizardCellInsert;$('wizardCellAddPoint').classList.toggle('active',wizardCellInsert);$('wizardStatus').textContent=wizardCellInsert?'새 점을 놓을 위치를 누르세요. 누른 위치에 맞춰 영역 모양이 바뀝니다.':'점 추가를 취소했습니다.';};
$('wizardCellDeletePoint').onclick=()=>{try{if(!wizardCellNode)return;const r=wizardRegions.find(r=>r.id===wizardSelected);const shape=mapRegionRings(r,ring=>ring.filter(p=>nodeKey(p)!==wizardCellNode));const next=reshapeSiteRegion(wizardOutline,wizardRegions,wizardSelected,shape);rememberCell();wizardRegions=next;wizardCellNode=null;wizardRender(true);$('wizardCellDeletePoint').disabled=true;}catch(error){$('wizardStatus').textContent=error.message;}};
$('siteWizardButton').onclick=()=>openSiteWizard();$('wizardImage').onload=wizardFit;window.addEventListener('resize',wizardFit);
$('wizardMenu').onclick=()=>$('wizardTools').hidden=!$('wizardTools').hidden;
function rememberOutline(value=wizardOutline){outlineHistory.push(structuredClone(value));if(outlineHistory.length>50)outlineHistory.shift();}
$('wizardUndoPoint').onclick=()=>{if(wizardDrawingRegion)wizardRegionDraft.pop();else{const previous=outlineHistory.pop();if(previous)wizardOutline=previous;else wizardOutline.pop();outlineSelection=null;}wizardRender();};
$('wizardResetOutline').onclick=()=>{rememberOutline();wizardOutline=[];wizardLoadedOutline=false;outlineSelection=null;wizardRender();};
$('wizardInsertPoint').onclick=()=>{wizardInsertMode=!wizardInsertMode;wizardRender();if(wizardInsertMode)$('wizardStatus').textContent='점을 추가할 경계선을 누르세요.';};
function outlineEdgeAt(e){if(wizardOutline.length<3)return null;const box=wizardSvg.getBoundingClientRect(),x=e.clientX-box.x,y=e.clientY-box.y;let best=null;for(let i=0;i<wizardOutline.length;i++){const a=wizardOutline[i],b=wizardOutline[(i+1)%wizardOutline.length],ax=a[0]*box.width,ay=a[1]*box.height,dx=(b[0]-a[0])*box.width,dy=(b[1]-a[1])*box.height,d=dx*dx+dy*dy;if(d<1)continue;const t=Math.max(.02,Math.min(.98,((x-ax)*dx+(y-ay)*dy)/d)),distance=Math.hypot(x-ax-t*dx,y-ay-t*dy);if(distance<=16&&(!best||distance<best.distance))best={index:i,distance,point:[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t]};}return best;}
function showOutlineTools(index,x,y){outlineSelection=index;wizardRender();const pop=$('outlinePointTools');placeNear(pop,x,y);$('deleteOutlinePoint').disabled=false;}
$('deleteOutlinePoint').onclick=()=>{if(outlineSelection===null)return;rememberOutline();wizardOutline.splice(outlineSelection,1);outlineSelection=null;wizardRender();};
wizardSvg.onclick=e=>{if(!editorInputAllowed(e))return;if(wizardLastDrag){const last=wizardLastDrag;wizardLastDrag=null;if(Math.hypot(e.clientX-last.x,e.clientY-last.y)<6)return;}if(e.target.closest('.edit-point'))return;
 if(wizardStep===1){if(wizardOutline.length>=160){$('wizardStatus').textContent='외곽선은 최대 160점입니다.';return;}const edge=outlineEdgeAt(e);if(edge){rememberOutline();wizardOutline.splice(edge.index+1,0,edge.point);showOutlineTools(edge.index+1,e.clientX,e.clientY);return;}if((wizardInsertMode||wizardLoadedOutline)&&wizardOutline.length>=3){$('outlinePointTools').hidden=true;$('wizardStatus').textContent='경계선을 눌러 점을 추가하거나, 기존 점을 끌어 이동하세요.';return;}rememberOutline();wizardOutline.push(wizardPoint(e));wizardRender();placeNear($('wizardOutlineActions'),e.clientX,e.clientY,260);return;}
 if(wizardDrawingRegion){if(wizardRegionDraft.length>=160){$('wizardStatus').textContent='건물 경계는 최대 160점입니다.';return;}if(!wizardDraftAdding)return;const p=latchRegionPoint(wizardOutline,wizardRegions,null,wizardPoint(e),wizardSvg.getBoundingClientRect()),next=[...wizardRegionDraft,p];const existing=wizardRegionDraft.findIndex(q=>Math.hypot((q[0]-p[0])*wizardSvg.getBoundingClientRect().width,(q[1]-p[1])*wizardSvg.getBoundingClientRect().height)<=6);if(existing>=0){wizardDraftNode=existing;wizardRender();return;}if(next.length>=3&&meshProblem([{points:next}])){toast('선이 교차하거나 면이 접히지 않도록 점을 조정해주세요.');return;}rememberDraft();wizardRegionDraft=next;wizardDraftNode=next.length-1;wizardRender();placeNear($('wizardDraftPopover'),e.clientX,e.clientY);return;}
 const region=e.target.closest('[data-wizard-region],[data-wizard-label]');if(region){const now=performance.now(),id=region.dataset.wizardRegion||region.dataset.wizardLabel,twice=wizardLastTap?.id===id&&now-wizardLastTap.time<350;wizardLastTap={id,time:now};selectEditorRegion(id,e.clientX,e.clientY,twice);}else{finishRegionEdit();showRegionActions(e.clientX,e.clientY);}
};
$('wizardDrawRegion').onclick=e=>{const start=!wizardDrawingRegion;finishRegionEdit();wizardDrawingRegion=start;wizardRegionDraft=[];wizardDraftHistory=[];wizardDraftNode=null;wizardDraftAdding=true;resetFloatingPosition($('wizardDraftPopover'));wizardRender();if(start)placeNear($('wizardDraftPopover'),e.clientX,e.clientY);};
$('wizardDraftUndo').onclick=()=>{wizardDraftAdding=false;const before=wizardDraftHistory.pop();wizardRegionDraft=before||wizardRegionDraft.slice(0,-1);wizardDraftNode=null;wizardRender();};
$('wizardDraftAdd').onclick=()=>{wizardDraftAdding=!wizardDraftAdding;wizardRender();};
$('wizardDraftDelete').onclick=()=>{if(wizardDraftNode===null)return;rememberDraft();wizardRegionDraft.splice(wizardDraftNode,1);wizardDraftNode=null;wizardRender();};
$('wizardCancelRegion').onclick=()=>{wizardDrawingRegion=false;wizardRegionDraft=[];wizardDraftHistory=[];wizardDraftNode=null;wizardRender();};
$('wizardFinishRegion').onclick=()=>{try{const before=structuredClone(wizardRegions),id=crypto.randomUUID();wizardRegions=insertManualRegion(wizardOutline,wizardRegions,wizardRegionDraft,id);wizardSelected=id;wizardEditBase=before;wizardCellHistory=[];wizardEditing=true;wizardDrawingRegion=false;wizardRegionDraft=[];wizardDraftHistory=[];wizardRender();const rect=wizardSvg.getBoundingClientRect(),p=regionPoint(wizardRegions.find(r=>r.id===id));showRegionActions(rect.x+p[0]*rect.width,rect.y+p[1]*rect.height);}catch(error){$('wizardStatus').textContent=error.message;}};
$('wizardName').oninput=()=>{const r=wizardRegions.find(r=>r.id===wizardSelected);if(r)r.name=$('wizardName').value;wizardRender(true);};$('wizardNameDone').onclick=()=>{$('wizardName').blur();$('wizardNamePopover').hidden=true;};$('wizardName').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();$('wizardNameDone').click();}};
$('wizardNext').onclick=async()=>{try{validateOutline(wizardOutline);const clip=globalThis.polygonClipping;const regions=[];for(const r of wizardRegions){const pieces=clip.intersection(regionPieces(r),[wizardOutline]);if(pieces.length)regions.push(withPieces(r,pieces));}wizardRegions=regions.length?conformRegions(regions):addSiteRegion(wizardOutline,[],crypto.randomUUID());if(!validMesh(wizardRegions))throw Error('외곽선과 내부 경계를 확인해주세요.');const saved=await api('/api/site',{site:{...wizardBase,outline:wizardOutline,regions:wizardRegions},revision:wizardRevision});site=saved;siteDraft=structuredClone(saved);wizardRevision=saved.revision;wizardBase=structuredClone(saved);wizardAcceptedOutline=JSON.stringify(wizardOutline);wizardLoadedOutline=true;wizardStep=2;outlineSelection=null;wizardSelected=null;wizardEditBase=null;wizardRender();renderSite();$('wizardStatus').textContent='외곽선을 저장했습니다. 이제 같은 화면에서 내부 영역을 편집하세요.';}catch(error){$('wizardStatus').textContent=error.message;}};
$('wizardPrev').onclick=()=>{if(wizardStep===1){$('wizardCancelOutline').click();return;}finishRegionEdit();wizardOutlineBase={outline:structuredClone(wizardOutline),regions:structuredClone(wizardRegions)};wizardStep=1;wizardRender();};
$('wizardCancelOutline').onclick=()=>{if(wizardOutlineBase){wizardOutline=structuredClone(wizardOutlineBase.outline);wizardRegions=structuredClone(wizardOutlineBase.regions);}if(wizardOutline.length<3){$('siteWizardDialog').close();return;}wizardStep=2;wizardRender();};
$('wizardDeleteRegion').onclick=()=>{try{if(!wizardSelected)return;wizardRegions=mergeDeletedRegion(wizardRegions,wizardSelected);wizardSelected=null;wizardEditBase=null;wizardCellNode=null;wizardRender();$('wizardStatus').textContent='선택 영역을 삭제하고 이웃 영역에 합쳤습니다.';}catch(error){$('wizardStatus').textContent=error.message;}};
$('wizardAddRegion').onclick=()=>{try{finishRegionEdit();const previous=structuredClone(wizardRegions);const id=crypto.randomUUID();wizardRegions=addSiteRegion(wizardOutline,wizardRegions,id);wizardEditBase=previous;wizardSelected=id;wizardRender();const point=regionPoint(wizardRegions.find(r=>r.id===id)),rect=wizardSvg.getBoundingClientRect();wizardEditing=true;wizardRender();showRegionActions(rect.x+point[0]*rect.width,rect.y+point[1]*rect.height);}catch(error){$('wizardStatus').textContent=error.message;}};
$('wizardCancel').onclick=()=>$('siteWizardDialog').close();
$('wizardSave').onclick=async()=>{try{if(wizardDrawingRegion)throw Error('그리는 영역을 먼저 완성하거나 취소해주세요.');$('wizardSave').disabled=true;const saved=await api('/api/site',{site:{...wizardBase,outline:wizardOutline,regions:wizardRegions},revision:wizardRevision});site=saved;siteDraft=structuredClone(saved);renderSite();$('siteWizardDialog').close();toast('현장 외곽선과 영역을 저장했습니다.');}catch(error){$('wizardStatus').textContent=error.message;}finally{$('wizardSave').disabled=false;}};
// Once an outline exists, adding a region recomputes its neighbors immediately.
$('addRegionBox').onclick=()=>{if(!siteDraft.outline?.length){openSiteWizard();return;}try{siteDraft.regions=addSiteRegion(siteDraft.outline,siteDraft.regions,crypto.randomUUID());renderSite();openMeshEditor(siteDraft.regions.at(-1).id);}catch(error){toast(error.message);}};
$('applyRegionCount').onclick=()=>{if(!siteDraft.outline?.length){openSiteWizard();return;}try{const count=Number($('regionCount').value);if(!Number.isInteger(count)||count<0||count>100)throw Error('영역 개수는 0~100개입니다.');if(count<siteDraft.regions.length&&!confirm('영역 개수를 줄일까요?'))return;while(siteDraft.regions.length<count)siteDraft.regions=addSiteRegion(siteDraft.outline,siteDraft.regions,crypto.randomUUID());while(siteDraft.regions.length>count)siteDraft.regions=mergeDeletedRegion(siteDraft.regions,siteDraft.regions.at(-1).id);renderSite();}catch(error){toast(error.message);}};
$('reflowRegions').onclick=()=>{openSiteWizard();};

const meshRail=el('nav');meshRail.id='meshToolRail';$('regionEditorDialog').append(meshRail);
for(const [id,icon,label]of [['meshUndo','↶','경계 편집 되돌리기'],['meshAddPoint','＋','점 추가'],['meshDeletePoint','−','선택 점 삭제'],['meshDeleteRegion','⌫','선택 영역 삭제']]){const button=$(id);button.textContent=icon;button.title=label;button.setAttribute('aria-label',label);meshRail.append(button);}


function renderHazards(){const hazards=siteDraft.hazards||defaultHazards();$('hazardList').replaceChildren();for(const h of hazards){const row=el('div','hazard-setting');const dot=el('span','hazard-dot','!');dot.style.background=h.color;const name=el('input');name.value=h.name;name.maxLength=80;name.setAttribute('aria-label','고위험 작업 이름');name.oninput=()=>{h.name=name.value;updateSiteSaveStatus();};const remove=el('button','','×');remove.setAttribute('aria-label',h.name+' 종류 삭제');remove.onclick=()=>{siteDraft.hazards=siteDraft.hazards.filter(x=>x.id!==h.id);renderHazards();updateSiteSaveStatus();};row.append(dot,name,remove);$('hazardList').append(row);}
 const select=$('taskIcon'),previous=select.value;for(const option of [...select.options])if(option.dataset.hazard||['formwork','rope'].includes(option.value))option.remove();for(const h of (site.hazards||defaultHazards())){const option=el('option','',h.name);option.dataset.hazard='true';option.value='hazard:'+h.id;select.append(option);}if([...select.options].some(o=>o.value===previous))select.value=previous;
}
$('addHazard').onclick=()=>{const name=$('newHazardName').value.trim();if(!name)return;if(siteDraft.hazards.length>=40){toast('작업 종류는 최대 40개입니다.');return;}siteDraft.hazards.push({id:crypto.randomUUID(),name,icon:'hazard',color:hazardColors[siteDraft.hazards.length%hazardColors.length]});$('newHazardName').value='';renderHazards();updateSiteSaveStatus();};

const chromeIcons={eraser:'m15 3 6 6-12 12H5l-4-4ZM7 11l6 6M9 21h12',qr:'M3 3h6v6H3ZM15 3h6v6h-6ZM3 15h6v6H3ZM15 13h2v4h4v4h-4M13 21v-6M21 13h-2',menu:'M4 6h16M4 12h16M4 18h16',pen:'m15 4 5 5M4 20l2-6L16 4a2 2 0 0 1 4 4L10 18Z',work:'M9 5H5v16h14V5h-4M9 3h6v4H9ZM8 12h8M12 9v6',photo:'M8 6l2-3h4l2 3h5v15H3V6ZM16 13a4 4 0 1 1-8 0 4 4 0 0 1 8 0',sync:'M20 8a8 8 0 0 0-14-3L3 8M3 3v5h5M4 16a8 8 0 0 0 14 3l3-3M16 16h5v5',gear:'m9 3-1 3-3 1-2 4 2 2v3l4 3 3-1 3 1 4-3v-3l2-2-2-4-3-1-1-3ZM15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0',full:'M9 3H3v6M15 3h6v6M21 15v6h-6M9 21H3v-6',more:'M5 12h.01M12 12h.01M19 12h.01',share:'M9 15 15 9M8 17l-1 1a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0M16 7l1-1a4 4 0 0 1 6 6l-5 5a4 4 0 0 1-6 0',close:'m6 6 12 12M18 6 6 18'};
function chromeIcon(name){const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');const path=document.createElementNS(svg.namespaceURI,'path');path.setAttribute('d',chromeIcons[name]);svg.append(path);return svg;}
function chromeButton(button,icon,text=null){if(!button)return;const label=button.getAttribute('aria-label')||button.title||button.textContent.trim();button.setAttribute('aria-label',label);button.title=label;button.replaceChildren(chromeIcon(icon));if(text)button.append(el('span','',text));}
chromeButton($('wizardStartEdit'),'pen','영역 수정');chromeButton($('wizardContextDraw'),'work','건물 영역 만들기');chromeButton($('menuToggle'),'menu');chromeButton($('fullScreen'),'full');chromeButton($('siteSettingsButton'),'gear');chromeButton($('menuClose'),'close');chromeButton($('railShare'),'qr');chromeButton($('mobilePhoto'),'photo');
for(const button of document.querySelectorAll('#toolRail [data-mode=draw],#mobileTools [data-mode=draw]'))chromeButton(button,'pen');
for(const [section,icon]of [['work','work'],['photo','photo'],['works','sync']])chromeButton(document.querySelector('#toolRail [data-section='+section+']'),icon);
const meetingStatus=el('div');meetingStatus.id='meetingStatus';meetingStatus.append($('led'),$('status'),$('presence'));const syncLabel=el('span');syncLabel.id='syncLabel';syncLabel.hidden=true;meetingStatus.append(syncLabel);$('workspace').append(meetingStatus);
$('mobilePhoto').onclick=chooseDetailPhoto;$('viewToolsToggle').onclick=()=>{const open=$('workspace').classList.toggle('view-tools-open');$('viewToolsToggle').setAttribute('aria-expanded',String(open));};
const advancedSite=document.createElement('details');advancedSite.id='siteAdvancedTools';advancedSite.append(el('summary','','세부 경계·백업'));$('sitePanel').insertBefore(advancedSite,$('siteSaveStatus'));$('sitePanel').insertBefore($('siteWizardButton'),$('hazardSettings'));for(const id of ['quickRegionSetup','regionName','regionAliases','pickRegion','saveRegion','cancelRegionEdit','regionList','discardSiteChanges','backupSite','restoreSite']){const element=$(id),container=element.closest('label');advancedSite.append(container||element);}
$('siteWizardButton').textContent='영역 설정';



let wizardDrag=null,wizardLastDrag=null;
wizardSvg.addEventListener('pointerdown',e=>{
 if(e.button!==0||!editorInputAllowed(e))return;const dot=nearestWizardDot(e),label=e.target.closest('[data-wizard-label]'),poly=e.target.closest('[data-wizard-region]');
 if(wizardStep===1&&dot?.dataset.outlinePoint!==undefined){outlineSelection=Number(dot.dataset.outlinePoint);wizardDrag={type:'outline',index:outlineSelection,before:structuredClone(wizardOutline)};}
 else if(wizardDrawingRegion&&dot?.dataset.draftPoint!==undefined){wizardDraftNode=Number(dot.dataset.draftPoint);wizardDrag={type:'draft',index:wizardDraftNode,before:structuredClone(wizardRegionDraft),snap:{}};}
 else if(!wizardDrawingRegion&&wizardStep===2&&wizardEditing){
  const selected=wizardRegions.find(r=>r.id===wizardSelected);if(!selected)return;
  if(label&&label.dataset.wizardLabel===wizardSelected){wizardCellNode=null;wizardDrag={type:'label',id:wizardSelected,before:structuredClone(wizardRegions),screen:[e.clientX,e.clientY]};}
  else{
   const flat=regionRings(selected).flat(),picked=dot?.dataset.cellPoint!==undefined?flat[Number(dot.dataset.cellPoint)]:null;
   if(!picked&&!wizardCellInsert&&poly?.dataset.wizardRegion!==wizardSelected)return;
   if(!wizardEditBase)wizardEditBase=structuredClone(wizardRegions);wizardCellNode=picked?nodeKey(picked):null;
   if(wizardCellInsert&&!picked){try{const added=addRegionPointAt(wizardOutline,wizardRegions,wizardSelected,wizardPoint(e),wizardSvg.getBoundingClientRect());rememberCell();wizardRegions=added.regions;wizardCellNode=nodeKey(added.point);wizardLastDrag={x:e.clientX,y:e.clientY};wizardRender(true);showRegionActions(e.clientX,e.clientY);}catch(error){$('wizardStatus').textContent=error.message;}e.preventDefault();e.stopImmediatePropagation();return;}
   $('wizardName').blur();wizardDrag={type:'cell',before:structuredClone(wizardRegions),id:wizardSelected,start:wizardPoint(e),screen:[e.clientX,e.clientY],points:picked?[picked]:flat,whole:!picked,snap:{}};
  }
 }else return;e.preventDefault();e.stopPropagation();wizardSvg.setPointerCapture(e.pointerId);
});
wizardSvg.addEventListener('pointermove',e=>{
 if(!wizardDrag){if(!editorInputAllowed(e))return;const nearest=nearestWizardDot(e);for(const dot of wizardSvg.querySelectorAll('.edit-point'))sizeWizardDot(dot,dot===nearest);return;}
 e.preventDefault();if(!editorInputAllowed(e))return;const p=wizardPoint(e),g=wizardDrag;
 if(g.type==='label'){if(Math.hypot(e.clientX-g.screen[0],e.clientY-g.screen[1])<4)return;wizardRegions.find(r=>r.id===g.id).labelPosition=p;wizardRender(true);return;}
 if(g.type==='outline'||g.type==='draft'){
  const before=g.type==='outline'?wizardOutline:wizardRegionDraft,next=structuredClone(before);next[g.index]=g.type==='outline'?p:latchRegionPoint(wizardOutline,wizardRegions,null,p,wizardSvg.getBoundingClientRect(),g.snap);
  const issue=next.length>=3?meshProblem([{points:next}]):null;if(issue){g.error=issue;return;}g.error=null;if(g.type==='outline')wizardOutline=next;else wizardRegionDraft=next;wizardRender(g.type==='draft');return;
 }
 if(Math.hypot(e.clientX-g.screen[0],e.clientY-g.screen[1])<4)return;
 try{
  const bounds=wizardSvg.getBoundingClientRect(),selected=g.before.find(r=>r.id===g.id),delta=[p[0]-g.start[0],p[1]-g.start[1]];
  if(g.whole){const snapped=latchRegionTranslation(wizardOutline,g.before,g.id,delta,bounds,g.snap);wizardRegions=translateSiteRegion(wizardOutline,g.before,g.id,snapped);}
  else{const from=g.points[0],target=latchRegionPoint(wizardOutline,g.before,g.id,[from[0]+delta[0],from[1]+delta[1]],bounds,g.snap),shape=mapRegionRings(selected,ring=>ring.map(point=>nodeKey(point)===nodeKey(from)?target:point));wizardRegions=reshapeSiteRegion(wizardOutline,g.before,g.id,shape);}
  g.error=null;wizardRender(true);
 }catch(error){g.error=error.message;}

});
wizardSvg.addEventListener('pointerleave',()=>{if(!wizardDrag)for(const dot of wizardSvg.querySelectorAll('.edit-point'))sizeWizardDot(dot,false);});
function finishWizardDrag(e,cancel=false){
 if(!wizardDrag)return;const g=wizardDrag;wizardDrag=null;wizardLastDrag={x:e.clientX,y:e.clientY};
 if(cancel){if(g.type==='outline')wizardOutline=g.before;else if(g.type==='draft')wizardRegionDraft=g.before;else wizardRegions=g.before;}
 if(g.type==='cell'||g.type==='label'){
  if(!cancel&&JSON.stringify(g.before)!==JSON.stringify(wizardRegions)){wizardCellHistory.push(g.before);if(g.type==='cell')wizardRegions=wizardRegions.map(r=>({...r,seed:regionPoint(r)}));}
  wizardRender(true);if(!cancel){const tapped=Math.hypot(e.clientX-g.screen[0],e.clientY-g.screen[1])<6,now=performance.now(),twice=tapped&&wizardLastTap?.id===g.id&&now-wizardLastTap.time<350;if(tapped)wizardLastTap={id:g.id,time:now};showRegionActions(e.clientX,e.clientY);if(g.error)$('wizardStatus').textContent=g.error+' 마지막 가능한 위치를 유지했습니다.';if(tapped&&twice&&!wizardCellNode)wizardEditName(g.id,e.clientX,e.clientY);}
 }else if(g.type==='draft'){
  if(!cancel&&JSON.stringify(g.before)!==JSON.stringify(wizardRegionDraft))wizardDraftHistory.push(g.before);wizardRender();if(!cancel)placeNear($('wizardDraftPopover'),e.clientX,e.clientY);
 }else{
  if(!cancel&&JSON.stringify(g.before)!==JSON.stringify(wizardOutline))rememberOutline(g.before);wizardRender();if(!cancel){showOutlineTools(g.index,e.clientX,e.clientY);placeNear($('wizardOutlineActions'),e.clientX,e.clientY+45);}
 }
 if(g.error&&!cancel)$('wizardStatus').textContent=g.error+' 마지막 가능한 위치를 유지했습니다.';
 if(wizardSvg.hasPointerCapture(e.pointerId))wizardSvg.releasePointerCapture(e.pointerId);
}
wizardSvg.addEventListener('pointerup',e=>finishWizardDrag(e));wizardSvg.addEventListener('pointercancel',e=>finishWizardDrag(e,true));
wizardSvg.addEventListener('dblclick',e=>{const poly=e.target.closest('[data-wizard-region],[data-wizard-label]');if(editorInputAllowed(e)&&wizardStep===2&&!wizardDrawingRegion&&poly)selectEditorRegion(poly.dataset.wizardRegion||poly.dataset.wizardLabel,e.clientX,e.clientY,true);});

let canvasActionPoint=null,canvasDismissPointer=null;
function showCanvasActions(e){if(photoMove)return;if(bulkDeleting)return;if(workAreaEdit||pendingPlacementId)return;if(canvasDismissPointer===e.pointerId){canvasDismissPointer=null;return;}canvasDismissPointer=null;if(picking||regionPicking||regionTransforming)return;canvasActionPoint=point(e);const menu=$('canvasActionMenu');menu.hidden=false;const clearing=canClearInk&&!mobileView()&&room.strokes.length;if(clearing)menu.append($('clearInk'));updatePenTools();$('canvasPhoto').disabled=!isTop()||!siteInputAllowed(e);$('canvasRegister').disabled=!isTop()||!siteInputAllowed(e);$('canvasRegister').title=isTop()?'이 위치에 작업 등록':'작업 등록은 현장 전경에서 가능합니다.';placeNear(menu,e.clientX,e.clientY);}
$('canvasEraseOwn').onclick=()=>{if(!room||!myInkOwner)return;if(send({type:'clearOwnInk',image:room.image})){$('canvasActionMenu').hidden=true;selectMode('pan');}};
function chooseDetailPhoto(anchor=null){photoAnchor=Array.isArray(anchor)&&isTop()?[...anchor]:null;stopActiveTool('photo');if(!$('sidePanel').hidden){if($('sidePanel').dataset.section==='work')cancelTaskRegistration();else panel(false);}if($('shareDialog').open)$('shareDialog').close();$('photoFile').click();}
$('canvasPhoto').onclick=()=>chooseDetailPhoto(canvasActionPoint);$('photoFile').addEventListener('cancel',()=>photoAnchor=null);
$('canvasDraw').onclick=()=>{stopActiveTool('draw');selectMode('draw');};
$('canvasRegister').onclick=()=>{if(!canvasActionPoint||!isTop())return;const [x,y]=canvasActionPoint;const shape='point';$('taskShape').value=shape;keptGeometry=[];$('keptGeometryCount').textContent='';if(shape==='area'){const left=Math.max(0,Math.min(.84,x-.08)),top=Math.max(0,Math.min(.84,y-.08));draft=[[left,top],[left+.16,top],[left+.16,top+.16],[left,top+.16]];}else draft=[[x,y]];renderDraft();$('canvasActionMenu').hidden=true;openToolSection('work');const r=$('scene').getBoundingClientRect();placeNear($('nearTaskCancel'),r.x+x*r.width,r.y+y*r.height,90);$('taskTitle').focus();};
document.addEventListener('pointerdown',e=>{
 canvasDismissPointer=null;suppressPlacementClick=false;
 if(!e.target.closest('#photoPinMenu,.photo-pin'))photoPinMenu.hidden=true;
 if(!e.target.closest('#photoMore,#photoViewActions'))photoViewActions.hidden=true;
 if(!e.target.closest('#pendingPopover,#pendingWorksButton'))closePending();
 if(!e.target.closest('#canvasActionMenu')){if(!$('canvasActionMenu').hidden)canvasDismissPointer=e.pointerId;$('canvasActionMenu').hidden=true;resetFloatingPosition($('canvasActionMenu'));updatePenTools();}
 if(!e.target.closest('#taskActions,.marker')&&!gesture){if(!$('taskActions').hidden)canvasDismissPointer=e.pointerId;pinnedId=activeId=null;if(room)reveal();resetFloatingPosition($('taskActions'));}
 for(const id of ['wizardRegionActions','wizardNamePopover','outlinePointTools','meshNamePopover']){
  const box=$(id);if(box.hidden||box.contains(e.target)||e.target.closest('[data-wizard-region],[data-wizard-label],[data-outline-point],[data-mesh-region],[data-mesh-point]'))continue;
  if(id==='wizardRegionActions'&&wizardEditing||id==='outlinePointTools'&&wizardDrag||id==='meshNamePopover'&&meshGesture)continue;
  if(box.contains(document.activeElement))document.activeElement.blur();box.hidden=true;resetFloatingPosition(box);
 }
 if(!e.target.closest('.vertical-warning'))document.querySelectorAll('.vertical-warning').forEach(node=>{if(node.contains(document.activeElement))document.activeElement.blur();node.classList.add('dismissed');node.classList.remove('expanded');node.querySelector('button')?.setAttribute('aria-expanded','false');});
},true);
window.addEventListener('keydown',e=>{if(e.key==='Escape')$('canvasActionMenu').hidden=true;});
chromeButton($('canvasEraseOwn'),'eraser','내 그림 지우기');chromeButton($('canvasDraw'),'pen','그리기');chromeButton($('canvasRegister'),'work','작업 등록');chromeButton($('canvasPhoto'),'photo','사진 추가');

$('sitePanel').append($('worksPanel'));$('worksPanel').querySelector('summary').textContent='웍스 일정 가져오기';

function cancelTaskRegistration(){$('nearTaskCancel').hidden=true;picking=false;rectangleGesture=null;draft=[];keptGeometry=[];canvasActionPoint=null;activeId=pinnedId=null;$('taskForm').reset();$('taskDate').value=selectedDates[0];$('taskShape').value='point';$('keptGeometryCount').textContent='';$('finishGeometry').hidden=true;$('cancelTaskPlacement').hidden=true;$('canvasActionMenu').hidden=true;renderDraft();reveal();selectMode('pan');panel(false);}
$('cancelTask').onclick=$('cancelTaskPlacement').onclick=$('nearTaskCancel').onclick=cancelTaskRegistration;

$('startWorksNetwork').after($('worksNetworkStatus'));

const cog=[];for(let i=0;i<8;i++)for(const [offset,radius]of [[-.5,8.4],[-.23,10.5],[.23,10.5],[.5,8.4]]){const angle=(i+offset)*Math.PI/4;cog.push([(12+radius*Math.cos(angle)).toFixed(2),(12+radius*Math.sin(angle)).toFixed(2)]);}chromeIcons.gear='M'+cog.map(p=>p.join(' ')).join('L')+'Z M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0';chromeButton($('siteSettingsButton'),'gear');

// Dialog-local notices remain above the modal image and disappear like arrival notices.
for(const id of ['wizardStatus','meshStatus']){const element=$(id);element.setAttribute('role','status');let timer;const show=()=>{element.classList.add('notice-visible');clearTimeout(timer);timer=setTimeout(()=>element.classList.remove('notice-visible'),3500);};new MutationObserver(show).observe(element,{childList:true,characterData:true,subtree:true});}

$('wizardDraftName').onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();$('wizardFinishRegion').click();}};

function showPlacementActions(e){if(!picking)return;placeNear($('cancelTaskPlacement'),e.clientX,e.clientY,90);$('cancelTaskPlacement').style.transform='none';placeNear($('finishGeometry'),e.clientX,e.clientY+44,120);$('finishGeometry').style.transform='none';}
// Optional registration fields collapse on phones, retaining full desktop access.
const taskOptions=el('details');taskOptions.id='taskOptions';taskOptions.append(el('summary','','추가 설정 · 날짜 / 영역 / 동선'));
for(const id of ['taskDate','taskEquipment','taskDetail','taskShape','pickGeometry','geometryCount','keepGeometry','keptGeometryCount','taskAttention']){const element=$(id);taskOptions.append(element.closest('label')||element);}
$('taskForm').insertBefore(taskOptions,$('taskForm').querySelector('.task-form-actions'));if(!mobileView())taskOptions.open=true;

function clampMobileTaskLabels(){if(!mobileView())return;const view=$('viewport').getBoundingClientRect();for(const marker of document.querySelectorAll('.marker.selected:not(.area-marker)')){const label=marker.querySelector('.marker-label'),scale=marker.getBoundingClientRect().width/Math.max(1,marker.offsetWidth);label.style.marginLeft='0px';label.style.translate='0 0';label.style.bottom='calc(100% + 10px)';label.style.top='auto';label.style.maxWidth=Math.max(100,(view.width-24)/scale)+'px';let box=label.getBoundingClientRect();const shift=box.right>view.right-8?view.right-8-box.right:box.left<view.left+8?view.left+8-box.left:0;label.style.marginLeft=shift/scale+'px';if(box.top<view.top+8)label.style.translate='0 '+(view.top+8-box.top)/scale+'px';}}
function syncMobileFrame(){if(!mobileView())return;const v=window.visualViewport,root=document.documentElement;root.style.setProperty('--app-width',(v?.width||innerWidth)+'px');root.style.setProperty('--app-height',(v?.height||innerHeight)+'px');root.style.setProperty('--app-left',(v?.offsetLeft||0)+'px');root.style.setProperty('--app-top',(v?.offsetTop||0)+'px');if(room)requestAnimationFrame(setZoom);}
window.visualViewport?.addEventListener('resize',syncMobileFrame);window.visualViewport?.addEventListener('scroll',syncMobileFrame);window.addEventListener('resize',syncMobileFrame);window.addEventListener('orientationchange',syncMobileFrame);syncMobileFrame();

// PC and phone share the same canonical rail and work-management entry.
$('toolRail').prepend($('toolRail').querySelector('[data-mode=draw]'));
$('registration').append($('taskManagement'));

$('personalZoomLevel').onclick=resetView;
zoomScrubber($('personalZoomLevel'),{get:()=>zoom,key:()=>room?.image,start:()=>{stopActiveTool('zoom');rememberView();},set:value=>{zoom=Math.max(minimumZoom(),Math.min(8,value));setZoom();}});

// Context menus retain their controls while a separate grip moves the whole menu.
for(const id of ['canvasActionMenu','wizardRegionActions','wizardDraftPopover','wizardOutlineActions','outlinePointTools','meshNamePopover','nearTaskCancel','cancelTaskPlacement','finishGeometry','taskActions'])makeFloatingMovable($(id));
function makeFloatingMovable(element){if(!element)return;const grip=el('span','floating-drag-handle','⠿');grip.setAttribute('aria-hidden','true');grip.title='끌어서 이동';element.prepend(grip);element.classList.add('floating-movable');let drag=null;
 element.addEventListener('pointerdown',e=>{if(e.button!==0||idIsBottomBar()||!e.target.closest('.floating-drag-handle'))return;e.preventDefault();e.stopPropagation();const r=element.getBoundingClientRect();drag={pointer:e.pointerId,x:e.clientX,y:e.clientY,left:r.left,top:r.top};element.style.position='fixed';element.style.left=r.left+'px';element.style.top=r.top+'px';element.style.right='auto';element.style.bottom='auto';element.style.transform='none';element.classList.add('floating-dragging');grip.setPointerCapture(e.pointerId);});
 grip.addEventListener('pointermove',e=>{if(!drag||e.pointerId!==drag.pointer)return;e.preventDefault();e.stopPropagation();element.dataset.userPosition='1';const v=window.visualViewport,left=v?.offsetLeft||0,top=v?.offsetTop||0,width=v?.width||innerWidth,height=v?.height||innerHeight,r=element.getBoundingClientRect();element.style.left=Math.max(left+8,Math.min(drag.left+e.clientX-drag.x,left+width-r.width-8))+'px';element.style.top=Math.max(top+8,Math.min(drag.top+e.clientY-drag.y,top+height-r.height-8))+'px';});
 const end=e=>{if(!drag)return;e.preventDefault();e.stopPropagation();drag=null;element.classList.remove('floating-dragging');if(grip.hasPointerCapture(e.pointerId))grip.releasePointerCapture(e.pointerId);};grip.addEventListener('pointerup',end);grip.addEventListener('pointercancel',end);
 element.addEventListener('click',e=>{if(e.target.closest('.floating-drag-handle')){e.preventDefault();e.stopImmediatePropagation();}},true);
 function idIsBottomBar(){return element.id==='taskActions'&&mobileView();}
}
// Suppress native image/text selection on interactive maps, leaving forms and share links selectable.
for(const id of ['scene','wizardStage','meshStage']){const target=$(id);for(const type of ['contextmenu','selectstart','dragstart'])target.addEventListener(type,e=>{if(!e.target.closest('input,textarea,[contenteditable=true]'))e.preventDefault();});}
for(const id of ['background','wizardImage','meshImage'])$(id).draggable=false;

let cloudSites=[],cloudBusy=false;
async function refreshCloudStatus(){try{const value=await api('/api/cloud/status');$('cloudLoginFields').hidden=!value.configured||value.signedIn;$('cloudActions').hidden=!value.signedIn;$('cloudShareStatus').textContent=value.signedIn?'연결됨 · '+value.email+(value.automatic?' · '+value.automatic.message:''):value.configured?'회사·집에서 같은 계정으로 로그인해 현장을 공유합니다.':'Supabase 연결 준비 중 · 현재 현장은 이 PC에 저장됩니다.';if(value.signedIn)await refreshCloudSites(value.automatic?.siteId||$('cloudSites').value);}catch(error){$('cloudShareStatus').textContent=error.message;}}
async function refreshCloudSites(selected=$('cloudSites').value){const value=await api('/api/cloud/sites');cloudSites=value.sites;$('cloudSites').replaceChildren(el('option','','새 공유 현장'));$('cloudSites').firstChild.value='';for(const saved of cloudSites){const option=el('option','',saved.name);option.value=saved.id;$('cloudSites').append(option);}if(cloudSites.some(saved=>saved.id===selected))$('cloudSites').value=selected;}
async function cloudAction(action){if(cloudBusy)return;cloudBusy=true;for(const id of ['cloudLogin','cloudPush','cloudPull','cloudLogout'])$(id).disabled=true;try{await action();}catch(error){$('cloudShareStatus').textContent=error.message;}finally{cloudBusy=false;for(const id of ['cloudLogin','cloudPush','cloudPull','cloudLogout'])$(id).disabled=false;}}
$('cloudLogin').onclick=()=>cloudAction(async()=>{try{await api('/api/cloud/login',{email:$('cloudEmail').value.trim(),password:$('cloudPassword').value});await refreshCloudStatus();}finally{$('cloudPassword').value='';}});
$('cloudLogout').onclick=()=>cloudAction(async()=>{await api('/api/cloud/logout',{});await refreshCloudStatus();});
$('cloudPush').onclick=()=>cloudAction(async()=>{const chosen=cloudSites.find(saved=>saved.id===$('cloudSites').value);$('cloudShareStatus').textContent='사진과 현장을 저장하고 있습니다…';const saved=await api('/api/cloud/push',{id:chosen?.id,revision:chosen?.revision||0});await refreshCloudSites(saved.id);$('cloudShareStatus').textContent=saved.hasNewLocalChanges?'공유 저장 완료 · 저장 중 추가된 변경은 한 번 더 저장해주세요.':'공유 저장 완료 · 다른 PC에서 같은 계정으로 불러올 수 있습니다.';});
$('cloudPull').onclick=()=>cloudAction(async()=>{const id=$('cloudSites').value;if(!id){$('cloudShareStatus').textContent='불러올 현장을 선택해주세요.';return;}$('cloudShareStatus').textContent='사진과 현장을 불러오고 있습니다…';await api('/api/cloud/pull',{id,roomRevision:room.revision,siteRevision:site.revision});await refreshCloudSites(id);$('cloudShareStatus').textContent='공유 현장을 불러왔습니다.';});

const worksQuick=el('div');worksQuick.id='worksQuickActions';
const worksAdvanced=el('details');worksAdvanced.id='worksConnectionSettings';worksAdvanced.hidden=true;worksAdvanced.append(el('summary','','진단 보기'));
const legacyWorksLabel=$('worksFile')?.closest('label'),legacyWorksNote=legacyWorksLabel?.nextElementSibling;
const sourceLabel=$('worksNetworkSource').closest('label'),dateLabel=$('worksDate').closest('label'),networkStatus=$('worksNetworkStatus');
sourceLabel.hidden=true;sourceLabel.firstChild.textContent='캘린더';dateLabel.firstChild.textContent='작업 날짜';
const unified=el('button','','연결하고 불러오기');unified.id='worksUnifiedImport';unified.onclick=connectAndImportWorks;
const defaults=el('small','','10초마다 자동 갱신 · 새 일정 자동 반영');defaults.id='worksDefaults';
const rescue=el('div');rescue.id='worksProblemActions';const edge=$('openWorksBrowser');edge.textContent='엣지 열기';rescue.append(edge);
for(const node of [...$('worksPanel').children])if(node.tagName!=='SUMMARY')worksAdvanced.append(node);
const worksLog=el('details');worksLog.id='worksLog';const worksLogSummary=el('summary','','상세 로그');worksLog.append(worksLogSummary,networkStatus);worksQuick.append(sourceLabel,dateLabel,unified,worksLog,defaults,rescue);
new MutationObserver(()=>{worksLogSummary.textContent='상세 로그'+(worksQuick.classList.contains('has-problem')?' · 연결 확인':worksAwaitLogin?' · 로그인 대기':worksNetworkLast?.automaticSave&&!worksNetworkLast.automaticSave.enabled?' · 저장 확인':worksNetworkLast?.automatic?' · 자동 갱신 중':'');}).observe(networkStatus,{childList:true,characterData:true,subtree:true});
$('worksPanel').append(worksQuick,worksAdvanced);
if(legacyWorksLabel)worksAdvanced.append(legacyWorksLabel);if(legacyWorksNote?.tagName==='SMALL')worksAdvanced.append(legacyWorksNote);
// Old manual readers remain available only as troubleshooting fallbacks.
$('startWorksNetwork').hidden=true;$('selectWorksNetwork').hidden=true;
for(const node of [...$('worksNetworkTools').children])if(node.tagName==='P'||node.tagName==='B'||node.tagName==='LABEL')node.hidden=true;
$('worksNetworkDate').closest('label').hidden=true;
$('worksNetworkSource').replaceChildren(el('option','','현장 캘린더 선택'));$('worksNetworkSource').firstChild.value='';
$('worksPanel').addEventListener('toggle',()=>{if($('worksPanel').open&&!worksNetworkLast&&!worksUnifiedBusy)void pollWorksNetwork();});

// Photo pins retain their map coordinate while the thumbnail avoids nearby work icons.
const photoLeaders=document.createElementNS('http://www.w3.org/2000/svg','svg');photoLeaders.id='photoLeaders';photoLeaders.setAttribute('viewBox','0 0 1000 1000');photoLeaders.setAttribute('preserveAspectRatio','none');
const photoPins=el('div');photoPins.id='photoPins';$('scene').append(photoLeaders,photoPins);
const photoInbox=el('button');photoInbox.id='photoInboxButton';photoInbox.hidden=true;$('workspace').append(photoInbox);chromeButton(photoInbox,'photo','사진');
const photoShelf=el('div');photoShelf.id='photoShelf';photoShelf.hidden=true;photoShelf.setAttribute('aria-label','등록 사진');
photoShelf.innerHTML='<div class="photo-shelf-head"><b>미확인 사진</b><button id="photoShelfAll">전체 사진</button><button id="photoShelfClose" aria-label="사진 목록 닫기">×</button></div><div id="photoShelfList"></div><button id="photoShelfMore" hidden>더 보기</button>';
$('workspace').append(photoShelf);makeFloatingMovable(photoShelf);for(const type of ['contextmenu','selectstart','dragstart'])photoShelf.addEventListener(type,e=>e.preventDefault());
const photoMore=el('button','','⋯');photoMore.id='photoMore';photoMore.hidden=true;photoMore.setAttribute('aria-label','사진 메뉴');$('workspace').append(photoMore);
const photoViewActions=el('div');photoViewActions.id='photoViewActions';photoViewActions.hidden=true;
photoViewActions.innerHTML='<button id="photoConfirm">확인 완료</button><button id="photoUnpin">지도 표시 해제</button><button id="photoDelete">사진 삭제</button>';$('workspace').append(photoViewActions);
photoMore.onclick=e=>{photoViewActions.hidden=!photoViewActions.hidden;if(!photoViewActions.hidden)placeNear(photoViewActions,e.clientX,e.clientY);};
let photoShowAll=false,photoLimit=10;
function currentPhoto(){return room?.photos?.find(p=>p.image===room.image);}
async function photoAction(photo,action){try{await api('/api/rooms/'+room.id+'/photos/'+photo.id,{action});}catch(error){toast(error.message);}}
function layoutTaskMarkers(){if(room&&isTop()&&!gesture)arrangeTaskMarkers($('scene'),viewport,room.tasks,site);layoutVerticalWarnings();clampMobileTaskLabels();layoutPhotos();}
function layoutPhotos(){if(room&&isTop())arrangePhotoCards($('scene'),viewport,photoLeaders);}
function renderPhotos(){
 if(!room)return;const photos=room.photos||[],unconfirmed=photos.filter(p=>p.status!=='confirmed');
 photoInbox.hidden=!photos.length||!isTop();photoInbox.setAttribute('aria-label',unconfirmed.length?'미확인 사진 '+unconfirmed.length:'사진 '+photos.length);for(const child of [...photoInbox.children])if(child.tagName.toLowerCase()!=='svg')child.remove();photoInbox.append(el('span','','사진'));if(unconfirmed.length)photoInbox.append(el('span','photo-inbox-count',String(unconfirmed.length)));$('workspace').classList.toggle('has-photo-inbox',!photoInbox.hidden);
 photoPins.replaceChildren();photoLeaders.replaceChildren();photoPins.hidden=photoLeaders.hidden=!isTop();
 if(isTop())for(const photo of photos.filter(p=>Number.isFinite(p.x)&&Number.isFinite(p.y))){
  const pin=el('div','photo-pin'+(photo.status==='confirmed'?' confirmed':''));pin.dataset.photoId=photo.id;pin.dataset.x=photo.x;pin.dataset.y=photo.y;const location=photoMove?.id===photo.id?photoMove.point:[photo.x,photo.y];pin.dataset.x=location[0];pin.dataset.y=location[1];pin.style.left=location[0]*100+'%';pin.style.top=location[1]*100+'%';
  const tail=el('span','photo-tail');const button=el('button','photo-thumb');button.setAttribute('aria-label',photo.title+' 사진 열기');const img=el('img');img.src=photo.thumbnail||photo.image;img.alt=photo.title;img.loading='lazy';img.draggable=false;button.append(img);wirePhotoThumb(button,photo);pin.append(tail,button);photoPins.append(pin);
 }
 const visible=currentPhoto();photoMore.hidden=!visible;photoViewActions.hidden=true;$('workspace').classList.toggle('detail-photo',Boolean(visible));if(visible){$('photoConfirm').textContent=visible.status==='confirmed'?'미확인으로 변경':'확인 완료';$('photoUnpin').hidden=!Number.isFinite(visible.x);}
 renderPhotoShelf();requestAnimationFrame(layoutTaskMarkers);
}
function renderPhotoShelf(){
 if(!room)return;const photos=[...(room.photos||[])].reverse().filter(p=>photoShowAll||p.status!=='confirmed');$('photoShelfList').replaceChildren();photoShelf.querySelector('b').textContent=photoShowAll?'전체 사진':'미확인 사진';$('photoShelfAll').textContent=photoShowAll?'미확인만':'전체 사진';
 for(const photo of photos.slice(0,photoLimit)){const button=el('button','photo-shelf-item');button.setAttribute('aria-label',photo.title+' 사진 열기');const img=el('img');img.src=photo.thumbnail||photo.image;img.alt=photo.title;img.loading='lazy';img.draggable=false;button.append(img,el('span','',photo.title));button.onclick=()=>{photoShelf.hidden=true;photoAction(photo,'open');};$('photoShelfList').append(button);}
 if(!photos.length)$('photoShelfList').append(el('small','','미확인 사진이 없습니다.'));$('photoShelfMore').hidden=photos.length<=photoLimit;
}
photoInbox.onclick=e=>{photoShelf.hidden=!photoShelf.hidden;if(!photoShelf.hidden){photoLimit=10;renderPhotoShelf();placeNear(photoShelf,e.clientX,e.clientY);}};$('photoShelfClose').onclick=()=>photoShelf.hidden=true;$('photoShelfAll').onclick=()=>{photoShowAll=!photoShowAll;photoLimit=10;renderPhotoShelf();};$('photoShelfMore').onclick=()=>{photoLimit+=10;renderPhotoShelf();};
$('photoConfirm').onclick=()=>{const photo=currentPhoto();if(photo)photoAction(photo,'confirm');};$('photoDelete').onclick=()=>{const photo=currentPhoto();if(photo)photoAction(photo,'delete');};$('photoUnpin').onclick=()=>{const photo=currentPhoto();if(photo)photoAction(photo,'unpin');};

// Pump concrete routes share normalized scene coordinates and save as an extra route geometry.
const pumpRouteTools=el('div');pumpRouteTools.id='pumpRouteTools';pumpRouteTools.hidden=true;
pumpRouteTools.innerHTML='<button id="pumpRouteUndo">이전</button><button id="pumpRouteDone">완료</button><button id="pumpRouteCancel">취소</button><button id="pumpRouteDelete" hidden>동선 삭제</button>';$('workspace').append(pumpRouteTools);makeFloatingMovable(pumpRouteTools);
const pumpPreview=document.createElementNS('http://www.w3.org/2000/svg','svg');pumpPreview.id='pumpRoutePreview';pumpPreview.setAttribute('viewBox','0 0 1000 1000');pumpPreview.setAttribute('preserveAspectRatio','none');$('scene').append(pumpPreview);
function cancelPumpRoute(){pumpRouteTaskId=null;pumpRoutePoints=[];$('workspace').classList.remove('pump-route-editing');pumpRouteTools.hidden=true;pumpPreview.replaceChildren();pinnedId=null;if(room)reveal();}
function renderPumpPreview(){pumpPreview.replaceChildren();const line=document.createElementNS(pumpPreview.namespaceURI,'polyline');line.setAttribute('points',pumpRoutePoints.map(p=>p.map(v=>v*1000).join(',')).join(' '));pumpPreview.append(line);for(const p of pumpRoutePoints){const dot=document.createElementNS(pumpPreview.namespaceURI,'circle');dot.setAttribute('cx',p[0]*1000);dot.setAttribute('cy',p[1]*1000);dot.setAttribute('r',3);pumpPreview.append(dot);}$('pumpRouteUndo').disabled=!pumpRoutePoints.length;$('pumpRouteDone').disabled=pumpRoutePoints.length<2;}
$('pumpRouteButton').onclick=e=>{const task=room.tasks.find(t=>t.id===pinnedId);if(!task||!hasConcreteRoute(task))return;stopActiveTool('pump-route');if(!$('sidePanel').hidden)panel(false);pumpRouteTaskId=task.id;$('workspace').classList.add('pump-route-editing');pumpRoutePoints=structuredClone(task.extras?.find(g=>g.purpose==='mixer-route')?.points||[]);$('taskActions').hidden=true;resetFloatingPosition(pumpRouteTools);$('pumpRouteDelete').hidden=!pumpRoutePoints.length;renderPumpPreview();placeNear(pumpRouteTools,e.clientX,e.clientY);};
viewport.addEventListener('pointerdown',e=>{if(!pumpRouteTaskId||e.button!==0||!e.target.closest('#scene')||!mainInputAllowed(e))return;e.preventDefault();e.stopImmediatePropagation();if(pumpRoutePoints.length>=100){toast('동선은 100점까지 지정할 수 있습니다.');return;}pumpRoutePoints.push(point(e));renderPumpPreview();placeNear(pumpRouteTools,e.clientX,e.clientY);},true);
$('pumpRouteUndo').onclick=()=>{pumpRoutePoints.pop();renderPumpPreview();};$('pumpRouteCancel').onclick=cancelPumpRoute;
$('pumpRouteDone').onclick=()=>{if(pumpRouteTaskId&&pumpRoutePoints.length>=2&&send({type:'setMixerRoute',id:pumpRouteTaskId,points:pumpRoutePoints})){cancelPumpRoute();pinnedId=null;reveal();}};
$('pumpRouteDelete').onclick=()=>{if(pumpRouteTaskId&&send({type:'setMixerRoute',id:pumpRouteTaskId,points:[]})){cancelPumpRoute();pinnedId=null;reveal();}};
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&pumpRouteTaskId){e.preventDefault();cancelPumpRoute();}});
function appendMixerIcons(svg,points){const box=$('scene').getBoundingClientRect();let count=0;for(let i=0;i<points.length-1&&count<6;i++){const a=points[i],b=points[i+1],dx=(b[0]-a[0])*box.width,dy=(b[1]-a[1])*box.height;if(Math.hypot(dx,dy)<30)continue;count++;const group=document.createElementNS(svg.namespaceURI,'g');group.classList.add('mixer-route-icon');group.setAttribute('transform','translate('+((a[0]+b[0])*500)+' '+((a[1]+b[1])*500)+') scale('+(1000/Math.max(1,box.width))+' '+(1000/Math.max(1,box.height))+')');const bg=document.createElementNS(svg.namespaceURI,'circle');bg.setAttribute('r',14);bg.classList.add('mixer-icon-bg');group.append(bg);const raw=Math.atan2(dy,dx)*180/Math.PI,angle=dx<0?raw+(raw<0?180:-180):raw;const vehicle=document.createElementNS(svg.namespaceURI,'g');vehicle.classList.add('mixer-vehicle');vehicle.style.color='#1d4ed8';vehicle.setAttribute('transform','rotate('+angle+') scale('+(dx>=0?-.375:.375)+' .375) translate(-32 -32)');vehicle.append(equipmentIcon({icon:'mixer'}).firstElementChild);group.append(vehicle);svg.append(group);}}

const wizardPhotoView=editorPhotoView({viewport:$('wizardViewport'),stage:$('wizardStage'),image:$('wizardImage'),dialog:$('siteWizardDialog'),id:'wizard',isMobile:mobileView,spaceHeld:()=>spaceHeld,beforeNavigate:()=>{
 if(wizardDrag){const g=wizardDrag;wizardDrag=null;if(g.type==='outline')wizardOutline=g.before;else if(g.type==='draft')wizardRegionDraft=g.before;else wizardRegions=g.before;wizardRender(true);}wizardLastDrag=null;
},afterFit:()=>{for(const dot of wizardSvg.querySelectorAll('.edit-point'))sizeWizardDot(dot,false);}});
const meshPhotoView=editorPhotoView({viewport:$('meshViewport'),stage:$('meshStage'),image:$('meshImage'),dialog:$('regionEditorDialog'),id:'mesh',isMobile:mobileView,spaceHeld:()=>spaceHeld,beforeNavigate:()=>{if(meshGesture){meshRegions=meshGesture.regions;meshGesture=null;meshRender();}}});

// Keep drawing and placements inside the site allowance. Pan/zoom and UI buttons are unaffected.
for(const type of ['pointerdown','pointermove','pointerup','click','dblclick'])$('scene').addEventListener(type,e=>{
 if(mainInputAllowed(e))return;
 if(type==='pointermove'&&gesture){if(gesture.type==='draw')gesture.last=null;e.preventDefault();e.stopImmediatePropagation();return;}
 if(type==='pointerup'&&gesture){finish(e,true);e.preventDefault();e.stopImmediatePropagation();return;}
 if(type==='click'||type==='dblclick'||type==='pointerdown'&&(mode!=='pan'||picking||regionPicking||e.target.closest('.marker,.photo-pin'))){if(mode==='zoom'||spaceHeld||e.button===1)return;e.preventDefault();e.stopImmediatePropagation();}
},true);
// Frequent meeting imports precede the initial site configuration controls.
$('sitePanel').prepend($('worksPanel'));

// One shared warning at the overlapping work footprint, separate from equipment icons.
const warningPlacements=new Map();
const verticalWarningLayer=el('div');verticalWarningLayer.id='verticalWarningLayer';$('scene').append(verticalWarningLayer);
function renderVerticalWarnings(tasks){
 verticalWarningLayer.replaceChildren();if(!isTop())return;
 const pairs=verticalConflictPairs(tasks,site.regions||[]);renderHiddenWarnings(pairs);
 const grouped=new Map();for(const pair of pairs.filter(p=>!warningHidden(room,p,site.regions||[])))for(const zone of pair.zones||[pair]){
  const key=zone.x.toFixed(4)+','+zone.y.toFixed(4),group=grouped.get(key)||{x:zone.x,y:zone.y,footprint:zone.footprint,pairs:new Map()};
  const existing=group.pairs.get(pair.id);if(existing){existing.needs=[...new Set([...existing.needs,...zone.needs])];}else group.pairs.set(pair.id,{...pair,location:zone.location,status:zone.status,needs:zone.needs});grouped.set(key,group);
 }
 for(const group of grouped.values()){
  const wrapper=el('div','vertical-warning'),trigger=el('button','vertical-warning-trigger','!');wrapper.warningPosition=group;wrapper.style.left=group.x*100+'%';wrapper.style.top=group.y*100+'%';trigger.setAttribute('aria-label','상하 작업 확인 필요');trigger.setAttribute('aria-expanded','false');wrapper.append(trigger);
  const detail=el('div','vertical-warning-detail');detail.setAttribute('role','region');detail.setAttribute('aria-label','상하 작업 확인 내용');
  for(const pair of group.pairs.values()){
   const card=el('section','safety-pair');card.dataset.pair=pair.id;
   card.append(el('b','safety-heading',(pair.status==='overlap'?'상하 작업 겹침':'상하 작업 확인')+(pair.location?' · '+pair.location:'')),el('div','safety-upper','↑ '+pair.upperTitle),el('div','safety-lower','↓ '+pair.lowerTitle),el('small','safety-checks',pair.needs.length?pair.needs.join(' · '):pair.timeLabel));
   const more=el('details','safety-more');more.append(el('summary','','자세히'));const body=el('div','safety-original');body.append(el('div','','상부 원문: '+pair.upperOriginal),el('div','','하부 원문: '+pair.lowerOriginal),el('div','','판단 단서: '+pair.upperBasis+' / '+pair.lowerBasis),el('div','','시간: '+pair.timeLabel),el('div','','영역: '+(pair.needs.includes('작업영역 확인 필요')?'동·위치 기준 후보 — 실제 영향구역 확인 필요':'지정 작업영역 겹침')),el('div','','방호·통제: '+(pair.controls.length?pair.controls.join(' · ')+' — 운영 여부 현장 확인':'현장 확인 필요')));more.append(body);more.ontoggle=()=>requestAnimationFrame(()=>wrapper.fitSafety?.());card.append(more);const hide=el('button','hide-vertical-warning','이 경고 숨기기');hide.title='경고 숨김은 안전 확인 완료와 별개입니다.';hide.onclick=e=>{e.stopPropagation();send({type:'setWarningVisibility',key:pair.id,version:warningVersion(pair,room.tasks,site.regions||[]),hidden:true});};card.append(hide);detail.append(card);
  }
  wrapper.append(detail);wrapper.fitSafety=()=>{detail.style.marginLeft='0px';detail.style.marginTop='0px';const box=detail.getBoundingClientRect(),view=viewport.getBoundingClientRect();detail.style.marginLeft=Math.max(view.left+8-box.left,Math.min(0,view.right-8-box.right))+'px';if(box.bottom>view.bottom-8)detail.style.marginTop=-(Math.min(box.height,view.height-24)+36)+'px';};
  wrapper.onpointerdown=e=>e.stopPropagation();trigger.onclick=e=>{e.stopPropagation();wrapper.classList.remove('dismissed');for(const other of verticalWarningLayer.children)if(other!==wrapper){other.classList.remove('expanded');other.querySelector('button').setAttribute('aria-expanded','false');}const expanded=wrapper.classList.toggle('expanded');trigger.setAttribute('aria-expanded',String(expanded));if(expanded)wrapper.fitSafety();};wrapper.onpointerenter=()=>{if(!mobileView()){wrapper.classList.remove('dismissed');requestAnimationFrame(wrapper.fitSafety);}};trigger.onfocus=()=>{if(!mobileView())requestAnimationFrame(wrapper.fitSafety);};verticalWarningLayer.append(wrapper);
 }
 requestAnimationFrame(layoutTaskMarkers);
}

function layoutVerticalWarnings(){
 const scene=$('scene').getBoundingClientRect(),view=viewport.getBoundingClientRect();if(!scene.width)return;
 const blocks=[...$('tasks').children].map(n=>n.getBoundingClientRect());
 for(const button of verticalWarningLayer.children){const group=button.warningPosition,key=JSON.stringify([[...group.pairs.keys()].sort(),group.x,group.y,group.footprint]),cached=warningPlacements.get(key);if(cached){button.style.left=cached[0]*100+'%';button.style.top=cached[1]*100+'%';blocks.push(button.getBoundingClientRect());continue;}let best=null;
  for(const radius of [0,40,64,88,120,160,200,240])for(let n=0;n<(radius?16:1);n++){const x=scene.left+group.x*scene.width+radius*Math.cos(n*Math.PI/8),y=scene.top+group.y*scene.height+radius*Math.sin(n*Math.PI/8),p=[(x-scene.left)/scene.width,(y-scene.top)/scene.height];if(group.footprint&&!insideRegion(p,group.footprint))continue;const box={left:x-14,right:x+14,top:y-14,bottom:y+14};let score=radius;if(x<view.left+16||x>view.right-16||y<view.top+16||y>view.bottom-16)score+=1e6;for(const b of blocks)score+=Math.max(0,Math.min(box.right,b.right+5)-Math.max(box.left,b.left-5))*Math.max(0,Math.min(box.bottom,b.bottom+5)-Math.max(box.top,b.top-5))*10000;if(!best||score<best.score)best={p,box,score};}
  if(best){warningPlacements.set(key,best.p);button.style.left=best.p[0]*100+'%';button.style.top=best.p[1]*100+'%';blocks.push(best.box);}
 }
}

const pendingPopover=el('div');pendingPopover.id='pendingPopover';pendingPopover.hidden=true;pendingPopover.setAttribute('role','dialog');pendingPopover.setAttribute('aria-label','위치 확인 대기');
const pendingHead=el('div','pending-head'),pendingClose=el('button','','×');pendingClose.setAttribute('aria-label','위치 확인 닫기');pendingClose.onclick=closePending;pendingHead.append(el('b','','위치 확인 대기'),pendingClose);pendingPopover.append(pendingHead,$('pendingPanel'));$('workspace').append(pendingPopover);$('pendingPanel').open=true;$('pendingPanel').querySelector('summary').hidden=true;
function closePending(){if($('pendingPopover'))$('pendingPopover').hidden=true;$('pendingWorksButton').setAttribute('aria-expanded','false');}
function placePending(){if(pendingPopover.hidden)return;const r=$('pendingWorksButton').getBoundingClientRect(),box=pendingPopover.getBoundingClientRect();pendingPopover.style.left=Math.max(8,Math.min(r.right-box.width,innerWidth-box.width-8))+'px';pendingPopover.style.top=Math.max(8,Math.min(r.bottom+8,innerHeight-box.height-8))+'px';}
window.addEventListener('resize',placePending);

const workAreaButton=el('button','','작업영역 지정');workAreaButton.id='workAreaButton';$('taskActions').insertBefore(workAreaButton,$('deleteSelected'));
const workAreaTools=el('div');workAreaTools.id='workAreaTools';workAreaTools.hidden=true;const areaUndo=el('button','','이전'),areaDone=el('button','','완료'),areaCancel=el('button','','취소');areaUndo.id='workAreaUndo';areaDone.id='workAreaDone';areaCancel.id='workAreaCancel';workAreaTools.append(areaUndo,areaDone,areaCancel);$('workspace').append(workAreaTools);makeFloatingMovable(workAreaTools);
const workAreaPreview=document.createElementNS('http://www.w3.org/2000/svg','svg');workAreaPreview.id='workAreaPreview';workAreaPreview.setAttribute('viewBox','0 0 1000 1000');workAreaPreview.setAttribute('preserveAspectRatio','none');$('scene').append(workAreaPreview);
workAreaButton.onclick=e=>{const task=room.tasks.find(t=>t.id===pinnedId);if(!task)return;stopActiveTool('work-area');if(!$('sidePanel').hidden)panel(false);selectMode('pan');workAreaEdit={id:task.id,expected:JSON.stringify(task.workArea||[]),points:structuredClone(task.workArea||[]),history:[],drag:null};pinnedId=activeId=null;reveal();resetFloatingPosition(workAreaTools);placeNear(workAreaTools,e.clientX,e.clientY);renderWorkArea();};
function renderWorkArea(){workAreaPreview.replaceChildren();if(!workAreaEdit)return;areaUndo.disabled=!workAreaEdit.history.length;areaDone.disabled=workAreaEdit.points.length!==4;const poly=document.createElementNS(workAreaPreview.namespaceURI,'polygon');poly.setAttribute('points',workAreaEdit.points.map(p=>p.map(v=>v*1000).join(',')).join(' '));workAreaPreview.append(poly);}
function cancelWorkArea(){const pointer=workAreaEdit?.drag?.pointer;workAreaEdit=null;touchPoints.clear();pinch=null;pinchBlocking=false;viewGesture=null;if(pointer!==undefined&&viewport.hasPointerCapture(pointer))viewport.releasePointerCapture(pointer);workAreaTools.hidden=true;workAreaPreview.replaceChildren();}
areaUndo.onclick=()=>{if(workAreaEdit?.history.length){workAreaEdit.points=workAreaEdit.history.pop();renderWorkArea();}};
areaCancel.onclick=cancelWorkArea;
areaDone.onclick=()=>{if(workAreaEdit&&workAreaEdit.points.length===4&&send({type:'setWorkArea',id:workAreaEdit.id,points:workAreaEdit.points,expected:workAreaEdit.expected}))cancelWorkArea();};
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&workAreaEdit){e.preventDefault();cancelWorkArea();}else if(e.key==='Escape')closePending();});

const pendingPlacementTools=el('div');pendingPlacementTools.id='pendingPlacementTools';pendingPlacementTools.hidden=true;const pendingPlacementCancel=el('button','','취소');pendingPlacementCancel.id='pendingPlacementCancel';pendingPlacementCancel.onclick=cancelPendingPlacement;pendingPlacementTools.append(pendingPlacementCancel);$('workspace').append(pendingPlacementTools);makeFloatingMovable(pendingPlacementTools);
function cancelPendingPlacement(){pendingPlacementId=null;if($('pendingPlacementTools'))$('pendingPlacementTools').hidden=true;$('scene').classList.remove('pending-placing');}
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&pendingPlacementId){e.preventDefault();cancelPendingPlacement();}});

document.addEventListener('keydown',()=>{suppressPlacementClick=false;},true);

// Batch selection is a tool: switching tools cancels the local selection, never deletes it.
const bulkDeleteButton=el('button');bulkDeleteButton.id='bulkDeleteButton';bulkDeleteButton.title='작업 여러 개 삭제';bulkDeleteButton.setAttribute('aria-label','작업 여러 개 삭제');bulkDeleteButton.setAttribute('aria-pressed','false');bulkDeleteButton.innerHTML='<svg viewBox="0 0 24 24" width="21" height="21" fill="none" stroke="currentColor" stroke-width="1.6" aria-hidden="true"><path d="M9 6h11M11 6v13H6V9M13 3h4l1 3M4 4l2 2 4-4M9 10v6m5-6v6"/></svg>';$('taskManagement').prepend(bulkDeleteButton);
const bulkDeleteTools=el('div');bulkDeleteTools.id='bulkDeleteTools';bulkDeleteTools.hidden=true;const bulkCount=el('span','','0개 선택'),bulkRemove=el('button','','선택 삭제'),bulkCancel=el('button','','취소');bulkRemove.id='bulkDeleteConfirm';bulkCancel.id='bulkDeleteCancel';bulkDeleteTools.append(bulkCount,bulkRemove,bulkCancel);$('workspace').append(bulkDeleteTools);makeFloatingMovable(bulkDeleteTools);
function endBulkDelete(){bulkDeleting=false;bulkSelected.clear();updateBulkDelete();}
function updateBulkDelete(){if(!$('bulkDeleteButton'))return;bulkDeleteButton.hidden=!room||!isTop();bulkDeleteButton.classList.toggle('active',bulkDeleting);bulkDeleteButton.setAttribute('aria-pressed',String(bulkDeleting));bulkDeleteTools.hidden=!bulkDeleting;bulkCount.textContent=bulkSelected.size+'개 선택';bulkRemove.disabled=!bulkSelected.size;for(const marker of $('tasks').children){marker.classList.toggle('batch-selected',bulkDeleting&&bulkSelected.has(marker.dataset.id));if(bulkDeleting)marker.setAttribute('aria-pressed',String(bulkSelected.has(marker.dataset.id)));else marker.removeAttribute('aria-pressed');}$('workspace').classList.toggle('batch-selecting',bulkDeleting);}
bulkDeleteButton.onclick=e=>{if(bulkDeleting){endBulkDelete();return;}stopActiveTool('batch-delete');if(!$('sidePanel').hidden)panel(false);selectMode('pan');pinnedId=activeId=null;bulkDeleting=true;reveal();updateBulkDelete();resetFloatingPosition(bulkDeleteTools);placeNear(bulkDeleteTools,e.clientX,e.clientY+24);toast('삭제할 작업 아이콘을 선택하세요.');};
bulkCancel.onclick=endBulkDelete;bulkRemove.onclick=()=>{const ids=[...bulkSelected].filter(id=>room.tasks.some(t=>t.id===id));if(!ids.length)return;if(!confirm('선택한 작업 '+ids.length+'개를 삭제할까요?'))return;if(send({type:'deleteTasks',ids}))endBulkDelete();};
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&bulkDeleting){endBulkDelete();e.preventDefault();}});

const moveCompleteTools=el('div');moveCompleteTools.id='moveCompleteTools';moveCompleteTools.hidden=true;const moveDone=el('button','','완료');moveDone.id='moveComplete';moveCompleteTools.append(moveDone);$('workspace').append(moveCompleteTools);makeFloatingMovable(moveCompleteTools);
function showMoveComplete(e){moveCompleteTools.hidden=false;placeNear(moveCompleteTools,e.clientX,e.clientY+24);}
moveDone.onclick=()=>{selectMode('pan');pinnedId=activeId=null;reveal();};
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&mode==='move'){selectMode('pan');pinnedId=activeId=null;reveal();}});

// Explicit review actions share room state across participants and cloud snapshots.
const clearPositionButton=el('button','','위치 해제');clearPositionButton.id='clearTaskPosition';clearPositionButton.hidden=true;clearPositionButton.title='위치·작업영역·동선을 해제하고 위치 확인 대기로 되돌리기';$('taskActions').append(clearPositionButton);
clearPositionButton.onclick=()=>{const task=room.tasks.find(t=>t.id===pinnedId);if(!task)return;if(!confirm('위치와 해당 작업의 영역·동선을 해제하고 위치 확인 대기로 돌릴까요? 작업내용은 유지됩니다.'))return;stopActiveTool('clear-position');if(send({type:'clearTaskPosition',id:task.id})){pinnedId=activeId=null;reveal();}};
const hiddenWarningMenu=el('details');hiddenWarningMenu.id='hiddenWarningMenu';hiddenWarningMenu.hidden=true;const hiddenWarningSummary=el('summary','','숨긴 상하 경고'),hiddenWarningList=el('div');hiddenWarningMenu.append(hiddenWarningSummary,hiddenWarningList);$('taskManagement').append(hiddenWarningMenu);
function renderHiddenWarnings(pairs){if(!$('hiddenWarningMenu'))return;const hidden=pairs.filter(p=>warningHidden(room,p,site.regions||[]));hiddenWarningMenu.hidden=!hidden.length;hiddenWarningSummary.textContent='숨긴 상하 경고 ('+hidden.length+')';hiddenWarningList.replaceChildren();for(const pair of hidden){const row=el('div','hidden-warning-row'),text=el('span','',pair.upperTitle+' / '+pair.lowerTitle),restore=el('button','','다시 표시');restore.onclick=()=>send({type:'setWarningVisibility',key:pair.id,version:warningVersion(pair,room.tasks,site.regions||[]),hidden:false});row.append(text,restore);hiddenWarningList.append(row);}}
const photoPinMenu=el('div');photoPinMenu.id='photoPinMenu';photoPinMenu.hidden=true;const pinOpen=el('button','','사진 보기'),pinMove=el('button','','위치 이동');photoPinMenu.append(pinOpen,pinMove);$('workspace').append(photoPinMenu);makeFloatingMovable(photoPinMenu);let selectedPhotoId=null;
const photoMoveTools=el('div');photoMoveTools.id='photoMoveTools';photoMoveTools.hidden=true;const photoMoveDone=el('button','','완료'),photoMoveCancel=el('button','','취소');photoMoveDone.id='photoMoveDone';photoMoveCancel.id='photoMoveCancel';photoMoveTools.append(photoMoveDone,photoMoveCancel);$('workspace').append(photoMoveTools);makeFloatingMovable(photoMoveTools);
function wirePhotoThumb(button,photo){
 button.onpointerdown=e=>{e.stopPropagation();if(!mobileView()||e.button!==0||photoMove)return;e.preventDefault();if(photoHold)clearTimeout(photoHold.timer);const hold={id:photo.id,pointer:e.pointerId,x:e.clientX,y:e.clientY};photoHold=hold;hold.timer=setTimeout(()=>{if(photoHold!==hold)return;photoHold=null;beginPhotoMove(photo,e);if(photoMove){photoMove.drag={pointer:e.pointerId,screen:[hold.x,hold.y],origin:[...photoMove.point]};button.dataset.skipClick='1';navigator.vibrate?.(25);}},1500);button.setPointerCapture(e.pointerId);};
 button.onpointermove=e=>{if(photoHold&&photoHold.pointer===e.pointerId&&Math.hypot(e.clientX-photoHold.x,e.clientY-photoHold.y)>12){clearTimeout(photoHold.timer);photoHold=null;}};
 for(const type of ['pointerup','pointercancel'])button.addEventListener(type,e=>{if(photoHold?.pointer===e.pointerId){clearTimeout(photoHold.timer);photoHold=null;}});
 button.onclick=e=>{e.stopPropagation();if(button.dataset.skipClick||photoMove)return;selectedPhotoId=photo.id;photoPinMenu.hidden=false;resetFloatingPosition(photoPinMenu);placeNear(photoPinMenu,e.clientX,e.clientY);};
}
pinOpen.onclick=()=>{const photo=room.photos?.find(p=>p.id===selectedPhotoId);photoPinMenu.hidden=true;if(photo)photoAction(photo,'open');};
pinMove.onclick=e=>{const photo=room.photos?.find(p=>p.id===selectedPhotoId);if(photo)beginPhotoMove(photo,e);};
function beginPhotoMove(photo,e){stopActiveTool('photo-move');selectMode('pan');pinnedId=activeId=null;reveal();photoPinMenu.hidden=true;photoMove={id:photo.id,point:[photo.x,photo.y],expected:JSON.stringify([photo.x,photo.y]),drag:null};photoMoveTools.hidden=false;resetFloatingPosition(photoMoveTools);placeNear(photoMoveTools,e.clientX,e.clientY+20);$('scene').classList.add('photo-moving');}
function previewPhotoMove(){if(!photoMove)return;const pin=[...photoPins.children].find(n=>n.dataset.photoId===photoMove.id);if(!pin)return;pin.dataset.x=photoMove.point[0];pin.dataset.y=photoMove.point[1];pin.style.left=photoMove.point[0]*100+'%';pin.style.top=photoMove.point[1]*100+'%';layoutPhotos();}
function cancelPhotoMove(){if(photoHold){clearTimeout(photoHold.timer);photoHold=null;}photoMove=null;viewGesture=null;touchPoints.clear();pinch=null;pinchBlocking=false;if($('photoMoveTools'))photoMoveTools.hidden=true;$('scene').classList.remove('photo-moving');if(room)renderPhotos();}
viewport.addEventListener('pointerdown',e=>{if(!photoMove||e.button!==0||!e.target.closest('#scene'))return;e.preventDefault();e.stopImmediatePropagation();if(e.target.closest('.photo-pin'))photoMove.drag={pointer:e.pointerId,screen:[e.clientX,e.clientY],origin:[...photoMove.point]};else{photoMove.point=point(e);photoMove.drag={pointer:e.pointerId,screen:[e.clientX,e.clientY],origin:[...photoMove.point]};previewPhotoMove();}viewport.setPointerCapture(e.pointerId);},true);
document.addEventListener('pointermove',e=>{if(photoMove?.drag?.pointer!==e.pointerId||pinch||pinchBlocking)return;const g=photoMove.drag,box=$('scene').getBoundingClientRect();photoMove.point=[Math.max(0,Math.min(1,g.origin[0]+(e.clientX-g.screen[0])/box.width)),Math.max(0,Math.min(1,g.origin[1]+(e.clientY-g.screen[1])/box.height))];previewPhotoMove();},true);
document.addEventListener('pointerup',e=>{if(photoMove?.drag?.pointer===e.pointerId)photoMove.drag=null;},true);
document.addEventListener('pointercancel',e=>{if(photoMove?.drag?.pointer===e.pointerId){photoMove.point=photoMove.drag.origin;photoMove.drag=null;previewPhotoMove();}},true);
photoMoveCancel.onclick=cancelPhotoMove;photoMoveDone.onclick=async()=>{const current=photoMove;if(!current)return;try{await api('/api/rooms/'+room.id+'/photos/'+current.id,{action:'move',x:current.point[0],y:current.point[1],expected:current.expected});if(photoMove===current)cancelPhotoMove();}catch(error){toast(error.message);}};
window.addEventListener('keydown',e=>{if(e.key==='Escape'){photoPinMenu.hidden=true;if(photoMove){cancelPhotoMove();e.preventDefault();}}});

const pmxUI=setupPmxUI({$,el,getRoom:()=>room,getDate:()=>selectedDates[0],getPinnedTask:()=>room?.tasks.find(t=>t.id===pinnedId),canManage:()=>!hostSetup||canClearInk,api,stopActiveTool});
