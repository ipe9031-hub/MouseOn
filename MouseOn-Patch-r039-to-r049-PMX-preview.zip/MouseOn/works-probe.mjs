import {pmxReadExpression} from './pmx-reader.mjs';
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {beginDiagnosticExpression,readDiagnosticExpression} from './works-diagnostics.mjs';
import {createNetworkReader} from './works-network-reader.mjs';
import {captureExpression,batchExpression,automaticBatchExpression,decodePageResult} from './works-capture.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const key=randomBytes(24).toString('hex');
let browser,cdp,starting=false;const network=createNetworkReader({readVisible:(session,date)=>session.evaluate(automaticBatchExpression(date))});
class CDP{
 constructor(url){this.ws=new WebSocket(url);this.pending=new Map();this.listeners=new Set();this.counter=0;this.ready=new Promise((resolve,reject)=>{this.ws.onopen=resolve;this.ws.onerror=()=>reject(Error('브라우저 연결 실패'));});this.ws.onmessage=e=>{const m=JSON.parse(e.data);if(m.method)for(const fn of this.listeners)fn(m);const p=this.pending.get(m.id);if(p){clearTimeout(p.timer);this.pending.delete(m.id);m.error?p.reject(Error('브라우저 읽기 실패')):p.resolve(m.result);}};this.ws.onclose=()=>{for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(Error('연동용 브라우저가 닫혔습니다.'));}this.pending.clear();};}
 async call(method,params={},sessionId){await this.ready;return new Promise((resolve,reject)=>{const id=++this.counter,timer=setTimeout(()=>{this.pending.delete(id);reject(Error('브라우저 응답 대기 시간 초과'));},10000);this.pending.set(id,{resolve,reject,timer});this.ws.send(JSON.stringify({id,method,params,...(sessionId?{sessionId}:{})}));});}
 close(){this.ws.close();}
}
async function launch(kind,service='works'){
 const targetUrl=service==='pmx'?'https://pmx.gsenc.com/com/qse/safety/rskasm':'https://calendar.worksmobile.com/web/calendar/main?viewType=day';
 if(cdp){const {targetInfos}=await cdp.call('Target.getTargets');const tab=targetInfos.find(t=>t.type==='page'&&(service==='pmx'?/^https:\/\/pmx\.gsenc\.com(?:[/?#]|$)/.test(t.url):/^https:\/\/calendar\.worksmobile\.com\/web\/calendar\/main(?:[?/#]|$)/.test(t.url)));let targetId=tab?.targetId;if(tab)await cdp.call('Target.activateTarget',{targetId});else targetId=(await cdp.call('Target.createTarget',{url:targetUrl,newWindow:false})).targetId;return {ok:true,targetId,message:'연동 엣지의 새 탭에서 로그인해주세요.'};}if(starting)throw Error('연동용 브라우저를 여는 중입니다. 잠시 후 다시 시도해주세요.');starting=true;
 try{
  const candidates=kind==='edge'?[path.join(process.env['PROGRAMFILES(X86)']||'','Microsoft/Edge/Application/msedge.exe'),path.join(process.env.PROGRAMFILES||'','Microsoft/Edge/Application/msedge.exe'),path.join(process.env.LOCALAPPDATA||'','Microsoft/Edge/Application/msedge.exe')]:[path.join(process.env.PROGRAMFILES||'','Google/Chrome/Application/chrome.exe'),path.join(process.env['PROGRAMFILES(X86)']||'','Google/Chrome/Application/chrome.exe'),path.join(process.env.LOCALAPPDATA||'','Google/Chrome/Application/chrome.exe')];
  const executable=process.env.WORKS_BROWSER_PATH||candidates.find(p=>fs.existsSync(p));if(!executable)throw Error('선택한 브라우저를 찾지 못했습니다. 크롬 또는 엣지 설치를 확인해주세요.');
  const profile=path.join(process.env.DATA_DIR||path.join(root,'data'),'works-sessions',kind==='edge'?'edge':'chrome');fs.mkdirSync(profile,{recursive:true});fs.rmSync(path.join(profile,'DevToolsActivePort'),{force:true});
  browser=spawn(executable,[`--user-data-dir=${profile}`,'--remote-debugging-port=0','--remote-debugging-address=127.0.0.1','--no-first-run','--no-default-browser-check',...(process.env.WORKS_HEADLESS==='1'?['--headless','--no-sandbox']:[]),targetUrl],{stdio:'ignore'});
  const launched=browser;launched.on('exit',()=>{if(browser===launched){launchError=true;void network.stop();cdp?.close();cdp=null;}});
  let launchError=false;browser.on('error',()=>launchError=true);
  const portFile=path.join(profile,'DevToolsActivePort');for(let i=0;i<100&&!fs.existsSync(portFile)&&!launchError;i++)await new Promise(r=>setTimeout(r,150));
  if(!fs.existsSync(portFile)){browser.kill();throw Error('연동용 브라우저가 시작되지 않았습니다. 회사 보안 정책 또는 브라우저 설치를 확인해주세요.');}
  const port=Number(fs.readFileSync(portFile,'utf8').split('\n')[0]);const info=await(await fetch(`http://127.0.0.1:${port}/json/version`)).json();cdp=new CDP(info.webSocketDebuggerUrl);const opened=cdp;opened.ws.addEventListener('close',()=>{if(cdp===opened)cdp=null;},{once:true});await cdp.ready;
  const pages=(await cdp.call('Target.getTargets')).targetInfos.filter(t=>t.type==='page');return {ok:true,targetId:pages.find(t=>t.url.includes(service==='pmx'?'gsenc.com':'worksmobile.com'))?.targetId||pages[0]?.targetId,message:'연동 엣지에서 직접 로그인해주세요.'};
 }catch(error){cdp?.close();cdp=null;browser?.kill();throw error;}finally{starting=false;}
}
async function calendarSession(){
 if(!cdp)throw Error('연동용 브라우저를 먼저 여세요.');
 const {targetInfos}=await cdp.call('Target.getTargets');
 const pages=targetInfos.filter(t=>{try{return t.type==='page'&&new URL(t.url).hostname==='calendar.worksmobile.com';}catch{return false;}});
 const main=pages.filter(t=>{try{return new URL(t.url).pathname.replace(/\/$/,'')==='/web/calendar/main';}catch{return false;}}),targets=main.length===1?main:pages;
 if(targets.length!==1)throw Error('로그인 후 캘린더 탭 하나를 열어주세요. 로그인 페이지에서는 내용을 읽지 않습니다.');
 const {sessionId}=await cdp.call('Target.attachToTarget',{targetId:targets[0].targetId,flatten:true});
 const current=cdp;return {call:(method,params)=>current.call(method,params,sessionId),subscribe(fn){const listener=event=>{if(event.sessionId===sessionId)fn(event);};current.listeners.add(listener);return ()=>current.listeners.delete(listener);},async evaluate(expression){
  await cdp.ready;const id=++cdp.counter;
  const result=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{cdp.pending.delete(id);reject(Error('화면 읽기 대기 시간 초과'));},10000);cdp.pending.set(id,{resolve,reject,timer});cdp.ws.send(JSON.stringify({id,method:'Runtime.evaluate',params:{expression,returnByValue:true,awaitPromise:true},sessionId}));});
  return decodePageResult(result);
 },async close(){await current.call('Target.detachFromTarget',{sessionId});}};
}
let pmxSession=null,pmxHeaders={};
async function attachPmx(targetId){
 if(pmxSession?.targetId===targetId&&pmxSession.cdp===cdp)return pmxSession;
 if(pmxSession){pmxSession.cdp.listeners.delete(pmxSession.listener);await pmxSession.cdp.call('Target.detachFromTarget',{sessionId:pmxSession.sessionId}).catch(()=>{});}
 pmxHeaders={};const current=cdp,{sessionId}=await current.call('Target.attachToTarget',{targetId,flatten:true});
 const listener=e=>{if(e.sessionId!==sessionId)return;if(e.method==='Network.requestWillBeSent'){let url;try{url=new URL(e.params.request.url);}catch{return;}if(url.origin!=='https://pmx.gsenc.com'||!url.pathname.startsWith('/qse/api/'))return;for(const [name,value]of Object.entries(e.params.request.headers||{}))if(/^(authorization|x-csrf-token|x-xsrf-token|x-auth-token)$/i.test(name)&&typeof value==='string'&&value.length<8000)pmxHeaders[name]=value;}if(e.method==='Network.responseReceived'&&[401,403].includes(e.params.response?.status))pmxHeaders={};};
 current.listeners.add(listener);await current.call('Network.enable',{},sessionId);pmxSession={targetId,sessionId,cdp:current,listener};return pmxSession;
}
async function openPmx(){const result=await launch('edge','pmx');const {targetInfos}=await cdp.call('Target.getTargets'),target=targetInfos.find(t=>t.targetId===result.targetId)||targetInfos.find(t=>t.type==='page'&&/^https:\/\/pmx\.gsenc\.com(?:[/?#]|$)/.test(t.url));if(target){const first=pmxSession?.targetId!==target.targetId;const session=await attachPmx(target.targetId);if(first)await session.cdp.call('Page.reload',{},session.sessionId).catch(()=>{});}return {...result,message:'연동 엣지의 PMX 탭에서 로그인하고 조회해주세요.'};}
async function pmxRead(project,date){
 if(!cdp)throw Error('PMX 로그인 창을 먼저 여세요.');const {targetInfos}=await cdp.call('Target.getTargets');const target=targetInfos.find(t=>t.type==='page'&&/^https:\/\/pmx\.gsenc\.com(?:[/?#]|$)/.test(t.url))||targetInfos.find(t=>t.targetId===pmxSession?.targetId);if(!target)throw Error('연동 엣지의 PMX 탭에서 로그인해주세요.');const session=await attachPmx(target.targetId);const result=await session.cdp.call('Runtime.evaluate',{expression:pmxReadExpression(project,date,pmxHeaders),returnByValue:true,awaitPromise:true},session.sessionId);return decodePageResult(result);
}
async function onPage(expression){const session=await calendarSession();try{return await session.evaluate(expression);}finally{await session.close();}}
const server=http.createServer(async(req,res)=>{
 res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');
 try{
  const url=new URL(req.url,'http://127.0.0.1');
  if(req.method==='GET'&&url.pathname==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');return res.end(fs.readFileSync(path.join(root,'works-probe.html')));}
  if(req.headers['x-probe-key']!==key) {res.writeHead(403);return res.end('{}');}
  if(req.headers.origin&&req.headers.origin!==`http://127.0.0.1:${server.address().port}`){res.writeHead(403);return res.end('{}');}
  let body='';for await(const chunk of req){body+=chunk;if(body.length>4096){res.writeHead(413);return res.end('{}');}}
  let value={};if(body)value=JSON.parse(body);let result;
  if(req.method==='POST'&&url.pathname==='/pmx/open')result=await openPmx();
  else if(req.method==='POST'&&url.pathname==='/pmx/read')result=await pmxRead(value.project,value.date);
  else if(req.method==='POST'&&url.pathname==='/open')result=await launch(value.browser==='edge'?'edge':'chrome');
  else if(req.method==='POST'&&url.pathname==='/network/start')result=await network.start(await calendarSession(),value);
  else if(req.method==='GET'&&url.pathname==='/network/status')result=await network.fallback();
  else if(req.method==='POST'&&url.pathname==='/network/select')result=await network.select(value);
  else if(req.method==='POST'&&url.pathname==='/network/stop')result=await network.stop();
  else if(req.method==='POST'&&url.pathname==='/select')result=await onPage(captureExpression);
  else if(req.method==='POST'&&url.pathname==='/diagnostic-start')result=await onPage(beginDiagnosticExpression);
  else if(req.method==='POST'&&url.pathname==='/diagnostic-read')result=await onPage(readDiagnosticExpression(value.includeText));
  else if(req.method==='POST'&&url.pathname==='/batch'){if(!/^\d{4}-\d{2}-\d{2}$/.test(value.date)||typeof value.calendar!=='string'||!value.calendar.trim()||value.calendar.length>100)throw Error('날짜와 캘린더 이름을 확인해주세요.');result=await onPage(batchExpression(value.date,value.calendar));}
  else if(req.method==='GET'&&url.pathname==='/preview')result=await onPage('window.__mouseonCalendarCapture?.items || []');
  else {res.writeHead(404);return res.end('{}');}
  res.setHeader('Content-Type','application/json');res.end(JSON.stringify(result));
 }catch(e){res.writeHead(400,{'Content-Type':'application/json'});res.end(JSON.stringify({error:e.message}));}
});
server.listen(0,'127.0.0.1',()=>{
 const url=`http://127.0.0.1:${server.address().port}/#key=${key}`;
 console.log('MouseOn calendar trial is ready. Keep this window open.');process.send?.({type:'ready',url,key});
 if(process.env.WORKS_NO_BROWSER!=='1'){
 const command=process.platform==='win32'?['cmd.exe',['/d','/c','start','',url]]:['xdg-open',[url]];
 const ui=spawn(...command,{stdio:'ignore'});ui.on('error',()=>console.error('Could not open the trial control screen.'));
 }
});
function stop(){void network.stop();cdp?.close();browser?.kill();server.close();}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
