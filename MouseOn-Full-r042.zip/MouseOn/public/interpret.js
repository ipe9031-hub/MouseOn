import {regionPieces,regionArea} from './region-geometry.js';
import './vendor/polygon-clipping.js';
import {validDate} from './calendar.js';
export const kindInfo={formwork:['갱폼','#c2410c'],rope:['로프 작업','#be185d'],sky:['스카이·고소작업차','#9333ea'],roller:['롤러','#a16207'],tower:['타워크레인','#6d28d9'],mobile:['이동식 크레인','#7c3aed'],concrete:['타설','#0369a1'],mixer:['레미콘','#1d4ed8'],excavator:['굴착기','#b45309'],forklift:['지게차·하역','#047857'],dump:['덤프','#4d7c0f'],other:['기타','#475569']};
export function kindOf(text){return /스카이|고소\s*작업\s*차|고소\s*작업\s*대|붐\s*리프트|\bsky(?:lift)?\b/i.test(text)?'sky':/포장|투수\s*콘|롤러|로울러|진동\s*로라|로드\s*롤러/i.test(text)?'roller':/갱폼/.test(text)?'formwork':/로프/.test(text)?'rope':/타워/.test(text)?'tower':/크레인|인양|양중/.test(text)?'mobile':/레미콘/.test(text)?'mixer':/타설|콘크리트/.test(text)?'concrete':/지게차|하역/.test(text)?'forklift':/덤프/.test(text)?'dump':/굴착|백호/.test(text)?'excavator':'other';}
export function excludedSchedule(entry){
 const title=(entry.text||entry.original||entry.title||'').split(/\r?\n/)[0];
 return !mapCalendar(entry.calendar)||/^\s*7\.\s*/.test(title)||/미팅|회의|행사|회식|건강검진|안전교육|점검(?!구|로|통로|발판|계단)/.test(title);
}
// Site convention: road/ground passage pours use an excavator; structure pours use a pump.
// This is an editable interpretation rule, not verification of equipment on site.
export function concreteContext(text){
 const clean=text.normalize('NFKC').replace(/\s+/g,' '),compact=clean.replace(/\s/g,'');
 const target=compact.replace(/(?:펌프카|레미콘|차량|장비)?[^,;。\n]*?(?:도로|통로|통행로|진입로|출입로|동선)(?:확보|정리|조정|이동|진입|통제|개방|사용)(?:후|하고|및)?/g,' ');
 const explicit=target.replace(/(?:굴착기|굴삭기|백호|포크레인|펌프\s*카|콘크리트\s*펌프|붐\s*펌프|라인\s*펌프)\s*(?:미사용|없음|제외|사용하지\s*않음)/g,'');
 const excavator=/굴착기|굴삭기|백호|포크레인/.test(explicit),pump=/펌프\s*카|콘크리트\s*펌프|붐\s*펌프|라인\s*펌프/.test(explicit);
 if(pump||excavator)return {method:pump&&excavator?'mixed':pump?'pump':'excavator',inferred:false,basis:'원문에 명시된 장비'};
 const locations=/(?:피난|소방|비상|가설|단지내|단지|내부|외부|구내|연결|진입|출입|우회|임시|작업|차량|보행자전용|보행자|보행|산책|자전거)?(?:도로|통로|통행로)|진출입(?:로|구)?|경계석|진입로|출입로|대피로|피난로|연결로|우회로|작업로|비상차로|(?:비상|피난|대피|소방|차량|보행)동선|보행로|산책로|차도|보도|인도|자전거길|경사로|램프|RAMP/gi;
 // Discard access/logistics clauses before deciding what is actually being poured.
 const civilGround=/진출입|산책로|경계석/.test(target),strongStructure=/(?:슬래브|스라브|벽체|기둥|코어|옥상|지붕|피난계단|피난층|\d+층)[^,;。]{0,14}타설/.test(target);
 const location=target.replace(/도로명|도로교통법|도로점용허가|보도자료|통로안내표지/g,' ').replace(/(?:도로|통로)(?:측|옆|인근|주변)(?=.{0,8}\d+동)/g,' ').match(locations)?.[0],structural=/(?:슬래브|스라브|벽체|기둥|보타설|거더|기초|매트|코어|옥상|지붕|피난계단|피난층|피난안전구역|실내|내부복도|공용복도|\d+층)[^,;。]{0,14}타설/.test(target)&&(!civilGround||strongStructure);
 const excludedPump=/(?:펌프카|콘크리트펌프|붐펌프|라인펌프)(?:미사용|없음|제외|사용하지않음)/.test(compact),excludedExcavator=/(?:굴착기|굴삭기|백호|포크레인)(?:미사용|없음|제외|사용하지않음)/.test(compact);
 if(location&&!structural&&excludedExcavator||(!location||structural)&&excludedPump)return {method:'unspecified',inferred:true,basis:'장비 제외 표현으로 사용 장비 확인 필요'};
 if(location&&!structural)return {method:'excavator',inferred:true,basis:location+' 등 지상 통행 공간 타설'};
 return {method:'pump',inferred:true,basis:structural?'건물 구조부 타설':'일반 타설 기본 규칙'};
}
export function isMaterialDelivery(text){const value=String(text||'').normalize('NFKC').replace(/\s/g,'');return /\d+(?:[.,]\d+)?(?:톤|ton|t)(?:급|차량|차|트럭|카고|윙바디|덤프|탑차|화물차)?(?:[(),·/\-])?\d+대/i.test(value);}
export function classifyWork(text,calendar='',hazards=[]){
 const compact=text.replace(/\s/g,''),clean=text.replace(/(?:굴착기|굴삭기|백호|포크레인|펌프카)\s*(?:미사용|없음|제외)/g,''),landscaping=/식재|수목|조경|녹지|잔디|관목|교목/.test(text);
 const excavator=/굴착기|굴삭기|백호|포크레인/.test(clean),pump=/펌프\s*카|콘크리트\s*펌프|붐\s*펌프|라인\s*펌프/.test(clean),pouring=/타설/.test(text)||pump&&/^(?:1[.\s]*)?타설/.test(calendar.replace(/\s/g,''));
 const hazard=hazards.find(h=>{const name=h.name.replace(/\s/g,'').replace(/작업$/,'');return name.length>=2&&compact.includes(name);});
 const calendarHigh=/^(?:3[.\s]*)?고위험/.test(calendar.replace(/\s/g,'')),numberedHigh=/^\s*3\.\s*/.test(text),wordHigh=/갱폼|로프|고소|해체|인양|양중|밀폐|화기|용접|고위험/.test(clean),high=calendarHigh||numberedHigh||wordHigh||Boolean(hazard);
 let icon=kindOf(clean),equipmentInferred=false,equipmentHint='',concreteMethod=null;
 if(pouring&&!(icon==='roller'&&!pump&&!excavator)){const context=concreteContext(text);concreteMethod=context.method;equipmentInferred=context.inferred;equipmentHint=context.inferred?context.basis+(concreteMethod==='unspecified'?'':' · '+(concreteMethod==='excavator'?'굴착기':'펌프카')+' 표시 추정'):'';icon=concreteMethod==='excavator'?'excavator':'concrete';}
 else if(excavator){icon='excavator';}
 else if(/진출입|산책로|경계석/.test(text)&&['other','concrete'].includes(icon)&&!/(?:굴착기|굴삭기|백호|포크레인)\s*(?:미사용|없음|제외|사용하지)/.test(text)){icon='excavator';equipmentInferred=true;equipmentHint='진출입·산책로·경계석 부대토목 · 굴착기 표시 추정';}
 else if(landscaping&&icon==='other'&&!/(?:굴착기|굴삭기|백호|포크레인)\s*(?:미사용|없음|제외|사용하지)/.test(text)){icon='excavator';equipmentInferred=true;equipmentHint='식재·조경: 굴착기 사용 추정 · 장비 확인 필요';}
 if(high&&icon==='other')icon='hazard';
 const vertical=safetyProfile({title:text});
 return {icon,materialDelivery:isMaterialDelivery(text),riskLevel:high?'high':'normal',riskBasis:calendarHigh?'캘린더 고위험 분류':numberedHigh?'원문의 고위험 분류 번호':hazard?'현장 고위험 종류':wordHigh?'원문의 고위험 작업 표현':'일반 작업 분류',hazardId:hazard?.id||null,hazardName:hazard?.name||null,hazardColor:high?(hazard?.color||'#b4233d'):null,equipmentInferred,equipmentHint,concreteMethod,workLevel:vertical.role,workLevelBasis:vertical.basis};
}
export function isPumpConcrete(task){if(task.icon==='roller')return false;const text=[task.original||task.title,task.equipment,task.detail].filter(Boolean).join(' ');if(task.concreteMethod&&task.concreteMethod!=='unspecified')return ['pump','mixed'].includes(task.concreteMethod);return /타설/.test(text)&&['pump','mixed'].includes(concreteContext(text).method);}
// Safety review is based on the activity and its influence zone; equipment display guesses are not evidence.
function safetyText(task){return [...new Set([task.original||task.title,task.detail].filter(Boolean))].join(' ').normalize('NFKC');}
export function safetyProfile(task){
 const raw=safetyText(task),controls=[...new Set(raw.match(/하부\s*출입\s*통제|출입\s*금지|낙하물\s*방지망|방호\s*선반|수직\s*보호망|작업\s*시간\s*분리/g)||[])];
 const text=raw.replace(/(?:스카이|로프|고소\s*작업(?:대|차)?|비계|갱폼|인양|양중)[^,;\n]{0,20}(?:철수|종료|완료|중지)\s*(?:이후|후)/g,' ').replace(/(?:스카이|로프|고소\s*작업(?:대|차)?|비계|갱폼|인양|양중)(?:\s*작업|\s*사용)?\s*(?:미사용|사용\s*안\s*함|사용하지\s*않음|없음|제외|종료|완료)/g,' ');
 const m=text.match(/(?<![\d.])(\d+(?:\.\d+)?)\s*(?:미터|m)(?![a-z])/i),floor=text.match(/(?<![\d지하])(\d+)\s*층/),height=m?{value:Number(m[1]),unit:'m'}:floor?{value:Number(floor[1]),unit:'floor'}:null;
 const transport=isMaterialDelivery(text)&&!/(인양|양중|하역|상하차|상차|하차|설치|해체|시공|보수|도장|방수|타설)/.test(text)||/(반입|입고|반출|배송|적치)/.test(text)&&!/(인양|양중|하역|상차|하차|설치|해체|시공|보수|도장|방수|타설)/.test(text);
 if(/회의|미팅|교육|작업계획서|계획\s*(?:수립|작성)/.test(text)||transport||!text.trim())return {role:'unknown',basis:'위험 작업행위 미확인',controls,height};
 const sky=/스카이|고소\s*작업\s*(?:차|대)|붐\s*리프트|\bsky(?:lift)?\b/i.test(text)||!task.sourceKey&&task.icon==='sky'&&!/스카이.*(?:미사용|철수|완료)/.test(raw);
 // Site preference: sky occupants are lower exposure recipients of rope/overhead work.
 if(sky)return {role:'lower',exposure:'sky',basis:'스카이 탑승 작업자',controls,height};
 const indoor=/실내|세대\s*내부|내부\s*복도|공용\s*복도/.test(text)&&!/외벽|외부|인양|양중|개구부|개방/.test(text);
 const lifting=/인양|양중/.test(text),rope=/로프\s*(?:작업|공)|달비계.{0,12}(?:작업|설치|해체)|외벽.{0,10}로프|로프.{0,10}(?:도장|방수|보수|설치)/.test(text)||!task.sourceKey&&task.icon==='rope'&&!/로프.*(?:미사용|철수|완료)/.test(raw);
 const dismantle=/비계|갱폼|거푸집/.test(text)&&/해체|조립|인상|탈형|철거/.test(text),exterior=/외벽|옥상|지붕|상부|최상층/.test(text)&&/작업|설치|해체|철거|도장|보수|방수|용접|절단|타설/.test(text);
 if(!indoor&&(lifting||rope||dismantle||exterior))return {role:'upper',basis:lifting?'인양 하물':rope?'로프 작업':dismantle?'비계·가설재 조립/해체':'외부 고소 작업',controls,height};
 const groundPour=/타설/.test(text)&&concreteContext(text.replace(/펌프\s*카|콘크리트\s*펌프|굴착기|굴삭기|백호|포크레인/g,'')).method==='excavator';
 const ground=text.match(/식재|수목|조경|녹지|잔디|경계석|산책로|진출입|포장|토공|굴착\s*작업|굴삭\s*작업|기초\s*(?:타설|공사)|버림\s*타설|지상\s*(?:작업|통행|시공)|하부\s*(?:작업|통행)|하역|하차|상차/);
 if((ground||groundPour)&&!/하부\s*작업\s*(?:없음|미실시)/.test(text))return {role:'lower',exposure:'ground',basis:(ground?.[0]||'지상 통행 공간 타설')+' 작업자',controls,height:height||{value:0,unit:'m'}};
 if(!indoor&&(/펜트\s*하우스|PENTHOUSE|(?<![지하\d])(?:[2-9]|[1-9]\d+)\s*층/i.test(text))&&/작업|설치|해체|철거|도장|보수|타설/.test(text))return {role:'upper',basis:'층·높이 표현',uncertainHeight:true,controls,height};
 return {role:'unknown',basis:'작업 높이·행위 미확인',controls,height};
}
export function workTimeWindows(task){
 const text=safetyText(task),base=Date.parse(task.date+'T00:00:00+09:00')/60000;if(!Number.isFinite(base))return [];
 const result=[],pattern=/(\d{1,2})(?::(\d{2})|시(?:\s*(\d{1,2})분)?)\s*[~∼～-]\s*(\d{1,2})(?::(\d{2})|시(?:\s*(\d{1,2})분)?)/g;
 for(const m of text.matchAll(pattern)){const h=Number(m[1]),k=Number(m[4]),a=Number(m[2]||m[3]||0),b=Number(m[5]||m[6]||0);if(h>23||k>24||a>59||b>59||k===24&&b)continue;const start=h*60+a;let end=k*60+b;if(end===start)continue;if(end<start)end+=1440;result.push({start:base+start,end:base+end});}return result;
}
export function safetyTasksForDates(tasks,dates){return tasks.filter(task=>dates.includes(task.date)||workTimeWindows(task).some(w=>dates.some(date=>{const d=Date.parse(date+'T00:00:00+09:00')/60000;return w.start<d+1440&&w.end>d;})));}
export function shortSafetyTitle(task){
 let title=(task.original||task.title||'작업').split('\n')[0].replace(/^\s*[1-7][.．]\s*/,'').replace(/(?<!\d)\d{1,4}(?:\s*[,、·/]\s*\d{1,4})*\s*동/g,'').replace(/\d{1,2}(?::\d{2}|시(?:\s*\d{1,2}분)?)\s*[~∼～-]\s*\d{1,2}(?::\d{2}|시(?:\s*\d{1,2}분)?)/g,'').replace(/\s+/g,' ').trim();
 return title.length>36?title.slice(0,35)+'…':title||'작업';
}
export function verticalConflictPairs(tasks,regions=[]){
 const groups=new Map(),byId=new Map(regions.map(r=>[r.id,r]));
 const origin=t=>String(t.sourceEventKey||t.sourceKey||t.id),geometry=t=>t.workArea?.length>=3?{region:{points:t.workArea},explicit:true}:t.shape==='area'&&t.points?.length>=3?{region:{points:t.points},explicit:true}:!['surrounding','between'].includes(t.placement)&&byId.has(t.workRegionId||t.regionId)?{region:byId.get(t.workRegionId||t.regionId),explicit:false}:null;
 const prepared=tasks.map(task=>({task,profile:safetyProfile(task),windows:workTimeWindows(task),shape:geometry(task)}));
 for(let i=0;i<prepared.length;i++)for(let j=i+1;j<prepared.length;j++){
  let a=prepared[i],b=prepared[j];if(origin(a.task)===origin(b.task))continue;
  if(a.profile.role==='lower'&&b.profile.role==='upper')[a,b]=[b,a];if(a.profile.role!=='upper'||b.profile.role!=='lower')continue;
  const timeKnown=Boolean(a.windows.length&&b.windows.length),overlaps=timeKnown&&a.windows.some(x=>b.windows.some(y=>x.start<y.end&&y.start<x.end));if(timeKnown&&!overlaps||!timeKnown&&a.task.date!==b.task.date)continue;
  const upper=a.task,lower=b.task,ua=upper.workAnchor||[upper.x,upper.y],lb=lower.workAnchor||[lower.x,lower.y],ah=a.profile.height,bh=b.profile.height;
  if(ah&&bh&&ah.unit===bh.unit&&ah.value<bh.value)continue;
  let point=null,footprint=null,spaceKnown=Boolean(a.shape?.explicit&&b.shape?.explicit);
  if(a.shape&&b.shape){try{const pieces=globalThis.polygonClipping.intersection(regionPieces(a.shape.region),regionPieces(b.shape.region));if(pieces.length&&regionArea({pieces})>1e-10){footprint={pieces,points:pieces[0][0]};point=regionPoint(footprint);}}catch{continue;}}
  else if(a.shape&&lb.every(Number.isFinite)&&insideRegion(lb,a.shape.region))point=lb;
  else if(b.shape&&ua.every(Number.isFinite)&&insideRegion(ua,b.shape.region))point=ua;
  else if(!regions.length&&(upper.workRegionId||upper.regionId)&&(upper.workRegionId||upper.regionId)===(lower.workRegionId||lower.regionId)&&[...ua,...lb].every(Number.isFinite))point=[(ua[0]+lb[0])/2,(ua[1]+lb[1])/2];
  if(!point)continue;
  const needs=[];if(!spaceKnown)needs.push('작업영역 확인 필요');if(!timeKnown)needs.push('시간 확인 필요');if(a.profile.uncertainHeight||b.profile.exposure==='sky'&&!(ah&&bh&&ah.unit===bh.unit&&ah.value>bh.value))needs.push('작업 높이 확인 필요');
  const status=needs.length?'review':'overlap',day=upper.date===lower.date?upper.date:[upper.date,lower.date].sort().join('/'),id=JSON.stringify([day,...[origin(upper),origin(lower)].sort()]);
  const labels=[upper.workRegionId||upper.regionId,lower.workRegionId||lower.regionId].map(id=>byId.get(id)?.name).filter(Boolean),location=spaceKnown?'지정 작업영역':[...new Set(labels)].join(' · ')||'작업 위치';
  const reason='상하 작업 확인: '+upper.title+' (상부 단서) / '+lower.title+' (하부 단서) · '+(timeKnown?'예정 시간 겹침':'시간 미확인')+' · '+needs.join(' · ')+' · 실제 높이·동시작업 여부 확인 필요';
  let group=groups.get(id);if(!group){group={id,taskIds:[],x:point[0],y:point[1],footprint,reason,status,upperTitle:shortSafetyTitle(upper),lowerTitle:shortSafetyTitle(lower),upperOriginal:upper.original||upper.title,lowerOriginal:lower.original||lower.title,upperBasis:a.profile.basis,lowerBasis:b.profile.basis,timeLabel:timeKnown?'예정 시간 겹침':'시간 확인 필요',controls:[...new Set([...a.profile.controls,...b.profile.controls])],needs:[],zones:[]};groups.set(id,group);}
  group.taskIds=[...new Set([...group.taskIds,upper.id,lower.id])];group.needs=[...new Set([...group.needs,...needs])];if(status==='review')group.status='review';
  const zoneKey=JSON.stringify([point.map(v=>v.toFixed(5)),footprint?.pieces]);let zone=group.zones.find(z=>z.key===zoneKey);if(!zone){zone={key:zoneKey,x:point[0],y:point[1],footprint,location,status,needs:[...needs]};group.zones.push(zone);}else{zone.needs=[...new Set([...zone.needs,...needs])];if(status==='review')zone.status='review';}
 }
 return [...groups.values()];
}
export function verticalConflicts(tasks,regions=[]){const result=new Map();for(const pair of verticalConflictPairs(tasks,regions))for(const id of pair.taskIds){const reasons=result.get(id)||[];reasons.push(pair.reason);result.set(id,reasons);}return result;}
function placeName(text){return text.normalize('NFKC').toUpperCase().replace(/(?<![A-Z])GATE(?=$|[^A-Z]|[A-Z](?![A-Z]))/g,'게이트').replace(/(?<![A-Z])RAMP(?=$|[^A-Z]|[A-Z](?![A-Z]))/g,'램프').replace(/(?<![\d:A-Z])(\d{1,3}|[A-Z])\s*(?:번\s*)?(게이트|램프)(?!\s*#?\s*[\dA-Z])/g,'$2$1').replace(/(게이트|램프)\s*#?\s*(\d{1,3}|[A-Z])(?:번)?/g,'$1$2');}
function hit(text,alias){const a=alias.replace(/\s/g,'');let from=0,i;while((i=text.indexOf(a,from))!==-1){if(!(/^\d/.test(a)&&i>0&&/\d/.test(text[i-1]))&&!(/\d$/.test(a)&&/\d/.test(text[i+a.length]||''))&&!(/[A-Z]$/.test(a)&&/[A-Z0-9]/.test(text[i+a.length]||'')))return true;from=i+1;}return false;}
export function matchRegions(text,regions){
 const facilities=[];const normalized=placeName(text).replace(/(?:근린생활시설|근생)\s*(?:제\s*)?\d{1,3}(?:\s*[,、·/]\s*(?:(?:근린생활시설|근생)\s*)?(?:제\s*)?\d{1,3})*(?:\s*동)?/g,part=>{facilities.push(...[...part.matchAll(/\d+/g)].map(m=>'근생'+Number(m[0])));return ' ';});
 const facilityText=facilities.join('|');
 const ranged=normalized.replace(/(?<!\d)(\d{1,4})\s*[~〜∼-]\s*(\d{1,4})\s*동/g,(all,a,b)=>{const from=Number(a),to=Number(b);return to>=from&&to-from<=100?Array.from({length:to-from+1},(_,i)=>(from+i)+'동').join(' '):all;});
 const expanded=ranged.replace(/(?<!\d)(\d{1,4}(?:\s*[,、·/]\s*\d{1,4})+)\s*동/g,(_,list)=>list.split(/\s*[,、·/]\s*/).map(n=>n+'동').join(' '));
 const located=expanded.replace(/(?<![\d:/])(\d{1,4}(?:\s*[,、·]\s*\d{1,4})+)(\s*)([가-힣]*)/g,(all,list,space,word,offset)=>{
  if(/^(?:동|층|호|시|분|일|월|년|명|대|톤|개|미터|시간)/.test(word)||/(?:시간|시각|날짜|일자|수량|대수|인원)\s*$/.test(expanded.slice(Math.max(0,offset-12),offset)))return all;
  return list.split(/\s*[,、·]\s*/).map(n=>n+'동').join(' ')+space+word;
 });
 const clean=located.replace(/(?<=\d)\s+(?=\d)/g,'|').replace(/\s/g,'');
 const numbers=regions.map(r=>({region:r,number:r.name?.normalize('NFKC').replace(/\s/g,'').match(/^(\d{1,4})동?$/)?.[1]}));
 return regions.filter(r=>{
  const names=[r.name,...(r.aliases||[])];const number=numbers.find(n=>n.region===r)?.number;
  if(number?.length===3){const short=String(Number(number.slice(1))),exact=numbers.some(n=>n.number&&Number(n.number)===Number(short));const peers=numbers.filter(n=>n.number?.length===3&&Number(n.number.slice(1))===Number(short));if(!exact&&peers.length===1)names.push(short+'동');}
  return names.filter(a=>a?.trim()).some(a=>{const canonical=placeName(a);const facility=canonical.replace(/근린생활시설/g,'근생').replace(/\s/g,'').replace(/^근생제?/,'근생').replace(/(근생\d+)동$/,'$1');return /^근생\d+$/.test(facility)?hit(facilityText,facility):hit(clean,canonical);});
 });
}
export function mapCalendar(calendar=''){return !/^(?:7[.\s]*)?(?:회의[,·\s]*행사|회의[·,\s]*행사[·,\s]*대내외점검|대내외점검)/.test(calendar.normalize('NFKC').replace(/\s/g,''));}
export const placementVersion='r042';
export function interpretAll(entry,regions,outline=null,hazards=[]){
 if(excludedSchedule(entry))return [];const candidate=interpret(entry,regions,outline,hazards);if(candidate.requiresPositionConfirmation)return [candidate];
 const matches=matchRegions(entry.text,regions);
 // Relative locations need confirmation; do not pretend the named buildings are the work location.
 if(matches.length<2||/사이|사잇|중간/.test(entry.text))return [candidate];
 return matches.map(region=>{const ground=candidate.placement==='equipment-ground',point=ground?equipmentGroundPoint(region,regions,outline):candidate.placement==='surrounding'?surroundingPoint(region,regions,outline):regionPoint(region);const reasons=candidate.reasons.filter(r=>!r.includes('여러 영역')&&!r.includes('주변 위치'));if(!point)reasons.push('영역 바깥의 주변 위치 확인 필요');return {...candidate,...(ground?{workRegionId:region.id,workAnchor:regionPoint(region)}:{}),regionId:region.id,x:point?.[0]??null,y:point?.[1]??null,reasons};});
}

export function inside(point,polygon){let yes=false;for(let i=0,j=polygon.length-1;i<polygon.length;j=i++){const a=polygon[i],b=polygon[j];if((a[1]>point[1])!==(b[1]>point[1])&&point[0]<(b[0]-a[0])*(point[1]-a[1])/(b[1]-a[1])+a[0])yes=!yes;}return yes;}
export function insideRegion(point,region){return regionPieces(region).some(p=>inside(point,p[0])&&!p.slice(1).some(hole=>inside(point,hole)));}
export function regionPoint(region,slot=0){if(region.pieces){for(const polygon of regionPieces(region)){const xs=polygon[0].map(p=>p[0]),ys=polygon[0].map(p=>p[1]);for(let step=0;step<900;step++){const x=step===0?.5:((step+slot*13)%30+.5)/30,y=step===0?.5:(Math.floor((step+slot*13)%900/30)+.5)/30,q=[Math.min(...xs)+(Math.max(...xs)-Math.min(...xs))*x,Math.min(...ys)+(Math.max(...ys)-Math.min(...ys))*y];if(inside(q,polygon[0])&&!polygon.slice(1).some(h=>inside(q,h)))return q;}}return region.points[0];}const p=region.points;const xs=p.map(a=>a[0]),ys=p.map(a=>a[1]);const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);const center=[(minX+maxX)/2,(minY+maxY)/2];if(slot>0){for(let step=0;step<50;step++){const angle=(slot+step)*2.399963;const radius=.16+(slot%3)*.09;const q=[center[0]+(maxX-minX)*radius*Math.cos(angle),center[1]+(maxY-minY)*radius*Math.sin(angle)];if(inside(q,p))return q;}}if(inside(center,p))return center;for(let y=1;y<30;y++)for(let x=1;x<30;x++){const q=[minX+(maxX-minX)*x/30,minY+(maxY-minY)*y/30];if(inside(q,p))return q;}return p[0];}
// Closest boundary pair, including shared edges; reject actual overlap rather than guessing.
export function betweenPoint(a,b){
 const ringsA=regionPieces(a).flatMap(p=>p),ringsB=regionPieces(b).flatMap(p=>p);
 const projection=(p,u,v)=>{const dx=v[0]-u[0],dy=v[1]-u[1],length=dx*dx+dy*dy,t=length?Math.max(0,Math.min(1,((p[0]-u[0])*dx+(p[1]-u[1])*dy)/length)):0;return [u[0]+t*dx,u[1]+t*dy];};
 const onBoundary=(p,rings)=>rings.some(r=>r.some((u,i)=>{const q=projection(p,u,r[(i+1)%r.length]);return Math.hypot(p[0]-q[0],p[1]-q[1])<1e-9;}));
 if(ringsA.flat().some(p=>insideRegion(p,b)&&!onBoundary(p,ringsB))||ringsB.flat().some(p=>insideRegion(p,a)&&!onBoundary(p,ringsA)))return null;
 const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);let distance=Infinity,points=[];
 const consider=(p,q)=>{const d=(p[0]-q[0])**2+(p[1]-q[1])**2,m=[(p[0]+q[0])/2,(p[1]+q[1])/2];if(d<distance-1e-12){distance=d;points=[m];}else if(Math.abs(d-distance)<1e-12)points.push(m);};
 for(const ra of ringsA)for(const rb of ringsB)for(let i=0;i<ra.length;i++)for(let j=0;j<rb.length;j++){const u=ra[i],v=ra[(i+1)%ra.length],w=rb[j],z=rb[(j+1)%rb.length];if(cross(u,v,w)*cross(u,v,z)<-1e-14&&cross(w,z,u)*cross(w,z,v)<-1e-14)return null;consider(u,projection(u,w,z));consider(v,projection(v,w,z));consider(projection(w,u,v),w);consider(projection(z,u,v),z);}
 if(!points.length)return null;const point=[points.reduce((n,p)=>n+p[0],0)/points.length,points.reduce((n,p)=>n+p[1],0)/points.length];return insideRegion(point,a)&&!onBoundary(point,ringsA)||insideRegion(point,b)&&!onBoundary(point,ringsB)?null:point;
}
// Sample short offsets outside a named footprint, retaining the site outline and other fixed buildings.
export function surroundingPoint(region,regions,outline=null){
 const center=regionPoint(region),candidates=[];
 for(const polygon of regionPieces(region))for(const ring of polygon)for(let i=0;i<ring.length;i++){
  const a=ring[i],b=ring[(i+1)%ring.length],dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(length<1e-10)continue;
  for(const t of [.25,.5,.75])for(const side of [-1,1])for(const distance of [.008,.015,.025]){
   const q=[a[0]+dx*t-side*dy/length*distance,a[1]+dy*t+side*dx/length*distance];
   if(q.some(v=>v<0||v>1)||insideRegion(q,region)||outline?.length&&!inside(q,outline))continue;
   if(regions.some(r=>r.id!==region.id&&r.fixed&&insideRegion(q,r)))continue;
   candidates.push({point:q,score:Math.hypot(q[0]-center[0],q[1]-center[1])+distance});
  }
 }
 candidates.sort((a,b)=>a.score-b.score);return candidates[0]?.point||null;
}
// Equipment pins represent ground staging; building footprints remain provisional influence zones.
export const isBuildingRegion=region=>/\d+\s*동|근생|근린생활시설/.test(region.name||'');
export function equipmentGroundPoint(region,regions,outline=null){
 const buildings=regions.filter(isBuildingRegion),center=regionPoint(region),candidates=[];
 for(const polygon of regionPieces(region))for(const ring of polygon)for(let i=0;i<ring.length;i++){
  const a=ring[i],b=ring[(i+1)%ring.length],dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(!length)continue;
  for(const t of [.25,.5,.75])for(const side of [-1,1])for(const distance of [.025,.04,.06]){
   const point=[a[0]+dx*t-side*dy/length*distance,a[1]+dy*t+side*dx/length*distance];
   if(point.some(v=>v<0||v>1)||insideRegion(point,region)||buildings.some(r=>insideRegion(point,r))||outline?.length&&!inside(point,outline))continue;
   candidates.push({point,score:Math.hypot(point[0]-center[0],point[1]-center[1])+distance});
  }
 }
 candidates.sort((a,b)=>a.score-b.score);return candidates[0]?.point||null;
}
export function interpret(entry,regions,outline=null,hazards=[]){
 if(typeof entry?.text!=='string'||!validDate(entry.date))throw Error('일정 원문·날짜를 확인해주세요.');
 const matches=matchRegions(entry.text,regions),relative=/사이|사잇|중간/.test(entry.text),surrounding=/주변|인근|근처/.test(entry.text),region=!relative&&matches.length===1?matches[0]:null;
 const classification=classifyWork(entry.text,entry.calendar||'',hazards),groundEquipment=['excavator','mobile','sky','concrete','roller','forklift','dump','mixer'].includes(classification.icon),ground=groundEquipment&&!relative&&!surrounding;
 const point=relative?(matches.length===2?betweenPoint(matches[0],matches[1]):null):(region?(ground?equipmentGroundPoint(region,regions,outline):surrounding?surroundingPoint(region,regions,outline):regionPoint(region)):null);
 const reasons=[];if(groundEquipment)reasons.push('지상 장비 아이콘 · 실제 장비 위치 확인 필요');if(!point)reasons.push(relative?'두 영역 사이의 위치 확인 필요':surrounding&&matches.length?'영역 바깥의 주변 위치 확인 필요':matches.length?'여러 영역이 언급되어 위치 확인 필요':'등록된 동·시설을 찾지 못했습니다.');
 if(/북|남|동측|서측|동쪽|서쪽/.test(entry.text))reasons.push('방향 표현은 현장 방위 확인 후 조정해주세요.');
 if(classification.riskLevel==='high')reasons.push('고위험 작업의 상하·주변 작업 확인 필요 (자동 간섭 판정 아님)');
 return {title:entry.text.replace(/\n/g,' ').slice(0,80),detail:'',date:entry.date,...classification,...(ground&&region?{workRegionId:region.id,workAnchor:regionPoint(region)}:{}),regionId:classification.materialDelivery?null:region?.id||null,x:classification.materialDelivery?null:point?.[0]??null,y:classification.materialDelivery?null:point?.[1]??null,requiresPositionConfirmation:classification.materialDelivery,original:entry.text,calendar:entry.calendar||'',placement:relative?'between':surrounding?'surrounding':ground?'equipment-ground':'inside',reasons:classification.materialDelivery?['자재 반입 추정 · 톤수/차량 대수 표기: 위치 확인 필요',...reasons.filter(reason=>!reason.includes('위치 확인')&&!reason.includes('찾지 못'))]:reasons};
}
