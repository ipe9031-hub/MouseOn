import { spawn } from 'node:child_process';

// Only a registered connection is advertised. Merely printing an assigned URL is insufficient.
export function startTunnel({ executable, port, onState, spawnProcess = spawn, timeout = 60000 }) {
  let url=null, ready=false, stopped=false, buffer='', lastState='';
  const child=spawnProcess(executable,['tunnel','--no-autoupdate','--protocol','http2','--url',`http://127.0.0.1:${port}`],{stdio:['ignore','pipe','pipe']});
  function update(status,message){const state={status,url:status==='ready'?url:null,message};const key=JSON.stringify(state);if(key!==lastState){lastState=key;onState(state);}}
  update('starting','인터넷 참여 주소를 연결하고 있습니다.');
  const timer=setTimeout(()=>{if(!ready){update('failed','외부 연결 시간이 초과되었습니다. 인터넷 또는 회사 네트워크의 터널 허용 여부를 확인하고 다시 실행해주세요.');stop();}},timeout);
  timer.unref?.();
  function consume(chunk){
    buffer+=chunk.toString();const lines=buffer.split(/\r?\n/);buffer=lines.pop().slice(-8192);
    for(const line of lines){
      const match=line.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com\b/);if(match)url=match[0];
      if(/Registered tunnel connection/.test(line)){ready=true;if(url){clearTimeout(timer);update('ready','LTE·5G에서도 QR로 참여할 수 있습니다.');}}
      if(url&&ready&&lastState.includes('"starting"')){clearTimeout(timer);update('ready','LTE·5G에서도 QR로 참여할 수 있습니다.');}
      if(/Unregistered tunnel connection|failed to serve tunnel connection|Connection terminated/i.test(line)) {ready=false;update('retrying','외부 연결이 끊겨 재연결 중입니다. 잠시 기다려주세요.');}
    }
  }
  child.stdout?.on('data',consume);child.stderr?.on('data',consume);
  child.on('error',()=>{clearTimeout(timer);update('failed','외부 연결 프로그램을 실행하지 못했습니다. runtime 폴더의 cloudflared.exe를 확인해주세요.');});
  child.on('exit',()=>{clearTimeout(timer);if(!stopped)update('failed','외부 연결이 종료되었습니다. 실행 창을 닫고 다시 실행해주세요.');});
  function stop(){stopped=true;clearTimeout(timer);child.kill();}
  return {stop,child};
}
