import fs from 'node:fs';
import {defaultHazards} from './public/hazards.js';
import {validateOutline,withinOutline} from './public/site-partition.js';
import path from 'node:path';
import {randomBytes} from 'node:crypto';
export function validateSite(input){
 if(input?.version!==1||typeof input.name!=='string'||!input.name.trim()||input.name.length>80||!Array.isArray(input.regions)||input.regions.length>300)throw Error('현장 설정 형식이 잘못되었습니다.');
 const ids=new Set(),aliases=new Set();
 const regions=input.regions.map(r=>{
  if(typeof r.id!=='string'||!/^[a-zA-Z0-9_-]{1,60}$/.test(r.id)||ids.has(r.id)||typeof r.name!=='string'||r.name.length>80||!Array.isArray(r.aliases)||r.aliases.length>20||!r.aliases.every(s=>typeof s==='string'&&s.trim()&&s.length<=80)||!Array.isArray(r.points)||r.points.length<3||r.points.length>100||!r.points.every(p=>Array.isArray(p)&&p.length===2&&p.every(v=>typeof v==='number'&&Number.isFinite(v)&&v>=0&&v<=1)))throw Error('영역 이름·별칭·경계점을 확인해주세요.');
  let area=0;for(let i=0;i<r.points.length;i++){const a=r.points[i],b=r.points[(i+1)%r.points.length];area+=a[0]*b[1]-b[0]*a[1];}if(Math.abs(area)<.00002)throw Error('영역이 너무 작거나 경계가 올바르지 않습니다.');
  ids.add(r.id);for(const alias of [r.name,...r.aliases]){const normalized=alias.replace(/\s/g,'');if(!normalized)continue;if(aliases.has(normalized))throw Error('서로 다른 영역에 같은 이름·별칭을 쓸 수 없습니다.');aliases.add(normalized);}
  return {id:r.id,name:r.name.trim(),...(Array.isArray(r.seed)&&r.seed.length===2&&r.seed.every(v=>Number.isFinite(v)&&v>=0&&v<=1)?{seed:r.seed}:{}),aliases:[...new Set(r.aliases.map(a=>a.trim()))].filter(a=>a!==r.name.trim()),points:r.points};
 });const outline=input.outline?.length?validateOutline(input.outline):null;if(outline&&!withinOutline(regions,outline))throw Error('영역이 현장 외곽선을 벗어났습니다.');const font=['system','nanum-gothic'].includes(input.font)?input.font:'system';const hazards=input.hazards===undefined?defaultHazards():input.hazards;if(!Array.isArray(hazards)||hazards.length>40||hazards.some(h=>typeof h.id!=='string'||!/^[a-zA-Z0-9_-]{1,60}$/.test(h.id)||typeof h.name!=='string'||!h.name.trim()||h.name.length>80||!['formwork','rope','hazard'].includes(h.icon)||!/^#[0-9a-f]{6}$/i.test(h.color))||new Set(hazards.map(h=>h.id)).size!==hazards.length)throw Error('고위험 작업 종류를 확인해주세요.');return {version:1,name:input.name.trim(),regions,outline,font,hazards:hazards.map(h=>({id:h.id,name:h.name.trim(),icon:h.icon,color:h.color}))};
}
export function siteStore(data){
 const folder=path.join(data,'site'),file=path.join(folder,'site.json');fs.mkdirSync(folder,{recursive:true});
 function read(){return fs.existsSync(file)?JSON.parse(fs.readFileSync(file,'utf8')):{version:1,name:'우리 현장',revision:0,regions:[],image:null};}
 return {read,
 save(input,expected,image){const current=read();if(expected!==current.revision)throw Error('다른 변경이 먼저 저장됐습니다. 설정을 다시 열어주세요.');const clean=validateSite(input);
  if(image!==undefined&&image!==null&&!/^[a-f0-9]{32}\.(png|jpg|webp)$/.test(image))throw Error('탑뷰 이미지 형식 오류');
  const next={...clean,revision:current.revision+1,image:image===undefined?current.image:image};
  if(fs.existsSync(file)){fs.copyFileSync(file,path.join(folder,'backup-'+Date.now()+'-'+randomBytes(2).toString('hex')+'.json'));const backups=fs.readdirSync(folder).filter(n=>n.startsWith('backup-')).sort().reverse();for(const stale of backups.slice(5))fs.unlinkSync(path.join(folder,stale));}
  fs.writeFileSync(file+'.tmp',JSON.stringify(next));fs.renameSync(file+'.tmp',file);return next;
 }};
}
