export function koreanDay(now=new Date()){
 return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
}
export function addDays(day,n){const d=new Date(day+'T12:00:00Z');d.setUTCDate(d.getUTCDate()+n);return d.toISOString().slice(0,10);}
export function schedule(now=new Date()){
 const today=koreanDay(now),weekday=new Date(today+'T12:00:00Z').getUTCDay();
 const next=addDays(today,weekday===6?2:1);return {dates:[next],options:[next]};
}
export function validDate(value){return typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&!Number.isNaN(Date.parse(value+'T12:00:00Z'))&&new Date(value+'T12:00:00Z').toISOString().slice(0,10)===value;}

export function stepWorkday(day,direction){let next=addDays(day,direction);if(new Date(next+'T12:00:00Z').getUTCDay()===0)next=addDays(next,direction);return next;}
