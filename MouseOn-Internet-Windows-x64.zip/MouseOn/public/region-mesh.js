const eps=1e-8;
export const nodeKey=p=>p.map(v=>Math.round(v*1e8)).join(':');
const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
export const polygonArea=p=>p.reduce((s,a,i)=>{const b=p[(i+1)%p.length];return s+a[0]*b[1]-b[0]*a[1];},0)/2;
const crossing=(a,b,c,d)=>cross(a,b,c)*cross(a,b,d)<-1e-14&&cross(c,d,a)*cross(c,d,b)<-1e-14;
export function conformRegions(regions){
 const vertices=[...new Map(regions.flatMap(r=>r.points).map(p=>[nodeKey(p),p])).values()];
 return regions.map(r=>({...r,points:r.points.flatMap((a,i)=>{const b=r.points[(i+1)%r.points.length],dx=b[0]-a[0],dy=b[1]-a[1],length=dx*dx+dy*dy;if(length<eps)return [a];return [a,...vertices.map(p=>({p,t:((p[0]-a[0])*dx+(p[1]-a[1])*dy)/length})).filter(v=>v.t>eps&&v.t<1-eps&&Math.abs(cross(a,b,v.p))<eps).sort((x,y)=>x.t-y.t).map(v=>[...v.p])];})}));
}
export function validMesh(regions){
 const edges=new Map();
 for(const r of regions){const p=r.points;if(p.length<3||p.length>100||Math.abs(polygonArea(p))<.00002||p.some(a=>a.some(v=>!Number.isFinite(v)||v<0||v>1)))return false;
  for(let i=0;i<p.length;i++){const a=p[i],b=p[(i+1)%p.length];if(nodeKey(a)===nodeKey(b))return false;for(let j=i+2;j<p.length;j++){if(i===0&&j===p.length-1)continue;if(crossing(a,b,p[j],p[(j+1)%p.length]))return false;}edges.set([nodeKey(a),nodeKey(b)].sort().join('/'),[a,b]);}
 }
 const unique=[...edges.values()];for(let i=0;i<unique.length;i++)for(let j=i+1;j<unique.length;j++)if(crossing(...unique[i],...unique[j]))return false;return true;
}
export function moveSharedNodes(regions,changes){
 const map=new Map(changes.map(({from,to})=>[nodeKey(from),[from[0]<eps?0:from[0]>1-eps?1:Math.max(0,Math.min(1,to[0])),from[1]<eps?0:from[1]>1-eps?1:Math.max(0,Math.min(1,to[1]))]]));
 const next=regions.map(r=>({...r,points:r.points.map(p=>map.get(nodeKey(p))||[...p])}));
 if(!validMesh(next)||next.some((r,i)=>polygonArea(r.points)*polygonArea(regions[i].points)<=0))throw Error('다른 영역이 뒤집히거나 너무 작아지는 위치로는 옮길 수 없습니다.');return next;
}
export function insertSharedPoint(regions,id,index,t=.5){
 const next=structuredClone(regions),r=next.find(r=>r.id===id);const a=r.points[index],b=r.points[(index+1)%r.points.length];t=Math.max(.05,Math.min(.95,t));const point=[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];r.points.splice(index+1,0,point);const conformed=conformRegions(next);if(!validMesh(conformed))throw Error('이 위치에는 점을 추가할 수 없습니다.');return {regions:conformed,point};
}
export function removeSharedPoint(regions,key){
 const sample=regions.flatMap(r=>r.points).find(p=>nodeKey(p)===key);if(!sample)throw Error('점을 먼저 선택해주세요.');if((sample[0]<eps||sample[0]>1-eps)&&(sample[1]<eps||sample[1]>1-eps))throw Error('사진 모서리는 삭제할 수 없습니다.');
 const neighbors=new Set();for(const r of regions){const i=r.points.findIndex(p=>nodeKey(p)===key);if(i>=0){neighbors.add(nodeKey(r.points[(i+r.points.length-1)%r.points.length]));neighbors.add(nodeKey(r.points[(i+1)%r.points.length]));}}
 if(neighbors.size>2)throw Error('여러 영역이 만나는 교차점은 삭제하지 않습니다. 경계에 추가한 점을 선택해주세요.');
 const next=regions.map(r=>({...r,points:r.points.filter(p=>nodeKey(p)!==key)}));if(!validMesh(next))throw Error('영역을 유지하려면 이 점이 필요합니다.');return next;
}
export function mergeDeletedRegion(regions,id){
 const removed=regions.find(r=>r.id===id);if(!removed)return regions;if(regions.length===1)return [];
 let best=null,length=0;
 for(const r of regions.filter(r=>r.id!==id)){let score=0;for(let i=0;i<removed.points.length;i++){const a=removed.points[i],b=removed.points[(i+1)%removed.points.length];for(let j=0;j<r.points.length;j++){const c=r.points[j],d=r.points[(j+1)%r.points.length];if(nodeKey(a)===nodeKey(d)&&nodeKey(b)===nodeKey(c))score+=Math.hypot(a[0]-b[0],a[1]-b[1]);}}if(score>length){length=score;best=r;}}
 if(!best)throw Error('맞닿은 이웃이 없습니다. 개수 설정에서 삭제 후 전체 자동 배치를 사용해주세요.');
 const edges=new Map();for(const r of [removed,best])for(let i=0;i<r.points.length;i++){const a=r.points[i],b=r.points[(i+1)%r.points.length],reverse=nodeKey(b)+'/'+nodeKey(a);if(edges.has(reverse))edges.delete(reverse);else edges.set(nodeKey(a)+'/'+nodeKey(b),[a,b]);}
 const remaining=[...edges.values()],points=[];let edge=remaining.shift();if(!edge)throw Error('경계를 합칠 수 없습니다.');const first=nodeKey(edge[0]);points.push(edge[0]);let end=edge[1];while(nodeKey(end)!==first){points.push(end);const i=remaining.findIndex(e=>nodeKey(e[0])===nodeKey(end));if(i<0)throw Error('나뉜 공간은 자동으로 합칠 수 없습니다.');edge=remaining.splice(i,1)[0];end=edge[1];if(points.length>100)throw Error('경계점이 너무 많습니다.');}
 if(remaining.length)throw Error('구멍이 있는 경계는 자동으로 합치지 않습니다.');const next=regions.filter(r=>r.id!==id).map(r=>r.id===best.id?{...r,points}:r);if(!validMesh(next))throw Error('영역 합치기에 실패했습니다.');return next;
}
