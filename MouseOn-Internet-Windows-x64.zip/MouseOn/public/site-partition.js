import './vendor/polygon-clipping.js';
import {polygonArea,conformRegions,validMesh} from './region-mesh.js';
import {inside,regionPoint} from './interpret.js';
const clip=globalThis.polygonClipping;
export const defaultOutline=()=>[[0,0],[1,0],[1,1],[0,1]];
export function validateOutline(points){if(!Array.isArray(points)||points.length<3||points.length>80||!validMesh([{points}]))throw Error('외곽선을 3점 이상 찍고 교차하지 않도록 지정해주세요.');return points;}
function halfPlane(points,a,b){const nx=b[0]-a[0],ny=b[1]-a[1],limit=(b[0]*b[0]+b[1]*b[1]-a[0]*a[0]-a[1]*a[1])/2;const out=[];for(let i=0;i<points.length;i++){const p=points[i],q=points[(i+1)%points.length],u=nx*p[0]+ny*p[1]-limit,v=nx*q[0]+ny*q[1]-limit;if(u<=1e-12)out.push(p);if((u<0&&v>0)||(u>0&&v<0)){const t=u/(u-v);out.push([p[0]+(q[0]-p[0])*t,p[1]+(q[1]-p[1])*t]);}}return out;}
export function partitionSite(outline,regions){
 validateOutline(outline);const seeds=regions.map(r=>r.seed||regionPoint(r));
 const next=regions.map((r,i)=>{let cell=[[-2,-2],[3,-2],[3,3],[-2,3]];for(let j=0;j<seeds.length;j++)if(i!==j){if(Math.hypot(seeds[i][0]-seeds[j][0],seeds[i][1]-seeds[j][1])<1e-6)throw Error('영역의 중심이 너무 가깝습니다. 다른 위치에 추가해주세요.');cell=halfPlane(cell,seeds[i],seeds[j]);}
  if(cell.length<3)throw Error('새 영역을 만들 공간이 부족합니다.');const result=clip.intersection([outline],[cell]);if(result.length!==1||result[0].length!==1)throw Error('이 위치에서는 영역이 분리됩니다. 다른 위치를 선택해주세요.');const points=result[0][0].slice(0,-1).map(p=>p.map(v=>Math.max(0,Math.min(1,v))));return {...r,seed:seeds[i],points};});
 const conformed=conformRegions(next);if(!validMesh(conformed))throw Error('영역이 너무 작아 나눌 수 없습니다.');return conformed;
}
export function addSiteRegion(outline,regions,id){
 validateOutline(outline);if(regions.length>=100)throw Error('영역은 최대 100개입니다.');
 if(!regions.length)return [{id,name:'',aliases:[],seed:regionPoint({points:outline}),points:structuredClone(outline)}];
 const largestCell=[...regions].sort((a,b)=>Math.abs(polygonArea(b.points))-Math.abs(polygonArea(a.points)))[0],boxX=largestCell.points.map(p=>p[0]),boxY=largestCell.points.map(p=>p[1]),cx=(Math.min(...boxX)+Math.max(...boxX))/2,cy=(Math.min(...boxY)+Math.max(...boxY))/2;
 for(const axis of [(Math.max(...boxX)-Math.min(...boxX))>=(Math.max(...boxY)-Math.min(...boxY))?0:1,1,0]){
  const delta=axis===0?(Math.max(...boxX)-Math.min(...boxX))/4:(Math.max(...boxY)-Math.min(...boxY))/4,a=[cx,cy],b=[cx,cy];a[axis]-=delta;b[axis]+=delta;
  if(inside(a,largestCell.points)&&inside(b,largestCell.points))try{return partitionSite(outline,[...regions.map(r=>r.id===largestCell.id?{...r,seed:a}:r),{id,name:'',aliases:[],seed:b,points:outline}]);}catch{}
 }
 const seeds=regions.map(r=>r.seed||regionPoint(r)),xs=outline.map(p=>p[0]),ys=outline.map(p=>p[1]),candidates=[];
 for(let y=1;y<24;y++)for(let x=1;x<24;x++){const p=[Math.min(...xs)+(Math.max(...xs)-Math.min(...xs))*x/24,Math.min(...ys)+(Math.max(...ys)-Math.min(...ys))*y/24];if(inside(p,outline))candidates.push({p,score:Math.min(...seeds.map(s=>Math.hypot(s[0]-p[0],s[1]-p[1]))) });}
 // Choose inside the largest cell near its center; alternative candidates avoid disconnected concave cells.
 const largest=[...regions].sort((a,b)=>Math.abs(polygonArea(b.points))-Math.abs(polygonArea(a.points)))[0],center=regionPoint(largest);
 candidates.sort((a,b)=>{const score=c=>c.score*(inside(c.p,largest.points)?1.4:1)-Math.hypot(c.p[0]-center[0],c.p[1]-center[1])*.15;return score(b)-score(a);});
 for(const {p}of candidates.slice(0,100))try{return partitionSite(outline,[...regions,{id,name:'',aliases:[],seed:p,points:outline}]);}catch{}
 throw Error('이 외곽선에서는 새 영역을 자동으로 나누지 못했습니다. 외곽선을 단순하게 조정하거나 경계를 직접 편집해주세요.');
}
export function withinOutline(regions,outline){if(!outline?.length||!regions.length)return true;const outside=clip.difference(regions.map(r=>[r.points]),[outline]);return outside.reduce((sum,p)=>sum+Math.abs(polygonArea(p[0])),0)<1e-7;}
export function constrainToOutline(outline,changes){if(!outline?.length)return changes;return changes.map(({from,to})=>{
 if(outline.some(p=>Math.hypot(p[0]-from[0],p[1]-from[1])<1e-8))return {from,to:[...from]};
 for(let i=0;i<outline.length;i++){const a=outline[i],b=outline[(i+1)%outline.length],dx=b[0]-a[0],dy=b[1]-a[1],d=dx*dx+dy*dy,t=((from[0]-a[0])*dx+(from[1]-a[1])*dy)/d;if(t>=0&&t<=1&&Math.hypot(from[0]-a[0]-t*dx,from[1]-a[1]-t*dy)<1e-8){const u=Math.max(0,Math.min(1,((to[0]-a[0])*dx+(to[1]-a[1])*dy)/d));return {from,to:[a[0]+u*dx,a[1]+u*dy]};}}
 return {from,to};
 });}
