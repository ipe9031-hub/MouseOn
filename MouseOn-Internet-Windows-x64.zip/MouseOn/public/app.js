import {kindInfo,regionPoint} from '/interpret.js';
import {equipmentIcon,isTower,iconType} from '/icons.js';
import {schedule,validDate,stepWorkday} from '/calendar.js';
const $ = id => document.getElementById(id);
let room, socket, mode='pointer', zoom=1, joined=false, retry, toastTimer;
let keptGeometry=[];
const viewHistory=[];let areaGesture=null,lastWheelTime=0;
let panX=0,panY=0,fitMode='cover',myColor='#d45743',myName='',site={version:1,revision:0,name:'우리 현장',regions:[]},siteDraft=null,regionPicking=false,regionEditId=null,batchEntries=[];
let selectedDates=schedule().dates, activeId=null,pinnedId=null,picking=false,draft=[];
const ctx=$('ink').getContext('2d');
const roomId=new URLSearchParams(location.search).get('room');
if(roomId) { $('enter').textContent='회의 참여 →'; $('welcome').querySelector('h2').textContent='진행 중인 회의에 참여하세요'; }
let hostSetup=false;
const fragment=new URLSearchParams(location.hash.slice(1));
if(fragment.has('host')){sessionStorage.setItem('mouseon-host',fragment.get('host'));history.replaceState(null,'',location.pathname+location.search);}
const hostHeaders={'X-Mouseon-Host':sessionStorage.getItem('mouseon-host')||''};
const roomQuery=()=>'?room='+encodeURIComponent(new URLSearchParams(location.search).get('room')||'');
let passwordRequired=false;
const accessReady=fetch('/api/access'+roomQuery()).then(r=>{if(!r.ok)throw Error('접속 상태를 확인하지 못했습니다.');return r.json();}).then(state=>{
 hostSetup=state.hostSetup;
 $('passwordLabel').textContent=hostSetup&&!roomId?'회의 비밀번호 지정 (4자 이상)':'회의 비밀번호';
 passwordRequired=state.passwordRequired&&!state.authenticated;
 $('passwordField').hidden=!passwordRequired;$('password').required=passwordRequired;
}).catch(error=>{toast(error.message);});
$('name').value=sessionStorage.getItem('mouseon-name')||'';
function toast(text){$('toast').textContent=text;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),3500);}
function send(m){if(socket?.readyState===WebSocket.OPEN){socket.send(JSON.stringify(m));return true;}toast('연결을 확인하고 다시 시도해주세요.');return false;}
function connected(ok,text){$('led').classList.toggle('on',ok);$('status').textContent=text;}
$('entry').onsubmit=async e=>{e.preventDefault();$('enter').disabled=true;try{
  const name=$('name').value.trim();if(!name)throw Error('이름을 입력해주세요.');sessionStorage.setItem('mouseon-name',name);
  await accessReady;
  if(passwordRequired && !(hostSetup&&!new URLSearchParams(location.search).get('room'))){
    const login=await fetch('/api/login'+roomQuery(),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('password').value})});
    const result=await login.json();if(!login.ok)throw Error(result.error||'로그인하지 못했습니다.');
    passwordRequired=false;$('password').value='';$('password').required=false;$('passwordField').hidden=true;
  }
  let id=new URLSearchParams(location.search).get('room');
  if(!id){const res=await fetch('/api/rooms',{method:'POST',headers:{...hostHeaders,'Content-Type':'application/json'},body:JSON.stringify({password:$('password').value})});if(!res.ok){const error=await res.json();throw Error(error.error||'회의를 만들지 못했습니다.');}id=(await res.json()).id;history.replaceState(null,'','?room='+id);}
  $('password').value='';passwordRequired=false;
  connect(id,name);
}catch(err){toast(err.message);$('enter').disabled=false;}};
function connect(id,name){
  clearTimeout(retry);connected(false,'연결 중');
  socket=new WebSocket(`${location.protocol==='https:'?'wss:':'ws:'}//${location.host}/?room=${encodeURIComponent(id)}&name=${encodeURIComponent(name)}`);
  socket.onopen=()=>{connected(true,'실시간 연결됨');};
  socket.onmessage=event=>{const m=JSON.parse(event.data);
    if(m.type==='state'){
      if(m.identity){myColor=m.identity.color;myName=m.identity.person;}
      room=m.room;document.body.classList.add('in-meeting');if(!joined){joined=true;$('welcome').hidden=true;$('workspace').hidden=false;$('share').disabled=false;}
      render();setZoom();if(!siteDraft)loadSite();if(m.notice)toast(m.notice);
    } else if(m.type==='site'){site=m.site;siteDraft=structuredClone(site);renderSite();toast('현장 설정이 갱신되었습니다.');}
    else if(m.type==='stroke' && m.image===room.image){room.strokes.push(m.stroke);paint(m.stroke);}
    else if(m.type==='pointer'){showPointer(m);}
    else if(m.type==='presence')$('presence').textContent=`· ${m.count}명 참여`;
    else if(m.type==='error')toast(m.message);
  };
  socket.onclose=e=>{connected(false,'연결 끊김');$('enter').disabled=false;
    if(e.code===1008){toast(e.reason||'참여할 수 없습니다. 주소와 비밀번호를 확인해주세요.');joined=false;$('welcome').hidden=false;$('workspace').hidden=true;$('share').disabled=true;passwordRequired=true;$('passwordField').hidden=false;$('password').required=true;return;}
    toast('연결이 끊겼습니다. 다시 연결 중입니다.');retry=setTimeout(()=>connect(id,name),1800);
  };
  socket.onerror=()=>connected(false,'서버 연결 확인 중');
}
function el(tag,cls,text){const node=document.createElement(tag);if(cls)node.className=cls;if(text!==undefined)node.textContent=text;return node;}
function isTop(){return room.image===room.topImage;}
function render(){
  const image=room.image||'/sample.svg';if($('background').getAttribute('src')!==image){$('background').src=image;zoom=1;panX=0;panY=0;viewHistory.length=0;updateViewButtons();setZoom();}
  $('viewTitle').textContent=isTop()?'현장 탑뷰':'상세 사진';$('imageNote').textContent=room.image?(isTop()?'업로드한 현장 탑뷰':'공유 중인 상세 사진'):'샘플 배치도';
  $('back').disabled=isTop();$('tasks').replaceChildren();$('routeLayer').replaceChildren();$('sequence').replaceChildren();$('taskCount').textContent=room.tasks.length;
  const visibleTasks=room.tasks.filter(t=>selectedDates.includes(t.date||schedule().dates[0]));
  renderPending();
  updateTitle();
  const groups=Map.groupBy(visibleTasks,t=>t.equipment);
  for(const [equipment,tasks] of groups){
    const group=el('section','equipment');group.append(el('h3','',equipment));
    tasks.forEach((task,i)=>{
      const row=el('div','task-row');if(!isTower(task))row.append(el('span','step',String(i+1)));
      const info=el('div','task-info');const label=el('b','');label.append(equipmentIcon(task),document.createTextNode(task.title));info.append(label,el('small','',task.detail));row.append(info);
      const controls=el('div','order-buttons');
      for(const [d,label] of [[-1,'↑'],[1,'↓']]){const button=el('button','',label);button.setAttribute('aria-label',task.title+(d===-1?' 순서 올리기':' 순서 내리기'));button.disabled=d===-1?i===0:i===tasks.length-1;button.onclick=()=>send({type:'reorder',id:task.id,direction:d,revision:room.revision});if(!isTower(task))controls.append(button);}
      const remove=el('button','delete-task','삭제');remove.setAttribute('aria-label',task.title+' 삭제');remove.onclick=()=>deleteTask(task);controls.append(remove);row.append(controls);group.append(row);
      if(isTop()&&Number.isFinite(task.x)&&Number.isFinite(task.y)){
        const marker=el('button','marker');marker.dataset.id=task.id;marker.style.left=task.x*100+'%';marker.style.top=task.y*100+'%';marker.setAttribute('aria-label',`${task.title} 위치`);
        const icon=el('span','marker-icon');icon.append(equipmentIcon(task));marker.append(icon);if(!isTower(task))marker.append(el('span','marker-number',String(i+1)));marker.append(el('span','marker-label',task.title));
        marker.querySelector('.marker-label').textContent=cleanTaskTitle(task.title);const color=kindInfo[iconType(task)]?.[1]||kindInfo.other[1];marker.style.setProperty('--task-color',color);if(task.reasons?.length){const badge=el('span','attention','!');badge.tabIndex=0;badge.append(el('span','attention-text',task.reasons.join('\n')));marker.append(badge);}
        marker.onpointerenter=()=>{activeId=task.id;reveal();};marker.onpointerleave=()=>{activeId=null;reveal();};
        marker.onfocus=()=>{activeId=task.id;reveal();};marker.onblur=()=>{activeId=null;reveal();};
        marker.onclick=()=>{if(mode!=='move'){pinnedId=pinnedId===task.id?null:task.id;reveal();}};$('tasks').append(marker);
        [{shape:task.shape,points:task.points},...(task.extras||[])].forEach((geometry,index)=>appendTaskGeometry(task,geometry,index));
      }
    });$('sequence').append(group);
  }
  reveal();drawSiteRegions();
  resizeInk();
}
function resizeInk(){const rect=$('scene').getBoundingClientRect();const canvas=$('ink');const scale=Math.min(devicePixelRatio,4096/Math.max(1,rect.width),4096/Math.max(1,rect.height));const w=Math.max(1,Math.round(rect.width*scale)),h=Math.max(1,Math.round(rect.height*scale));if(canvas.width!==w)canvas.width=w;if(canvas.height!==h)canvas.height=h;ctx.clearRect(0,0,w,h);if(room)room.strokes.forEach(paint);}
function paint(stroke){const c=$('ink');ctx.strokeStyle=stroke.color;ctx.lineWidth=3*c.width/Math.max(1,$('scene').getBoundingClientRect().width);ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();stroke.points.forEach(([x,y],i)=>i?ctx.lineTo(x*c.width,y*c.height):ctx.moveTo(x*c.width,y*c.height));ctx.stroke();}
$('background').onload=()=>{const img=$('background');$('scene').style.aspectRatio=`${img.naturalWidth} / ${img.naturalHeight}`;setZoom();resizeInk();};
new ResizeObserver(resizeInk).observe($('scene'));
function point(e){const r=$('scene').getBoundingClientRect();return [Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),Math.max(0,Math.min(1,(e.clientY-r.top)/r.height))];}
const pointerTimers=new Map();
function showPointer(m){let p=document.getElementById('p-'+m.peer);if(!p){p=el('div','remote-pointer');p.id='p-'+m.peer;p.append(el('span','','↖'),el('b','',m.person));$('pointers').append(p);}p.style.color=m.color||'#d45743';p.querySelector('b').style.background=m.color||'#d45743';p.style.left=m.x*100+'%';p.style.top=m.y*100+'%';clearTimeout(pointerTimers.get(m.peer));pointerTimers.set(m.peer,setTimeout(()=>{p.remove();pointerTimers.delete(m.peer);},1500));}
let gesture=null,lastSent=0;
$('scene').onpointerdown=e=>{
  if(regionPicking){draft.push(point(e));renderSiteDraft();return;}
  if(mode==='pan')return;
  if(picking){const p=point(e);draft.push(p);renderDraft();return;}
  if(!e.target.closest('.marker')){pinnedId=null;activeId=null;reveal();}
  if(!room||socket?.readyState!==WebSocket.OPEN)return;
  const marker=e.target.closest('.marker'), p=point(e);
  if(mode==='move'&&marker){
    e.preventDefault();const task=room.tasks.find(t=>t.id===marker.dataset.id);
    gesture={type:'move',id:task.id,marker,startX:e.clientX,startY:e.clientY,original:[task.x,task.y],ready:e.pointerType!=='touch'};
    if(!gesture.ready)gesture.timer=setTimeout(()=>{if(gesture){gesture.ready=true;navigator.vibrate?.(25);}},350);
  }else if(mode==='draw'){e.preventDefault();gesture={type:'draw',last:p};}
  else if(mode==='pointer'){e.preventDefault();gesture={type:'pointer'};send({type:'pointer',x:p[0],y:p[1]});}
  if(gesture&&(!marker||mode==='move'))$('scene').setPointerCapture(e.pointerId);
};
$('scene').onpointermove=e=>{
  if(!room||picking||regionPicking)return;const p=point(e), now=performance.now();
  if(gesture?.type==='move'){
    if(!gesture.ready){if(Math.hypot(e.clientX-gesture.startX,e.clientY-gesture.startY)>12){clearTimeout(gesture.timer);gesture.marker.style.left=gesture.original[0]*100+'%';gesture.marker.style.top=gesture.original[1]*100+'%';gesture=null;}return;}
    gesture.marker.style.left=p[0]*100+'%';gesture.marker.style.top=p[1]*100+'%';return;
  }
  if(now-lastSent<25)return;lastSent=now;
  if(gesture?.type==='draw'){const stroke={points:[gesture.last,p],color:myColor,person:myName};if(send({type:'stroke',points:stroke.points,image:room.image})){room.strokes.push(stroke);paint(stroke);}gesture.last=p;}
  else if(mode==='pointer' && (e.pointerType==='mouse'||gesture))send({type:'pointer',x:p[0],y:p[1]});
};
function finish(e,cancel=false){if(!gesture)return;clearTimeout(gesture.timer);const g=gesture;gesture=null;
 if(g.type==='move'){if(!cancel&&g.ready){const p=point(e);send({type:'move',id:g.id,x:p[0],y:p[1]});}else{g.marker.style.left=g.original[0]*100+'%';g.marker.style.top=g.original[1]*100+'%';}}
 if(g.type==='draw'&&!cancel){const p=point(e);const stroke={points:[g.last,p],color:myColor,person:myName};if(send({type:'stroke',points:stroke.points,image:room.image})){room.strokes.push(stroke);paint(stroke);}}
}
$('scene').onpointerup=e=>finish(e);$('scene').onpointercancel=e=>finish(e,true);
function selectMode(next){
 if(gesture?.timer)clearTimeout(gesture.timer);gesture=null;cancelAreaZoom();
 mode=next;document.querySelectorAll('button[data-mode]').forEach(b=>{b.classList.toggle('active',b.dataset.mode===mode);b.setAttribute('aria-pressed',String(b.dataset.mode===mode));});$('scene').dataset.mode=mode;
 $('drawClear').hidden=mode!=='draw';$('mobileDone').disabled=mode!=='draw';
 $('modeHint').textContent={pointer:'터치하거나 움직여 위치를 가리키세요',draw:'사진 위에 그리기 · 펜을 다시 누르거나 종료로 해제',move:'아이콘을 길게 눌러 위치를 옮기세요',pan:'휠로 확대·축소, 드래그로 이동, 모서리로 크기 조절',zoom:'사진에서 확대할 구간을 드래그하세요 · Esc로 취소'}[mode];
}
for(const button of document.querySelectorAll('button[data-mode]'))button.onclick=()=>selectMode(button.dataset.mode==='draw'&&mode==='draw'?'pointer':button.dataset.mode);
function clearAndExit(){selectMode('pointer');send({type:'clear'});}
$('scene').dataset.mode=mode;
$('clear').onclick=clearAndExit;$('back').onclick=()=>send({type:'top'});
function setZoom(){const r=$('viewport').getBoundingClientRect();const img=$('background');const ratio=(img.naturalWidth||16)/(img.naturalHeight||10);$('scene').style.width=Math.max(1,(fitMode==='cover'&&r.width>=r.height?Math.max(r.width,r.height*ratio):Math.min(r.width,r.height*ratio)))*zoom+'px';$('scene').style.transform=`translate(-50%,-50%) translate(${panX}px,${panY}px)`;$('zoomLabel').textContent=Math.round(zoom*100)+'%';}
$('zoomIn').onclick=()=>{rememberView();zoom=Math.min(8,zoom*1.2);setZoom();};$('zoomOut').onclick=()=>{rememberView();zoom=Math.max(.2,zoom/1.2);setZoom();};
let uploading=false;
for(const [input,kind] of [['topFile','top'],['photoFile','photo']])$(input).onchange=()=>{
 const file=$(input).files[0];if(!file)return;
 if(uploading){toast('진행 중인 업로드가 끝난 뒤 다시 선택해주세요.');$(input).value='';return;}
 if(file.size>50*1024*1024){toast('사진은 최대 50MB까지 지원합니다.');$(input).value='';return;}
 uploading=true;const xhr=new XMLHttpRequest();xhr.open('POST',`/api/rooms/${room.id}/image?kind=${kind}`);xhr.timeout=180000;
 xhr.upload.onprogress=e=>{if(e.lengthComputable)toast(`사진 업로드 중 · ${Math.round(e.loaded/e.total*100)}%`);};
 xhr.onload=()=>{let result;try{result=JSON.parse(xhr.responseText);}catch{}toast(xhr.status===200?'사진을 공유했습니다.':result?.error||'업로드에 실패했습니다.');};
 xhr.onerror=()=>toast('업로드 연결을 확인해주세요.');xhr.ontimeout=()=>toast('업로드 시간이 초과되었습니다. 다시 시도해주세요.');xhr.onloadend=()=>{uploading=false;$(input).value='';};xhr.send(file);
};
let sharePoll;
function updateShare(){
 const address=$('networkAddress').value;
 if(!address){$('qr').hidden=true;$('joinUrl').hidden=true;$('copy').disabled=true;return;}
 const link=address+'/?room='+room.id;
 $('joinUrl').value=link;$('joinUrl').hidden=false;$('qr').hidden=false;
 const src='/api/qr?url='+encodeURIComponent(link)+'&room='+room.id;if($('qr').getAttribute('src')!==src)$('qr').src=src;
 $('copy').disabled=false;
}
$('networkAddress').onchange=updateShare;
async function refreshShare(){
 try{
   const res=await fetch('/api/network'+roomQuery(),{headers:hostHeaders});if(!res.ok)throw Error('참여 주소 확인에 실패했습니다. 다시 로그인하거나 연결 상태를 확인해주세요.');
   const {addresses,tunnel}=await res.json();let choices=[];
   if(tunnel.status!=='local'){
     if(tunnel.status==='ready'&&tunnel.url){choices=[tunnel.url];$('shareStatus').textContent='인터넷 연결됨 · 휴대폰 LTE·5G에서도 참여할 수 있습니다.';}
     else $('shareStatus').textContent=tunnel.message||'인터넷 주소 연결 중입니다. 잠시 기다려주세요.';
   } else {
     const loopback=['localhost','127.0.0.1','[::1]'].includes(location.hostname);
     choices=loopback?addresses:[location.origin];
     $('shareStatus').textContent=choices.length?'로컬 연결 · PC와 휴대폰이 같은 네트워크에 있어야 합니다.':'휴대폰용 주소를 찾지 못했습니다. PC의 Wi-Fi 또는 유선 연결을 확인해주세요.';
   }
   const previous=$('networkAddress').value;
   $('networkAddress').replaceChildren(...choices.map(address=>{const option=el('option','',address);option.value=address;return option;}));
   if(choices.includes(previous))$('networkAddress').value=previous;
   $('networkAddress').hidden=!choices.length;updateShare();
 }catch(error){$('shareStatus').textContent=error.message;$('networkAddress').replaceChildren();updateShare();}
}
$('share').onclick=()=>{
 $('networkAddress').replaceChildren();updateShare();$('shareDialog').showModal();
 refreshShare();clearInterval(sharePoll);sharePoll=setInterval(refreshShare,2000);
};
$('closeShare').onclick=()=>$('shareDialog').close();
$('shareDialog').addEventListener('close',()=>clearInterval(sharePoll));
$('copy').onclick=async()=>{try{await navigator.clipboard.writeText($('joinUrl').value);toast('참여 링크를 복사했습니다.');}catch{$('joinUrl').select();toast('주소를 선택했습니다. 길게 누르거나 Ctrl+C로 복사해주세요.');}};

function panel(open){cancelAreaZoom();$('workspace').classList.toggle('panel-open',open);$('sidePanel').hidden=!open;$('menuToggle').setAttribute('aria-expanded',String(open));measureMobilePanel();setZoom();}
$('menuToggle').onclick=()=>panel($('sidePanel').hidden);$('menuClose').onclick=()=>panel(false);
for(const b of document.querySelectorAll('button[data-mode]')){const previous=b.onclick;b.onclick=()=>{previous();panel(false);};}
$('fullScreen').onclick=async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen();}catch{toast('이 브라우저는 전체화면을 지원하지 않습니다.');}};
function updateTitle(){const dates=selectedDates.map(d=>d.replaceAll('-','.')+' '+['일','월','화','수','목','금','토'][new Date(d+'T12:00:00Z').getUTCDay()]);$('meetingTitle').textContent='명일 작업사항 ('+dates.join(' · ')+')';}
function chooseDates(dates){selectedDates=dates;$('viewDate').value=dates.length===1?dates[0]:'';if(room)render();else updateTitle();renderDateChoices();}
function renderDateChoices(){const plan=schedule();$('dateChoices').replaceChildren();for(const date of plan.options){const b=el('button',selectedDates.includes(date)?'active':'',date.slice(5).replace('-','/')+' '+['일','월','화','수','목','금','토'][new Date(date+'T12:00:00Z').getUTCDay()]);b.onclick=()=>chooseDates([date]);$('dateChoices').append(b);}}
$('viewDate').onchange=()=>{if(validDate($('viewDate').value))chooseDates([$('viewDate').value]);};$('defaultDates').onclick=()=>chooseDates(schedule().dates);
$('taskDate').value=selectedDates[0];$('worksDate').value=selectedDates[0];chooseDates(selectedDates);
function reveal(){const id=activeId||pinnedId;const selected=room?.tasks.find(t=>t.id===pinnedId);$('taskActions').hidden=!selected;if(selected)$('selectedTaskName').textContent=selected.title;for(const svg of $('routeLayer').children)svg.classList.toggle('revealed',svg.dataset.task===id);for(const marker of $('tasks').children)marker.classList.toggle('selected',marker.dataset.id===id);}
function renderDraft(){const svg=$('draftLayer');svg.replaceChildren();const shape=document.createElementNS(svg.namespaceURI,$('taskShape').value==='area'?'polygon':'polyline');shape.setAttribute('points',draft.map(p=>p.map(v=>v*1000).join(',')).join(' '));svg.append(shape);for(const [x,y] of draft){const dot=document.createElementNS(svg.namespaceURI,'circle');dot.setAttribute('cx',x*1000);dot.setAttribute('cy',y*1000);dot.setAttribute('r',6);svg.append(dot);}$('geometryCount').textContent=draft.length+'점 지정';}
$('pickGeometry').onclick=()=>{if(!isTop()){toast('탑뷰로 복귀한 뒤 위치를 지정해주세요.');return;}draft=[];picking=true;renderDraft();panel(false);$('finishGeometry').hidden=false;$('finishGeometry').classList.add('floating-finish');toast('지도에서 위치를 찍고 위치 지정 완료를 누르세요.');};
// The finish control is outside the collapsed menu while selecting geometry.
$('workspace').append($('finishGeometry'));
$('finishGeometry').onclick=()=>{picking=false;$('finishGeometry').hidden=true;panel(true);};
$('taskShape').onchange=()=>{draft=[];renderDraft();};
$('taskForm').onsubmit=e=>{e.preventDefault();if(!draft.length&&!keptGeometry.length){toast('먼저 지도에서 작업 위치를 지정해주세요.');return;}let primary={shape:$('taskShape').value,points:draft};let extras=keptGeometry;if(!draft.length){primary=keptGeometry[0];extras=keptGeometry.slice(1);}const shape=primary.shape;if((shape==='area'&&primary.points.length<3)||(shape==='route'&&primary.points.length<2)){toast('영역은 3점, 동선은 2점 이상 찍어주세요.');return;}
 const date=$('taskDate').value;const task={title:$('taskTitle').value,detail:$('taskDetail').value,equipment:$('taskEquipment').value,icon:$('taskIcon').value,date,shape,points:primary.points,extras,attention:$('taskAttention').value,x:primary.points[0][0],y:primary.points[0][1]};
 if(send({type:'addTask',task})){chooseDates([date]);draft=[];keptGeometry=[];$('keptGeometryCount').textContent='';$('taskAttention').value='';renderDraft();$('taskTitle').value='';panel(false);}
};
window.addEventListener('resize',setZoom);document.addEventListener('fullscreenchange',setZoom);

const zoomTools=$('zoomIn').parentElement;zoomTools.className='zoom-tools';$('sidePanel').append(zoomTools);

function deleteTask(task){if(confirm('“'+task.title+'” 작업을 삭제할까요?')){send({type:'deleteTask',id:task.id});if(pinnedId===task.id)pinnedId=null;activeId=null;}}
$('deleteSelected').onclick=()=>{const task=room?.tasks.find(t=>t.id===pinnedId);if(task)deleteTask(task);};
let viewGesture=null,spaceHeld=false;
const viewport=$('viewport');
viewport.addEventListener('wheel',e=>{if(!room||picking||regionPicking)return;e.preventDefault();cancelAreaZoom();if(performance.now()-lastWheelTime>250)rememberView();lastWheelTime=performance.now();const box=viewport.getBoundingClientRect(),x=e.clientX-box.left-box.width/2,y=e.clientY-box.top-box.height/2;const next=Math.max(.2,Math.min(8,zoom*Math.exp(-e.deltaY*.0015)));const factor=next/zoom;panX=x-(x-panX)*factor;panY=y-(y-panY)*factor;zoom=next;setZoom();},{passive:false});
viewport.addEventListener('pointerdown',e=>{
 if(picking||regionPicking||(!spaceHeld&&mode!=='pan'&&e.button!==1&&!e.target.closest('[data-resize]')))return;
 rememberView();e.preventDefault();e.stopPropagation();const rect=viewport.getBoundingClientRect();const cx=rect.x+rect.width/2+panX,cy=rect.y+rect.height/2+panY;
 viewGesture={resize:Boolean(e.target.closest('[data-resize]')),x:e.clientX,y:e.clientY,px:panX,py:panY,zoom,distance:Math.hypot(e.clientX-cx,e.clientY-cy),cx,cy};viewport.setPointerCapture(e.pointerId);
},true);
viewport.addEventListener('pointermove',e=>{if(!viewGesture)return;e.preventDefault();const g=viewGesture;if(g.resize)zoom=Math.max(.2,Math.min(8,g.zoom*Math.hypot(e.clientX-g.cx,e.clientY-g.cy)/Math.max(1,g.distance)));else{panX=g.px+e.clientX-g.x;panY=g.py+e.clientY-g.y;}setZoom();});
for(const type of ['pointerup','pointercancel','lostpointercapture'])viewport.addEventListener(type,()=>viewGesture=null);
window.addEventListener('keydown',e=>{if(e.code==='Space'&&!/INPUT|SELECT|TEXTAREA|BUTTON/.test(document.activeElement?.tagName)){spaceHeld=true;e.preventDefault();}});window.addEventListener('keyup',e=>{if(e.code==='Space')spaceHeld=false;});window.addEventListener('blur',()=>{spaceHeld=false;viewGesture=null;});
const fit=el('button','','화면 맞춤');fit.id='fitImage';fit.onclick=resetView;zoomTools.append(fit);

let worksEntries=[];
function showWorksEntry(){const entry=worksEntries[Number($('worksEntry').value)];$('worksOriginal').textContent=entry?entry.calendar+' · '+entry.date+'\n'+entry.text:'';}
$('worksFile').onchange=async()=>{const file=$('worksFile').files[0];if(!file)return;try{
 if(file.size>1024*1024)throw Error('가져오기 파일은 1MB까지 지원합니다.');const data=JSON.parse(await file.text());
 if(data.format!=='mouseon-works-preview/v1'||!Array.isArray(data.entries)||data.entries.length<1||data.entries.length>50||!data.entries.every(e=>typeof e.text==='string'&&e.text.trim()&&e.text.length<=1200&&validDate(e.date)&&typeof e.calendar==='string'&&e.calendar.length<=100))throw Error('선택 일정 미리보기 JSON 형식을 확인해주세요.');
 worksEntries=data.entries;$('worksEntry').replaceChildren(...worksEntries.map((entry,i)=>{const option=el('option','',entry.text.slice(0,65));option.value=String(i);return option;}));showWorksEntry();$('worksDialog').showModal();
 }catch(error){toast(error.message);}finally{$('worksFile').value='';}};
$('worksEntry').onchange=showWorksEntry;$('closeWorks').onclick=()=>$('worksDialog').close();
$('prepareWorks').onclick=()=>{const entry=worksEntries[Number($('worksEntry').value)];if(!entry)return;
 $('taskTitle').value=entry.text.replaceAll('\n',' ').slice(0,80);$('taskDetail').value=entry.text.length>80?entry.text.slice(80,260):'';$('taskDate').value=entry.date;
 $('taskIcon').value=/타설|콘크리트/.test(entry.text)?'concrete':/타워/.test(entry.text)?'tower':/크레인/.test(entry.text)?'mobile':/지게차|하역/.test(entry.text)?'forklift':/덤프/.test(entry.text)?'dump':/굴착|백호/.test(entry.text)?'excavator':'other';
 draft=[];keptGeometry=[];$('keptGeometryCount').textContent='';renderDraft();$('taskShape').value='point';$('taskEquipment').value='';$('registration').open=true;$('worksDialog').close();panel(true);toast('자동 등록 전 단계입니다. 내용·날짜·위치를 확인하고 작업 저장을 눌러주세요.');
};

function cleanTaskTitle(text){return text.replace(/\d{4}[.\/-]\d{1,2}[.\/-]\d{1,2}/g,'').replace(/^\d+\.\s*/,'').replace(/\(?\d{1,2}[:：]\d{2}\)?/g,'').replace(/\d{1,2}시(?:\s*\d{1,2}분)?/g,'').replace(/\S*팀/g,'').replace(/\s+/g,' ').trim();}
$('previousDay').onclick=()=>chooseDates([stepWorkday(selectedDates[0],-1)]);$('nextDay').onclick=()=>chooseDates([stepWorkday(selectedDates.at(-1),1)]);
$('drawClear').onclick=clearAndExit;
async function api(route,body){const res=await fetch(route+roomQuery(),{method:body?'POST':'GET',headers:{...hostHeaders,'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{})});const value=await res.json();if(!res.ok)throw Error(value.error||'요청 실패');return value;}
async function loadSite(){try{site=await api('/api/site');siteDraft=structuredClone(site);renderSite();}catch(error){toast(error.message);}}
function renderSite(){if(!siteDraft)return;renderPending();drawSiteRegions();$('siteName').value=siteDraft.name;$('regionList').replaceChildren();for(const region of siteDraft.regions){const row=el('div','site-region',region.name);const edit=el('button','','편집');edit.onclick=()=>{regionEditId=region.id;$('regionName').value=region.name;$('regionAliases').value=region.aliases.join(', ');draft=structuredClone(region.points);renderSiteDraft();};row.append(edit);const remove=el('button','','삭제');remove.onclick=()=>{if(confirm(region.name+' 기본 영역을 삭제할까요?')){siteDraft.regions=siteDraft.regions.filter(r=>r.id!==region.id);renderSite();}};row.append(remove);$('regionList').append(row);}}
function renderSiteDraft(){const svg=$('draftLayer');svg.replaceChildren();const polygon=document.createElementNS(svg.namespaceURI,'polygon');polygon.setAttribute('points',draft.map(p=>p.map(v=>v*1000).join(',')).join(' '));svg.append(polygon);for(const [x,y]of draft){const dot=document.createElementNS(svg.namespaceURI,'circle');dot.setAttribute('cx',x*1000);dot.setAttribute('cy',y*1000);dot.setAttribute('r',5);svg.append(dot);}}
$('pickRegion').onclick=()=>{if(!isTop()){toast('탑뷰로 돌아온 뒤 설정해주세요.');return;}regionPicking=true;picking=false;draft=[];renderSiteDraft();panel(false);$('finishGeometry').hidden=false;toast('동·시설 경계를 3점 이상 찍고 완료를 누르세요.');};
const oldFinish=$('finishGeometry').onclick;$('finishGeometry').onclick=()=>{if(regionPicking){regionPicking=false;$('finishGeometry').hidden=true;panel(true);}else oldFinish();};
$('saveRegion').onclick=()=>{const name=$('regionName').value.trim();if(!name||draft.length<3){toast('영역 이름과 경계점 3개 이상이 필요합니다.');return;}siteDraft.regions=siteDraft.regions.filter(r=>r.id!==regionEditId);siteDraft.regions.push({id:regionEditId||crypto.randomUUID(),name,aliases:$('regionAliases').value.split(',').map(s=>s.trim()).filter(Boolean),points:structuredClone(draft)});regionEditId=null;draft=[];$('draftLayer').replaceChildren();$('regionName').value='';$('regionAliases').value='';renderSite();};
$('saveSite').onclick=async()=>{try{if($('useSiteImage').checked&&site.image&&siteDraft.regions.length&&!confirm('기본 탑뷰를 바꾸면 기존 영역과 위치가 어긋날 수 있습니다. 영역을 확인한 상태인가요?'))return;const next=await api('/api/site',{site:{...siteDraft,name:$('siteName').value},revision:site.revision,useCurrentImage:$('useSiteImage').checked});site=next;siteDraft=structuredClone(next);renderSite();toast('현장 기본 설정을 저장했습니다. 새 회의에서도 유지됩니다.');}catch(error){toast(error.message);}};
function downloadJSON(value,name){const url=URL.createObjectURL(new Blob([JSON.stringify(value,null,2)],{type:'application/json'})),a=el('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
$('backupSite').onclick=async()=>{try{downloadJSON(await api('/api/site/backup'),'MouseOn-site-backup.json');}catch(error){toast(error.message);}};
$('restoreSite').onchange=async()=>{const file=$('restoreSite').files[0];if(!file)return;try{if(file.size>72*1024*1024)throw Error('백업 파일이 너무 큽니다.');const input=JSON.parse(await file.text());if(!confirm('현장 기본 설정을 백업 내용으로 바꿀까요?'))return;const next=await api('/api/site/restore',{...input,revision:site.revision});site=next;siteDraft=structuredClone(next);renderSite();toast('복원했습니다. 새 회의에서 기본 탑뷰를 사용합니다.');}catch(error){toast(error.message);}finally{$('restoreSite').value='';}};
$('openWorksBrowser').onclick=async()=>{try{const result=await api('/api/works/open',{browser:$('worksBrowser').value});$('worksBatchStatus').textContent=result.message;}catch(error){$('worksBatchStatus').textContent=error.message;}};
async function collectBatch(demo){$('applyWorks').disabled=true;try{const result=await api('/api/works/preview',{date:$('worksDate').value,calendar:$('worksCalendar').value,demo});batchEntries=result.entries;$('worksBatchStatus').textContent=[result.engine,...(result.warnings||[])].join('\n');$('worksBatchPreview').replaceChildren();for(const entry of batchEntries){const row=el('div','batch-entry');row.append(el('b','',entry.title));const select=el('select');select.setAttribute('aria-label',entry.title+' 위치');const unknown=el('option','','위치 미확인 · 지도에는 표시 안 함');unknown.value='';select.append(unknown);for(const region of site.regions){const option=el('option','',region.name);option.value=region.id;select.append(option);}select.value=entry.regionId||'';select.onchange=()=>entry.regionId=select.value||null;row.append(select,el('small','',entry.reasons.join(' · ')));$('worksBatchPreview').append(row);}$('applyWorks').disabled=!batchEntries.length;}catch(error){$('worksBatchStatus').textContent=error.message;}}
$('collectWorks').onclick=()=>{if(confirm('웍스에서 선택한 캘린더만 표시하고 해당 날짜를 하루 보기로 열었나요? 현재 로드된 일정만 읽습니다.'))collectBatch(false);};$('demoWorks').onclick=()=>collectBatch(true);
$('applyWorks').onclick=async()=>{if(!confirm('미리보기 일정을 반영할까요? 위치가 없는 작업은 확인 대기로 저장합니다.'))return;try{const result=await api('/api/works/apply',{entries:batchEntries});chooseDates([$('worksDate').value]);toast(result.added+'개 등록 · 기존 '+result.skipped+'개 유지');}catch(error){toast(error.message);}};
function renderPending(){if(!$('pendingTasks'))return;$('pendingTasks').replaceChildren();for(const task of room.tasks.filter(t=>!Number.isFinite(t.x)||!Number.isFinite(t.y))){const row=el('div','pending-task',task.title);const select=el('select');const empty=el('option','','배치할 영역 선택');empty.value='';select.append(empty);for(const region of site.regions){const option=el('option','',region.name);option.value=region.id;select.append(option);}select.onchange=()=>{const region=site.regions.find(r=>r.id===select.value);if(region){const [x,y]=regionPoint(region);send({type:'move',id:task.id,x,y,regionId:region.id});}};row.append(select);$('pendingTasks').append(row);}}

function drawSiteRegions(){let svg=$('siteLayer');if(!svg){svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.id='siteLayer';svg.setAttribute('viewBox','0 0 1000 1000');svg.setAttribute('preserveAspectRatio','none');$('scene').insertBefore(svg,$('ink'));}svg.replaceChildren();for(const region of (siteDraft||site).regions){const poly=document.createElementNS(svg.namespaceURI,'polygon');poly.setAttribute('points',region.points.map(p=>p.map(v=>v*1000).join(',')).join(' '));svg.append(poly);const text=document.createElementNS(svg.namespaceURI,'text');const [x,y]=regionPoint(region);text.setAttribute('x',x*1000);text.setAttribute('y',y*1000);text.textContent=region.name;svg.append(text);}svg.style.display=room&&isTop()?'':'none';}

function appendTaskGeometry(task,geometry,index){if(!geometry.points?.length)return;
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.dataset.task=task.id;svg.setAttribute('viewBox','0 0 1000 1000');svg.setAttribute('preserveAspectRatio','none');const color=kindInfo[iconType(task)]?.[1]||'#657f74';svg.style.setProperty('--geometry-color',color);svg.style.color=color;
 const shape=document.createElementNS(svg.namespaceURI,geometry.shape==='area'?'polygon':geometry.shape==='unloading'?'circle':'polyline');
 if(geometry.shape==='unloading'){shape.setAttribute('cx',geometry.points[0][0]*1000);shape.setAttribute('cy',geometry.points[0][1]*1000);shape.setAttribute('r',14);shape.classList.add('unloading-point');const label=document.createElementNS(svg.namespaceURI,'text');label.setAttribute('x',geometry.points[0][0]*1000+18);label.setAttribute('y',geometry.points[0][1]*1000+5);label.textContent='작업·하역';svg.append(label);}
 else shape.setAttribute('points',geometry.points.map(p=>p.map(v=>v*1000).join(',')).join(' '));
 if(geometry.shape==='route'){const defs=document.createElementNS(svg.namespaceURI,'defs');const id='arrow-'+task.id+'-'+index;defs.innerHTML='<marker id="'+id+'" markerWidth="9" markerHeight="9" refX="8" refY="4" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L8,4 L0,8 Z" fill="currentColor"/></marker>';svg.append(defs);shape.style.markerEnd='url(#'+id+')';}
 svg.append(shape);$('routeLayer').append(svg);
}
$('keepGeometry').onclick=()=>{const shape=$('taskShape').value,needed=shape==='area'?3:shape==='route'?2:1;if(draft.length<needed){toast('현재 표시의 위치를 먼저 지정해주세요.');return;}if(keptGeometry.length>=10){toast('추가 표시는 최대 10개입니다.');return;}keptGeometry.push({shape,points:structuredClone(draft)});draft=[];renderDraft();$('keptGeometryCount').textContent=keptGeometry.length+'개 보관됨';toast('표시를 보관했습니다. 다음 동선이나 작업·하역 위치를 추가하세요.');};

$('siteName').oninput=()=>{if(siteDraft)siteDraft.name=$('siteName').value;};

function updateViewButtons(){for(const id of ['previousView','mobileViewBack'])$(id).disabled=!viewHistory.length;}
function rememberView(){const current={zoom,panX,panY,fitMode};const previous=viewHistory.at(-1);if(!previous||JSON.stringify(current)!==JSON.stringify(previous)){viewHistory.push(current);if(viewHistory.length>30)viewHistory.shift();}updateViewButtons();}
function previousView(){cancelAreaZoom();const previous=viewHistory.pop();if(previous){({zoom,panX,panY,fitMode}=previous);setZoom();}updateViewButtons();}
function resetView(){cancelAreaZoom();rememberView();zoom=1;panX=0;panY=0;fitMode='contain';setZoom();}
function cancelAreaZoom(){areaGesture=null;$('zoomSelection').hidden=true;}
function selectionPoint(e){return [Math.max(areaGesture.left,Math.min(areaGesture.right,e.clientX)),Math.max(areaGesture.top,Math.min(areaGesture.bottom,e.clientY))];}
viewport.addEventListener('pointerdown',e=>{
 if(mode!=='zoom'||picking||regionPicking||e.button!==0)return;
 const v=viewport.getBoundingClientRect(),image=$('scene').getBoundingClientRect();const left=Math.max(v.left,image.left),right=Math.min(v.right,image.right),top=Math.max(v.top,image.top),bottom=Math.min(v.bottom,image.bottom);
 if(e.clientX<left||e.clientX>right||e.clientY<top||e.clientY>bottom)return;
 e.preventDefault();e.stopImmediatePropagation();areaGesture={x:e.clientX,y:e.clientY,left,right,top,bottom,viewport:v};viewport.setPointerCapture(e.pointerId);$('zoomSelection').hidden=false;drawSelection(e);
},true);
function drawSelection(e){if(!areaGesture)return;const [x,y]=selectionPoint(e),g=areaGesture;g.endX=x;g.endY=y;Object.assign($('zoomSelection').style,{left:Math.min(g.x,x)-g.viewport.left+'px',top:Math.min(g.y,y)-g.viewport.top+'px',width:Math.abs(g.x-x)+'px',height:Math.abs(g.y-y)+'px'});}
viewport.addEventListener('pointermove',e=>{if(areaGesture){e.preventDefault();e.stopImmediatePropagation();drawSelection(e);}},true);
viewport.addEventListener('pointerup',e=>{
 if(!areaGesture)return;e.stopImmediatePropagation();drawSelection(e);const g=areaGesture,w=Math.abs(g.endX-g.x),h=Math.abs(g.endY-g.y);cancelAreaZoom();
 if(w<12||h<12){toast('확대할 구간을 사각형으로 드래그해주세요.');return;}
 rememberView();const target=Math.min((g.viewport.width-24)/w,(g.viewport.height-24)/h);const next=Math.max(.2,Math.min(8,zoom*target)),factor=next/zoom;
 const x=(g.x+g.endX)/2-g.viewport.left-g.viewport.width/2,y=(g.y+g.endY)/2-g.viewport.top-g.viewport.height/2;
 panX=-(x-panX)*factor;panY=-(y-panY)*factor;zoom=next;setZoom();selectMode('pan');
},true);
viewport.addEventListener('pointercancel',cancelAreaZoom);viewport.addEventListener('lostpointercapture',()=>{if(areaGesture)cancelAreaZoom();});
window.addEventListener('keydown',e=>{if(e.key==='Escape'){cancelAreaZoom();if(mode==='zoom'||mode==='draw')selectMode('pointer');}});
$('previousView').onclick=previousView;$('mobileViewBack').onclick=previousView;$('resetView').onclick=resetView;$('mobileFit').onclick=resetView;
$('mobileClear').onclick=clearAndExit;$('mobileDone').onclick=()=>selectMode('pointer');
function measureMobilePanel(){const mobile=matchMedia('(max-width:900px), (pointer:coarse)').matches;const height=mobile&&!$('sidePanel').hidden?Math.ceil($('sidePanel').getBoundingClientRect().height)+8:0;const value=height+'px';if($('workspace').style.getPropertyValue('--mobile-panel-height')!==value){$('workspace').style.setProperty('--mobile-panel-height',value);setZoom();}}
new ResizeObserver(measureMobilePanel).observe($('sidePanel'));window.addEventListener('resize',measureMobilePanel);selectMode('pointer');updateViewButtons();
