const $ = id => document.getElementById(id);
let room, socket, mode='pointer', zoom=1, joined=false, retry, toastTimer;
const ctx=$('ink').getContext('2d');
const roomId=new URLSearchParams(location.search).get('room');
if(roomId) { $('enter').textContent='회의 참여 →'; $('welcome').querySelector('h2').textContent='진행 중인 회의에 참여하세요'; }
let hostSetup=false;
const fragment=new URLSearchParams(location.hash.slice(1));
if(fragment.has('host')){sessionStorage.setItem('mouseon-host',fragment.get('host'));history.replaceState(null,'',location.pathname+location.search);}
const hostHeaders={'X-Mouseon-Host':sessionStorage.getItem('mouseon-host')||''};
const roomQuery=()=>'?room='+encodeURIComponent(new URLSearchParams(location.search).get('room')||'');
let passwordRequired=false;
const accessReady=fetch('/api/access'+roomQuery()).then(r=>{if(!r.ok)throw Error('접속 상태를 확인하지 못했습니다.');return r.json();}).then(state=>{
 hostSetup=state.hostSetup;
 $('passwordLabel').textContent=hostSetup&&!roomId?'회의 비밀번호 지정 (4자 이상)':'회의 비밀번호';
 passwordRequired=state.passwordRequired&&!state.authenticated;
 $('passwordField').hidden=!passwordRequired;$('password').required=passwordRequired;
}).catch(error=>{toast(error.message);});
$('name').value=sessionStorage.getItem('mouseon-name')||'';
function toast(text){$('toast').textContent=text;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),3500);}
function send(m){if(socket?.readyState===WebSocket.OPEN){socket.send(JSON.stringify(m));return true;}toast('연결을 확인하고 다시 시도해주세요.');return false;}
function connected(ok,text){$('led').classList.toggle('on',ok);$('status').textContent=text;}
$('entry').onsubmit=async e=>{e.preventDefault();$('enter').disabled=true;try{
  const name=$('name').value.trim();if(!name)throw Error('이름을 입력해주세요.');sessionStorage.setItem('mouseon-name',name);
  await accessReady;
  if(passwordRequired && !(hostSetup&&!new URLSearchParams(location.search).get('room'))){
    const login=await fetch('/api/login'+roomQuery(),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:$('password').value})});
    const result=await login.json();if(!login.ok)throw Error(result.error||'로그인하지 못했습니다.');
    passwordRequired=false;$('password').value='';$('password').required=false;$('passwordField').hidden=true;
  }
  let id=new URLSearchParams(location.search).get('room');
  if(!id){const res=await fetch('/api/rooms',{method:'POST',headers:{...hostHeaders,'Content-Type':'application/json'},body:JSON.stringify({password:$('password').value})});if(!res.ok){const error=await res.json();throw Error(error.error||'회의를 만들지 못했습니다.');}id=(await res.json()).id;history.replaceState(null,'','?room='+id);}
  $('password').value='';passwordRequired=false;
  connect(id,name);
}catch(err){toast(err.message);$('enter').disabled=false;}};
function connect(id,name){
  clearTimeout(retry);connected(false,'연결 중');
  socket=new WebSocket(`${location.protocol==='https:'?'wss:':'ws:'}//${location.host}/?room=${encodeURIComponent(id)}&name=${encodeURIComponent(name)}`);
  socket.onopen=()=>{connected(true,'실시간 연결됨');};
  socket.onmessage=event=>{const m=JSON.parse(event.data);
    if(m.type==='state'){
      room=m.room;if(!joined){joined=true;$('welcome').hidden=true;$('workspace').hidden=false;$('share').disabled=false;}
      render();if(m.notice)toast(m.notice);
    } else if(m.type==='stroke' && m.image===room.image){room.strokes.push(m.stroke);paint(m.stroke);}
    else if(m.type==='pointer'){showPointer(m);}
    else if(m.type==='presence')$('presence').textContent=`· ${m.count}명 참여`;
    else if(m.type==='error')toast(m.message);
  };
  socket.onclose=e=>{connected(false,'연결 끊김');$('enter').disabled=false;
    if(e.code===1008){toast(e.reason||'참여할 수 없습니다. 주소와 비밀번호를 확인해주세요.');joined=false;$('welcome').hidden=false;$('workspace').hidden=true;$('share').disabled=true;passwordRequired=true;$('passwordField').hidden=false;$('password').required=true;return;}
    toast('연결이 끊겼습니다. 다시 연결 중입니다.');retry=setTimeout(()=>connect(id,name),1800);
  };
  socket.onerror=()=>connected(false,'서버 연결 확인 중');
}
function el(tag,cls,text){const node=document.createElement(tag);if(cls)node.className=cls;if(text!==undefined)node.textContent=text;return node;}
function isTop(){return room.image===room.topImage;}
function render(){
  const image=room.image||'/sample.svg';if($('background').getAttribute('src')!==image){$('background').src=image;zoom=1;setZoom();}
  $('viewTitle').textContent=isTop()?'현장 탑뷰':'문제 사진';$('imageNote').textContent=room.image?(isTop()?'업로드한 현장 탑뷰':'공유 중인 문제 사진'):'샘플 배치도';
  $('back').disabled=isTop();$('tasks').replaceChildren();$('routeLayer').replaceChildren();$('sequence').replaceChildren();$('taskCount').textContent=room.tasks.length;
  const groups=Map.groupBy(room.tasks,t=>t.equipment);
  for(const [equipment,tasks] of groups){
    const group=el('section','equipment');group.append(el('h3','',equipment));
    tasks.forEach((task,i)=>{
      const row=el('div','task-row');row.append(el('span','step',String(i+1)));
      const info=el('div','task-info');info.append(el('b','',`${task.icon} ${task.title}`),el('small','',task.detail));row.append(info);
      const controls=el('div','order-buttons');
      for(const [d,label] of [[-1,'↑'],[1,'↓']]){const button=el('button','',label);button.setAttribute('aria-label',task.title+(d===-1?' 순서 올리기':' 순서 내리기'));button.disabled=d===-1?i===0:i===tasks.length-1;button.onclick=()=>send({type:'reorder',id:task.id,direction:d,revision:room.revision});controls.append(button);}
      row.append(controls);group.append(row);
      if(isTop()){
        const marker=el('button','marker');marker.dataset.id=task.id;marker.style.left=task.x*100+'%';marker.style.top=task.y*100+'%';marker.setAttribute('aria-label',`${task.title} 위치`);
        marker.append(el('span','marker-icon',task.icon),el('span','marker-number',String(i+1)),el('span','marker-label',task.title));
        marker.title=task.detail+' · PTW 미조회';marker.onclick=()=>{if(mode!=='move')toast(`${task.title} · ${task.detail} · PTW 미조회`);};$('tasks').append(marker);
      }
    });$('sequence').append(group);
    if(isTop()&&tasks.length>1){
      const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 1000 1000');svg.setAttribute('preserveAspectRatio','none');
      const line=document.createElementNS(svg.namespaceURI,'polyline');line.setAttribute('points',tasks.map(t=>`${t.x*1000},${t.y*1000}`).join(' '));svg.append(line);$('routeLayer').append(svg);
    }
  }
  resizeInk();
}
function resizeInk(){const rect=$('scene').getBoundingClientRect();const canvas=$('ink');canvas.width=Math.max(1,rect.width*devicePixelRatio);canvas.height=Math.max(1,rect.height*devicePixelRatio);if(room)room.strokes.forEach(paint);}
function paint(stroke){const c=$('ink');ctx.strokeStyle=stroke.color;ctx.lineWidth=3*devicePixelRatio;ctx.lineCap='round';ctx.lineJoin='round';ctx.beginPath();stroke.points.forEach(([x,y],i)=>i?ctx.lineTo(x*c.width,y*c.height):ctx.moveTo(x*c.width,y*c.height));ctx.stroke();}
$('background').onload=()=>{const img=$('background');$('scene').style.aspectRatio=`${img.naturalWidth} / ${img.naturalHeight}`;resizeInk();};
new ResizeObserver(resizeInk).observe($('scene'));
function point(e){const r=$('scene').getBoundingClientRect();return [Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),Math.max(0,Math.min(1,(e.clientY-r.top)/r.height))];}
const pointerTimers=new Map();
function showPointer(m){let p=document.getElementById('p-'+m.peer);if(!p){p=el('div','remote-pointer');p.id='p-'+m.peer;p.append(el('span','','↖'),el('b','',m.person));$('pointers').append(p);}p.style.left=m.x*100+'%';p.style.top=m.y*100+'%';clearTimeout(pointerTimers.get(m.peer));pointerTimers.set(m.peer,setTimeout(()=>{p.remove();pointerTimers.delete(m.peer);},1500));}
let gesture=null,lastSent=0;
$('scene').onpointerdown=e=>{
  if(!room||socket?.readyState!==WebSocket.OPEN)return;
  const marker=e.target.closest('.marker'), p=point(e);
  if(mode==='move'&&marker){
    e.preventDefault();const task=room.tasks.find(t=>t.id===marker.dataset.id);
    gesture={type:'move',id:task.id,marker,startX:e.clientX,startY:e.clientY,original:[task.x,task.y],ready:e.pointerType!=='touch'};
    if(!gesture.ready)gesture.timer=setTimeout(()=>{if(gesture){gesture.ready=true;navigator.vibrate?.(25);}},350);
  }else if(mode==='draw'){e.preventDefault();gesture={type:'draw',last:p};}
  else if(mode==='pointer'){e.preventDefault();gesture={type:'pointer'};send({type:'pointer',x:p[0],y:p[1]});}
  if(gesture)$('scene').setPointerCapture(e.pointerId);
};
$('scene').onpointermove=e=>{
  if(!room)return;const p=point(e), now=performance.now();
  if(gesture?.type==='move'){
    if(!gesture.ready){if(Math.hypot(e.clientX-gesture.startX,e.clientY-gesture.startY)>12){clearTimeout(gesture.timer);gesture.marker.style.left=gesture.original[0]*100+'%';gesture.marker.style.top=gesture.original[1]*100+'%';gesture=null;}return;}
    gesture.marker.style.left=p[0]*100+'%';gesture.marker.style.top=p[1]*100+'%';return;
  }
  if(now-lastSent<25)return;lastSent=now;
  if(gesture?.type==='draw'){const stroke={points:[gesture.last,p],color:'#ff6847'};if(send({type:'stroke',points:stroke.points,image:room.image})){room.strokes.push(stroke);paint(stroke);}gesture.last=p;}
  else if(mode==='pointer' && (e.pointerType==='mouse'||gesture))send({type:'pointer',x:p[0],y:p[1]});
};
function finish(e,cancel=false){if(!gesture)return;clearTimeout(gesture.timer);const g=gesture;gesture=null;
 if(g.type==='move'){if(!cancel&&g.ready){const p=point(e);send({type:'move',id:g.id,x:p[0],y:p[1]});}else{g.marker.style.left=g.original[0]*100+'%';g.marker.style.top=g.original[1]*100+'%';}}
 if(g.type==='draw'&&!cancel){const p=point(e);const stroke={points:[g.last,p],color:'#ff6847'};if(send({type:'stroke',points:stroke.points,image:room.image})){room.strokes.push(stroke);paint(stroke);}}
}
$('scene').onpointerup=e=>finish(e);$('scene').onpointercancel=e=>finish(e,true);
for(const button of document.querySelectorAll('[data-mode]'))button.onclick=()=>{
  mode=button.dataset.mode;document.querySelectorAll('[data-mode]').forEach(b=>b.classList.toggle('active',b===button));$('scene').dataset.mode=mode;
  $('modeHint').textContent={pointer:'터치하거나 움직여 위치를 가리키세요',draw:'사진 위에 자유롭게 그려보세요',move:'아이콘을 길게 눌러 위치를 옮기세요'}[mode];
};
$('scene').dataset.mode=mode;
$('clear').onclick=()=>send({type:'clear'});$('back').onclick=()=>send({type:'top'});
function setZoom(){$('scene').style.width=zoom*100+'%';$('zoomLabel').textContent=Math.round(zoom*100)+'%';}
$('zoomIn').onclick=()=>{zoom=Math.min(3,zoom+.25);setZoom();};$('zoomOut').onclick=()=>{zoom=Math.max(1,zoom-.25);setZoom();};
let uploading=false;
for(const [input,kind] of [['topFile','top'],['photoFile','photo']])$(input).onchange=()=>{
 const file=$(input).files[0];if(!file)return;
 if(uploading){toast('진행 중인 업로드가 끝난 뒤 다시 선택해주세요.');$(input).value='';return;}
 if(file.size>50*1024*1024){toast('사진은 최대 50MB까지 지원합니다.');$(input).value='';return;}
 uploading=true;const xhr=new XMLHttpRequest();xhr.open('POST',`/api/rooms/${room.id}/image?kind=${kind}`);xhr.timeout=180000;
 xhr.upload.onprogress=e=>{if(e.lengthComputable)toast(`사진 업로드 중 · ${Math.round(e.loaded/e.total*100)}%`);};
 xhr.onload=()=>{let result;try{result=JSON.parse(xhr.responseText);}catch{}toast(xhr.status===200?'사진을 공유했습니다.':result?.error||'업로드에 실패했습니다.');};
 xhr.onerror=()=>toast('업로드 연결을 확인해주세요.');xhr.ontimeout=()=>toast('업로드 시간이 초과되었습니다. 다시 시도해주세요.');xhr.onloadend=()=>{uploading=false;$(input).value='';};xhr.send(file);
};
let sharePoll;
function updateShare(){
 const address=$('networkAddress').value;
 if(!address){$('qr').hidden=true;$('joinUrl').hidden=true;$('copy').disabled=true;return;}
 const link=address+'/?room='+room.id;
 $('joinUrl').value=link;$('joinUrl').hidden=false;$('qr').hidden=false;
 const src='/api/qr?url='+encodeURIComponent(link)+'&room='+room.id;if($('qr').getAttribute('src')!==src)$('qr').src=src;
 $('copy').disabled=false;
}
$('networkAddress').onchange=updateShare;
async function refreshShare(){
 try{
   const res=await fetch('/api/network'+roomQuery(),{headers:hostHeaders});if(!res.ok)throw Error('참여 주소 확인에 실패했습니다. 다시 로그인하거나 연결 상태를 확인해주세요.');
   const {addresses,tunnel}=await res.json();let choices=[];
   if(tunnel.status!=='local'){
     if(tunnel.status==='ready'&&tunnel.url){choices=[tunnel.url];$('shareStatus').textContent='인터넷 연결됨 · 휴대폰 LTE·5G에서도 참여할 수 있습니다.';}
     else $('shareStatus').textContent=tunnel.message||'인터넷 주소 연결 중입니다. 잠시 기다려주세요.';
   } else {
     const loopback=['localhost','127.0.0.1','[::1]'].includes(location.hostname);
     choices=loopback?addresses:[location.origin];
     $('shareStatus').textContent=choices.length?'로컬 연결 · PC와 휴대폰이 같은 네트워크에 있어야 합니다.':'휴대폰용 주소를 찾지 못했습니다. PC의 Wi-Fi 또는 유선 연결을 확인해주세요.';
   }
   const previous=$('networkAddress').value;
   $('networkAddress').replaceChildren(...choices.map(address=>{const option=el('option','',address);option.value=address;return option;}));
   if(choices.includes(previous))$('networkAddress').value=previous;
   $('networkAddress').hidden=!choices.length;updateShare();
 }catch(error){$('shareStatus').textContent=error.message;$('networkAddress').replaceChildren();updateShare();}
}
$('share').onclick=()=>{
 $('networkAddress').replaceChildren();updateShare();$('shareDialog').showModal();
 refreshShare();clearInterval(sharePoll);sharePoll=setInterval(refreshShare,2000);
};
$('closeShare').onclick=()=>$('shareDialog').close();
$('shareDialog').addEventListener('close',()=>clearInterval(sharePoll));
$('copy').onclick=async()=>{try{await navigator.clipboard.writeText($('joinUrl').value);toast('참여 링크를 복사했습니다.');}catch{$('joinUrl').select();toast('주소를 선택했습니다. 길게 누르거나 Ctrl+C로 복사해주세요.');}};
