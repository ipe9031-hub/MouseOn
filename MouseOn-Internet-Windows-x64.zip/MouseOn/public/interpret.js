import {validDate} from './calendar.js';
export const kindInfo={formwork:['갱폼','#a45352'],rope:['로프 작업','#a75487'],tower:['타워크레인','#8061ac'],mobile:['이동식 크레인','#8061ac'],concrete:['타설','#3d83bb'],mixer:['레미콘','#3d83bb'],excavator:['굴착기','#ce8a39'],forklift:['지게차·하역','#398e8c'],dump:['덤프','#947157'],other:['기타','#657f74']};
export function kindOf(text){return /갱폼/.test(text)?'formwork':/로프/.test(text)?'rope':/타워/.test(text)?'tower':/크레인|인양|양중/.test(text)?'mobile':/레미콘/.test(text)?'mixer':/타설|콘크리트/.test(text)?'concrete':/지게차|하역/.test(text)?'forklift':/덤프/.test(text)?'dump':/굴착|백호/.test(text)?'excavator':'other';}
function hit(text,alias){const a=alias.replace(/\s/g,'');let from=0,i;while((i=text.indexOf(a,from))!==-1){if(!(/^\d/.test(a)&&i>0&&/\d/.test(text[i-1]))&&!(/\d$/.test(a)&&/\d/.test(text[i+a.length]||'')))return true;from=i+1;}return false;}
export function matchRegions(text,regions){const clean=text.replace(/\s/g,'');return regions.filter(r=>[r.name,...r.aliases].some(a=>hit(clean,a)));}
export function inside(point,polygon){let yes=false;for(let i=0,j=polygon.length-1;i<polygon.length;j=i++){const a=polygon[i],b=polygon[j];if((a[1]>point[1])!==(b[1]>point[1])&&point[0]<(b[0]-a[0])*(point[1]-a[1])/(b[1]-a[1])+a[0])yes=!yes;}return yes;}
export function regionPoint(region,slot=0){const p=region.points;const xs=p.map(a=>a[0]),ys=p.map(a=>a[1]);const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);const center=[(minX+maxX)/2,(minY+maxY)/2];if(slot>0){for(let step=0;step<50;step++){const angle=(slot+step)*2.399963;const radius=.16+(slot%3)*.09;const q=[center[0]+(maxX-minX)*radius*Math.cos(angle),center[1]+(maxY-minY)*radius*Math.sin(angle)];if(inside(q,p))return q;}}if(inside(center,p))return center;for(let y=1;y<30;y++)for(let x=1;x<30;x++){const q=[minX+(maxX-minX)*x/30,minY+(maxY-minY)*y/30];if(inside(q,p))return q;}return p[0];}
export function interpret(entry,regions){
 if(typeof entry?.text!=='string'||!validDate(entry.date))throw Error('일정 원문·날짜를 확인해주세요.');
 const matches=matchRegions(entry.text,regions),region=matches.length===1?matches[0]:null;
 const reasons=[];if(!region)reasons.push(matches.length?'여러 영역이 언급되어 위치 확인 필요':'등록된 동·시설을 찾지 못했습니다.');
 if(/북|남|동측|서측|동쪽|서쪽/.test(entry.text))reasons.push('방향 표현은 현장 방위 확인 후 조정해주세요.');
 if(/갱폼|로프|고소|해체|인양|밀폐|화기/.test(entry.text))reasons.push('고위험 작업의 상하·주변 작업 확인 필요 (자동 간섭 판정 아님)');
 const point=region?regionPoint(region):null;return {title:entry.text.replace(/\n/g,' ').slice(0,80),detail:'',date:entry.date,icon:kindOf(entry.text),regionId:region?.id||null,x:point?.[0]??null,y:point?.[1]??null,original:entry.text,calendar:entry.calendar||'',reasons};
}
