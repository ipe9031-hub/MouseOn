import {extractSchedules,networkSourceId} from './works-network.mjs';
import {validDate} from './public/calendar.js';
const HOST='calendar.worksmobile.com';
const allowed=url=>{try{const u=new URL(url);return u.protocol==='https:'&&u.hostname===HOST&&!u.username&&!u.password;}catch{return false;}};
export function createNetworkReader({now=()=>Date.now(),setTimer=setInterval,clearTimer=clearInterval}={}){
 let session=null,unsubscribe=null,timer=null,timeout=null,running=false,phase='stopped',message='',scope=null,generation=0,lastRead=null,waiting=false,scopeAfter=0;
 const sources=new Map(),pending=new Map(),schemaKeys=new Set();let jsonResponses=0,unscopedEvents=0,requestSequence=0;
 function inspectKeys(v,depth=0){if(!v||typeof v!=='object'||depth>6||schemaKeys.size>=100)return;if(Array.isArray(v)){if(v.length)inspectKeys(v[0],depth+1);return;}for(const [k,item]of Object.entries(v)){if(/token|cookie|password|secret|auth|session|headers/i.test(k))continue;if(/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(k))schemaKeys.add(k);inspectKeys(item,depth+1);}}
 function status(){return {phase,message,diagnostic:{jsonResponses,unscopedEvents,schemaKeys:[...schemaKeys].sort()},automatic:Boolean(timer),scope,generation,lastRead,sources:[...sources.values()].map(s=>({id:s.id,method:s.method,calendarId:s.calendarId,calendarName:s.calendarName,count:s.events.length,dates:[...new Set(s.events.map(e=>e.date))].sort()})),snapshot:scope&&lastRead&&!waiting?{generation,at:lastRead,scope,events:(sources.get(scope.sourceId)?.events||[]).filter(e=>e.date===scope.date)}:null};}
 async function stop(){if(timer)clearTimer(timer);timer=null;clearTimeout(timeout);timeout=null;waiting=false;unsubscribe?.();unsubscribe=null;const previous=session;session=null;if(previous)try{await previous.close();}catch{}sources.clear();pending.clear();scope=null;lastRead=null;phase='stopped';message='자동 수집을 중지했습니다.';return status();}
 function accept(request,payload){
  jsonResponses++;inspectKeys(payload);const parsed=extractSchedules(payload);unscopedEvents+=parsed.unscoped;const groups=Map.groupBy(parsed.events,e=>e.calendarId);
  for(const [calendarId,events] of groups){
   if(sources.size>=30&&!sources.has(networkSourceId(request.path,request.method,calendarId)))continue;
   const id=networkSourceId(request.path,request.method,calendarId);if((sources.get(id)?.sequence||0)>request.sequence)continue;const source={id,method:request.method,calendarId,calendarName:events[0].calendarName,sequence:request.sequence,events};sources.set(id,source);
   if(scope?.sourceId===id&&request.sequence>scopeAfter&&events.some(e=>e.date===scope.date)){
    generation++;lastRead=now();waiting=false;clearTimeout(timeout);timeout=null;phase='collecting';message='선택한 캘린더의 일정 데이터를 갱신했습니다.';
   }
  }
  if(!scope&&sources.size){phase='choose';message='일정 데이터가 확인됐습니다. 현장 캘린더와 날짜를 선택해주세요.';}
  else if(!sources.size&&parsed.unscoped){phase='unsupported';message='일정은 찾았지만 캘린더 식별자가 없어 자동 반영하지 않았습니다. 통신 구조 확인이 필요합니다.';}
 }
 async function receive(event){
  const {method,params:p}=event;
  if(method==='Network.responseReceived'){
   if(!['XHR','Fetch'].includes(p.type)||!allowed(p.response?.url))return;
   if([401,403].includes(p.response.status)){if(timer)clearTimer(timer);timer=null;waiting=true;phase='login';message='일정 접근 인증을 확인해주세요. 자동 반영을 중단했습니다.';return;}
   if(p.response.status!==200||!/json/i.test(p.response.mimeType||''))return;
   const previous=pending.get(p.requestId);if(!previous)return;
   previous.response=true;return;
  }
  if(method==='Network.requestWillBeSent'){
   if(!['XHR','Fetch'].includes(p.type)||!allowed(p.request?.url)||!['GET','POST'].includes(p.request.method))return;
   if(pending.size>=100)pending.delete(pending.keys().next().value);
   pending.set(p.requestId,{method:p.request.method,path:new URL(p.request.url).pathname,response:false,at:now(),sequence:++requestSequence});return;
  }
  if(method==='Network.loadingFailed'){pending.delete(p.requestId);return;}
  if(method!=='Network.loadingFinished')return;
  const request=pending.get(p.requestId);pending.delete(p.requestId);
  if(!request?.response||now()-request.at>30000||p.encodedDataLength>2*1024*1024||!session)return;
  const current=session;
  try{
   const result=await current.call('Network.getResponseBody',{requestId:p.requestId});
   if(current!==session)return;
   const raw=result.base64Encoded?Buffer.from(result.body,'base64').toString('utf8'):result.body;
   if(typeof raw!=='string'||Buffer.byteLength(raw)>2*1024*1024)return;
   accept(request,JSON.parse(raw.replace(/^\)\]\}\',?\s*/,'')));
  }catch{if(current===session&&!sources.size){phase='waiting';message='일정 응답이 아직 확인되지 않았습니다. 로그인·캘린더 선택을 확인해주세요.';}}
 }
 async function reload(){
  if(!session||running)return;running=true;const current=session;
  try{
   const location=await current.evaluate('location.href');
   if(!allowed(location)||!new URL(location).pathname.startsWith('/web/calendar/'))throw Error('login');
   waiting=true;phase=scope?'collecting':'waiting';message='일정 데이터 응답을 기다리고 있습니다.';clearTimeout(timeout);
   timeout=setTimeout(()=>{if(session===current&&waiting){phase='unconfirmed';message='선택한 날짜의 일정 데이터를 확인하지 못했습니다. 기존 작업은 유지합니다. 캘린더 창의 조회 날짜와 로그인을 확인해주세요.';}},15000);timeout.unref?.();
   pending.clear();await current.call('Page.reload',{ignoreCache:true});
  }catch{
   if(session!==current)return;if(timer)clearTimer(timer);timer=null;waiting=true;phase='login';message='연동 브라우저의 로그인 상태를 확인해주세요. 자동 반영을 중단했습니다.';
  }finally{running=false;}
 }
 return {
  status,
  async start(newSession){await stop();session=newSession;generation=0;jsonResponses=0;unscopedEvents=0;schemaKeys.clear();phase='waiting';message='일정 데이터 통신을 찾고 있습니다.';unsubscribe=session.subscribe(event=>{void receive(event);});try{await session.call('Network.enable',{maxTotalBufferSize:4*1024*1024,maxResourceBufferSize:2*1024*1024});await reload();return status();}catch(error){await stop();throw Error('일정 통신 관찰을 시작하지 못했습니다.');}},
  async select(input){
   const source=sources.get(input.sourceId);if(!source||!validDate(input.date)||!source.events.some(e=>e.date===input.date))throw Error('수집된 캘린더와 일정이 있는 날짜를 선택해주세요.');
   const seconds=Number(input.intervalSeconds||60);if(![30,60,120,300].includes(seconds))throw Error('수집 간격을 확인해주세요.');
   if(timer)clearTimer(timer);scopeAfter=requestSequence;scope={sourceId:source.id,calendarId:source.calendarId,calendarName:source.calendarName,date:input.date};lastRead=null;waiting=true;clearTimeout(timeout);timeout=null;
   timer=setTimer(()=>{void reload();},seconds*1000);timer.unref?.();phase='collecting';message='선택한 현장 캘린더의 일정 데이터를 자동으로 수집합니다.';await reload();return status();
  },reload,stop
 };
}
