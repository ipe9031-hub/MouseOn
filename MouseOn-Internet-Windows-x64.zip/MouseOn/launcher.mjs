import { spawn } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import path from 'node:path';
import os from 'node:os';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { startTunnel } from './tunnel.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const internet=process.env.MOUSEON_INTERNET==='1';
const hostToken=randomBytes(24).toString('hex');
console.log('Choose your meeting password in the browser.');
const durableData=process.env.DATA_DIR||path.join(process.platform==='win32'?(process.env.LOCALAPPDATA||path.join(os.homedir(),'AppData','Local')):(process.env.XDG_DATA_HOME||path.join(os.homedir(),'.local','share')),'MouseOn');
if(!fs.existsSync(durableData)&&fs.existsSync(path.join(root,'data'))&&durableData!==path.join(root,'data'))fs.cpSync(path.join(root,'data'),durableData,{recursive:true,errorOnExist:true,force:false});
const child=spawn(process.execPath,[path.join(root,'server.js')],{cwd:root,env:{...process.env,DATA_DIR:durableData,MOUSEON_HOST_SETUP:'1',MOUSEON_HOST_TOKEN:hostToken},stdio:['inherit','pipe','inherit','ipc']});
let tunnel, helper,closing=false;
helper=spawn(process.execPath,[path.join(root,'works-probe.mjs')],{cwd:root,env:{...process.env,DATA_DIR:durableData,WORKS_NO_BROWSER:'1'},stdio:['ignore','ignore','ignore','ipc']});
helper.on('message',m=>{if(m.type==='ready'&&child.connected)child.send({type:'worksHelper',url:m.url,key:m.key});});
helper.on('error',()=>console.log('Calendar browser helper could not start.'));
child.stdout.on('data',buffer=>process.stdout.write(buffer));
child.on('message',message=>{
  if(message.type!=='ready')return;
  console.log('\nMouseOn is ready. Keep this window open during the meeting.');
  if(internet){
    console.log('Starting temporary Internet connection via Cloudflare. No account is required.');
    tunnel=startTunnel({executable:process.env.CLOUDFLARED_PATH||path.join(root,'runtime',process.platform==='win32'?'cloudflared.exe':'cloudflared'),port:message.port,onState:state=>{
      if(child.connected)child.send({type:'tunnel',state});
      console.log('Internet: '+state.status+(state.url?' '+state.url:''));
      if(state.status==='failed')console.log('Check Internet access and whether your company permits Cloudflare Tunnel.');
    }});
  } else console.log('Local mode: phone and PC need the same network.');
  const url='http://127.0.0.1:'+message.port+'/#host='+hostToken;
  process.send?.({type:'ready',url});
  if(process.env.MOUSEON_NO_BROWSER!=='1'){
    const command=process.platform==='win32' ? ['cmd.exe',['/d','/c','start','',url]] : process.platform==='darwin' ? ['open',[url]] : ['xdg-open',[url]];
    const browser=spawn(...command,{stdio:'ignore'});browser.on('error',()=>console.log('Open your browser at '+url));
  }
});
function stop(){if(closing)return;closing=true;tunnel?.stop();helper?.kill();child.kill();}
child.on('error',e=>{console.error(e.message);tunnel?.stop();process.exitCode=1;});
child.on('exit',code=>{tunnel?.stop();helper?.kill();process.exitCode=closing?0:code??1;});
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,stop);
