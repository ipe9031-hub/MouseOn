import { spawn } from 'node:child_process';
import { randomBytes } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { startTunnel } from './tunnel.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const internet=process.env.MOUSEON_INTERNET==='1';
const hostToken=randomBytes(24).toString('hex');
console.log('Choose your meeting password in the browser.');
const child=spawn(process.execPath,[path.join(root,'server.js')],{cwd:root,env:{...process.env,MOUSEON_HOST_SETUP:'1',MOUSEON_HOST_TOKEN:hostToken},stdio:['inherit','pipe','inherit','ipc']});
let tunnel, closing=false;
child.stdout.on('data',buffer=>process.stdout.write(buffer));
child.on('message',message=>{
  if(message.type!=='ready')return;
  console.log('\nMouseOn is ready. Keep this window open during the meeting.');
  if(internet){
    console.log('Starting temporary Internet connection via Cloudflare. No account is required.');
    tunnel=startTunnel({executable:process.env.CLOUDFLARED_PATH||path.join(root,'runtime',process.platform==='win32'?'cloudflared.exe':'cloudflared'),port:message.port,onState:state=>{
      if(child.connected)child.send({type:'tunnel',state});
      console.log('Internet: '+state.status+(state.url?' '+state.url:''));
      if(state.status==='failed')console.log('Check Internet access and whether your company permits Cloudflare Tunnel.');
    }});
  } else console.log('Local mode: phone and PC need the same network.');
  const url='http://127.0.0.1:'+message.port+'/#host='+hostToken;
  if(process.env.MOUSEON_NO_BROWSER!=='1'){
    const command=process.platform==='win32' ? ['cmd.exe',['/d','/c','start','',url]] : process.platform==='darwin' ? ['open',[url]] : ['xdg-open',[url]];
    const browser=spawn(...command,{stdio:'ignore'});browser.on('error',()=>console.log('Open your browser at '+url));
  }
});
function stop(){if(closing)return;closing=true;tunnel?.stop();child.kill();}
child.on('error',e=>{console.error(e.message);tunnel?.stop();process.exitCode=1;});
child.on('exit',code=>{tunnel?.stop();process.exitCode=closing?0:code??1;});
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,stop);
