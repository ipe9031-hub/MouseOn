// A deliberate click captures one visible appointment, never the whole account/calendar database.
export const captureExpression=`(()=>{
 if(location.hostname!=='calendar.worksmobile.com')throw Error('Calendar only');
 if(window.__mouseonCalendarCapture?.handler)return {ok:true};
 const state=window.__mouseonCalendarCapture||{items:[]};
 const banner=document.createElement('div');banner.id='mouseon-calendar-banner';
 Object.assign(banner.style,{position:'fixed',bottom:'16px',left:'50%',transform:'translateX(-50%)',zIndex:'2147483647',background:'#153f33',color:'#fff',padding:'14px 22px',borderRadius:'9px',font:'14px sans-serif'});
 banner.textContent='MouseOn 읽기 시험 · 가져올 일정 제목을 클릭하세요. 일정은 수정하지 않습니다. ';const exit=document.createElement('button');exit.textContent='선택 종료';banner.append(exit);document.body.append(banner);
 state.handler=e=>{
  if(banner.contains(e.target))return;
  if(e.target.closest('input,textarea,[contenteditable=true]'))return;
  e.preventDefault();e.stopImmediatePropagation();
  const leaf=(e.target.innerText||e.target.textContent||'').trim();
  if(!leaf||leaf.length>1200){banner.firstChild.textContent='일정 제목의 글자를 눌러주세요. ';return;}
  const candidate=e.composedPath().find(n=>n instanceof HTMLElement && /event|schedule|appointment/i.test(n.className||'') && n.innerText?.trim().length<=1200);
  const text=(candidate?.innerText||leaf).trim();
  if(state.items.length>=50){banner.firstChild.textContent='최대 50개까지 선택할 수 있습니다. ';return;}
  if(!state.items.some(x=>x.text===text))state.items.push({text});
  banner.firstChild.textContent=state.items.length+'개 선택됨 · 미리보기 화면에서 내용을 확인하세요. ';
 };
 exit.onclick=()=>{document.removeEventListener('click',state.handler,true);state.handler=null;banner.remove();};
 document.addEventListener('click',state.handler,true);window.__mouseonCalendarCapture=state;return {ok:true};
})()`;

export function batchExpression(date,calendar){return `(()=>{
 if(location.hostname!=='calendar.worksmobile.com')throw Error('Calendar only');
 const requestedDate=${JSON.stringify(date)}, calendar=${JSON.stringify(calendar)};
 const dateParts=requestedDate.split('-').map(Number);
 const headings=[...document.querySelectorAll('h1,h2,h3,[role=heading],time')].filter(n=>n.getBoundingClientRect().width&&n.getBoundingClientRect().height).map(n=>n.innerText||n.getAttribute('datetime')||'');
 const bodyDate=(document.body.innerText||'').slice(0,3000);
 const datePattern=new RegExp(dateParts[0]+'[.년/\\\\-\\\\s]+0?'+dateParts[1]+'[.월/\\\\-\\\\s]+0?'+dateParts[2]+'(?![0-9])');
 if(!datePattern.test(headings.join(' '))&&!datePattern.test(bodyDate))throw Error('선택한 날짜를 화면에서 확인하지 못했습니다. 웍스를 하루 보기로 열고 같은 날짜를 선택해주세요.');
 const selectors=['[data-event-id]','[data-schedule-id]','.fc-event','.calendar-event','.schedule-item','[class*=event_item]','[class*=eventItem]','[class*=schedule_item]'];
 const candidates=[...new Set(selectors.flatMap(s=>[...document.querySelectorAll(s)]))].filter(n=>{const r=n.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(n).visibility!=='hidden';});
 const leaves=candidates.filter(n=>!candidates.some(other=>other!==n&&n.contains(other)));
 const items=[];const seen=new Set();
 for(const n of leaves){const text=(n.innerText||n.getAttribute('title')||'').trim();if(!text||text.length>1200)continue;
  const calendarName=n.getAttribute('data-calendar-name');if(calendarName&&calendarName!==calendar)continue;
  const start=n.getAttribute('data-start')||n.getAttribute('data-date');if(start&&start.slice(0,10)!==requestedDate)continue;
  const sourceId=n.getAttribute('data-event-id')||n.getAttribute('data-schedule-id')||null;const signature=sourceId||text;if(seen.has(signature))continue;seen.add(signature);
  items.push({text,date:requestedDate,calendar,sourceId});if(items.length>=200)break;
 }
 if(!items.length)throw Error('일정 요소를 찾지 못했습니다. 실제 웍스 화면 구조 확인이 필요합니다. 0건으로 동기화하지 않습니다.');
 return {format:'mouseon-works-preview/v1',entries:items,coverage:'visible-only',warnings:['현재 화면에 로드된 일정만 읽었습니다. 캘린더 선택과 누락 여부를 확인하세요. 전체 수집·수정·취소 동기화는 아직 검증 전입니다.']};
})()`;}
