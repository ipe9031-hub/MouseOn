// A deliberate click captures one visible appointment, never the whole account/calendar database.
export const captureExpression=`(()=>{
 if(location.hostname!=='calendar.worksmobile.com')throw Error('Calendar only');
 if(window.__mouseonCalendarCapture?.handler)return {ok:true};
 const state=window.__mouseonCalendarCapture||{items:[]};
 const banner=document.createElement('div');banner.id='mouseon-calendar-banner';
 Object.assign(banner.style,{position:'fixed',bottom:'16px',left:'50%',transform:'translateX(-50%)',zIndex:'2147483647',background:'#153f33',color:'#fff',padding:'14px 22px',borderRadius:'9px',font:'14px sans-serif'});
 banner.textContent='MouseOn 읽기 시험 · 가져올 일정 제목을 클릭하세요. 일정은 수정하지 않습니다. ';const exit=document.createElement('button');exit.textContent='선택 종료';banner.append(exit);document.body.append(banner);
 state.handler=e=>{
  if(banner.contains(e.target))return;
  if(e.target.closest('input,textarea,[contenteditable=true]'))return;
  e.preventDefault();e.stopImmediatePropagation();
  const leaf=(e.target.innerText||e.target.textContent||'').trim();
  if(!leaf||leaf.length>1200){banner.firstChild.textContent='일정 제목의 글자를 눌러주세요. ';return;}
  const candidate=e.composedPath().find(n=>n instanceof HTMLElement && /event|schedule|appointment/i.test(n.className||'') && n.innerText?.trim().length<=1200);
  const text=(candidate?.innerText||leaf).trim();
  if(state.items.length>=50){banner.firstChild.textContent='최대 50개까지 선택할 수 있습니다. ';return;}
  if(!state.items.some(x=>x.text===text))state.items.push({text});
  banner.firstChild.textContent=state.items.length+'개 선택됨 · 미리보기 화면에서 내용을 확인하세요. ';
 };
 exit.onclick=()=>{document.removeEventListener('click',state.handler,true);state.handler=null;banner.remove();};
 document.addEventListener('click',state.handler,true);window.__mouseonCalendarCapture=state;return {ok:true};
})()`;

export const worksReadErrors={
 WORKS_DATE_MISMATCH:'선택한 날짜를 화면에서 확인하지 못했습니다. 웍스를 하루 보기로 열고 앱과 같은 날짜를 선택해주세요.',
 WORKS_NO_EVENT_ELEMENTS:'현재 화면에서 일정 요소를 찾지 못했습니다. 화면 구조 진단 파일을 보내주시면 실제 태그에 맞춰 수집기를 수정할 수 있습니다. 기존 작업은 삭제하지 않습니다.',
 WORKS_LOGIN_REQUIRED:'로그인 후 캘린더 본문을 열어주세요. 로그인 화면에서는 일정을 읽지 않습니다.',
 WORKS_WRONG_HOST:'연동용 브라우저에서 calendar.worksmobile.com 캘린더를 열어주세요.',
 WORKS_SCRIPT_ERROR:'일정 읽기 스크립트 실행 중 오류가 발생했습니다. 화면 구조 진단을 진행해주세요.'
};
function collectBatch(requestedDate,calendar){
 const fail=code=>({readError:{code}});
 try{
  if(location.hostname!=='calendar.worksmobile.com')return fail('WORKS_WRONG_HOST');
  if(/login/i.test(location.pathname)||[...document.querySelectorAll('input[type=password]')].some(n=>n.getBoundingClientRect().width&&n.getBoundingClientRect().height))return fail('WORKS_LOGIN_REQUIRED');
  const parts=requestedDate.split('-').map(Number);
  const headings=[...document.querySelectorAll('h1,h2,h3,[role=heading],time')].filter(n=>n.getBoundingClientRect().width&&n.getBoundingClientRect().height).map(n=>n.innerText||n.getAttribute('datetime')||'');
  const displayed=[...headings,(document.body.innerText||'').slice(0,3000)].join(' ');
  const matches=[...displayed.matchAll(/(\d{4})\s*[.년/\-]\s*(\d{1,2})\s*[.월/\-]\s*(\d{1,2})(?!\d)/g)];
  if(!matches.some(m=>parts.every((v,i)=>v===Number(m[i+1]))))return fail('WORKS_DATE_MISMATCH');
  const selectors=['[data-event-id]','[data-schedule-id]','.fc-event','.calendar-event','.schedule-item','[class*=event_item]','[class*=eventItem]','[class*=schedule_item]'];
  const candidates=[...new Set(selectors.flatMap(s=>[...document.querySelectorAll(s)]))].filter(n=>{const r=n.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(n).visibility!=='hidden';});
  const leaves=candidates.filter(n=>!candidates.some(other=>other!==n&&n.contains(other)));const items=[],seen=new Set();
  for(const n of leaves){const text=(n.innerText||n.getAttribute('title')||'').trim();if(!text||text.length>1200)continue;const calendarName=n.getAttribute('data-calendar-name');if(calendarName&&calendarName!==calendar)continue;const start=n.getAttribute('data-start')||n.getAttribute('data-date');if(start&&start.slice(0,10)!==requestedDate)continue;const sourceId=n.getAttribute('data-event-id')||n.getAttribute('data-schedule-id')||null,signature=sourceId||text;if(seen.has(signature))continue;seen.add(signature);items.push({text,date:requestedDate,calendar,sourceId});if(items.length>=200)break;}
  if(!items.length)return fail('WORKS_NO_EVENT_ELEMENTS');
  return {format:'mouseon-works-preview/v1',entries:items,coverage:'visible-only',warnings:['현재 화면에 로드된 일정만 읽었습니다. 캘린더 선택과 누락 여부를 확인하세요. 전체 수집·수정·취소 동기화는 아직 검증 전입니다.']};
 }catch{return fail('WORKS_SCRIPT_ERROR');}
}
export function batchExpression(date,calendar){return `(${collectBatch.toString()})(${JSON.stringify(date)},${JSON.stringify(calendar)})`;}
export function decodePageResult(result){
 if(result.exceptionDetails){const name=result.exceptionDetails.exception?.className;const category=['SyntaxError','TypeError','ReferenceError','EvalError','SecurityError'].includes(name)?name:'ScriptError';throw Error('[WORKS_EVALUATION_FAILED] '+category+' · 브라우저가 화면 읽기 코드를 실행하지 못했습니다. 진단 영역 지정도 같은 오류가 나는지 확인해주세요.');}
 const value=result.result?.value;
 if(value?.readError){const code=Object.hasOwn(worksReadErrors,value.readError.code)?value.readError.code:'WORKS_SCRIPT_ERROR';throw Error('['+code+'] '+worksReadErrors[code]);}
 if(value?.diagnosticError)throw Error(value.diagnosticError);
 return value;
}
