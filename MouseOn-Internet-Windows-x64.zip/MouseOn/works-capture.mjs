// A deliberate click captures one visible appointment, never the whole account/calendar database.
export const captureExpression=`(()=>{
 if(location.hostname!=='calendar.worksmobile.com')throw Error('Calendar only');
 if(window.__mouseonCalendarCapture?.handler)return {ok:true};
 const state=window.__mouseonCalendarCapture||{items:[]};
 const banner=document.createElement('div');banner.id='mouseon-calendar-banner';
 Object.assign(banner.style,{position:'fixed',bottom:'16px',left:'50%',transform:'translateX(-50%)',zIndex:'2147483647',background:'#153f33',color:'#fff',padding:'14px 22px',borderRadius:'9px',font:'14px sans-serif'});
 banner.textContent='MouseOn 읽기 시험 · 가져올 일정 제목을 클릭하세요. 일정은 수정하지 않습니다. ';const exit=document.createElement('button');exit.textContent='선택 종료';banner.append(exit);document.body.append(banner);
 state.handler=e=>{
  if(banner.contains(e.target))return;
  if(e.target.closest('input,textarea,[contenteditable=true]'))return;
  e.preventDefault();e.stopImmediatePropagation();
  const leaf=(e.target.innerText||e.target.textContent||'').trim();
  if(!leaf||leaf.length>1200){banner.firstChild.textContent='일정 제목의 글자를 눌러주세요. ';return;}
  const candidate=e.composedPath().find(n=>n instanceof HTMLElement && /event|schedule|appointment/i.test(n.className||'') && n.innerText?.trim().length<=1200);
  const text=(candidate?.innerText||leaf).trim();
  if(state.items.length>=50){banner.firstChild.textContent='최대 50개까지 선택할 수 있습니다. ';return;}
  if(!state.items.some(x=>x.text===text))state.items.push({text});
  banner.firstChild.textContent=state.items.length+'개 선택됨 · 미리보기 화면에서 내용을 확인하세요. ';
 };
 exit.onclick=()=>{document.removeEventListener('click',state.handler,true);state.handler=null;banner.remove();};
 document.addEventListener('click',state.handler,true);window.__mouseonCalendarCapture=state;return {ok:true};
})()`;
