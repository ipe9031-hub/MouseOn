@echo off
cd /d "%~dp0"
"runtime\node.exe" launcher.mjs
pause
