import { createHash, randomBytes, timingSafeEqual } from 'node:crypto';

export function createAccess(password = '') {
  const sessions = new Map();
  let failures = [];
  const digest = value => createHash('sha256').update(value).digest();
  return {
    required: Boolean(password),
    allowed(req) {
      if (!password) return true;
      const token = (req.headers.cookie || '').split(';').map(s=>s.trim()).find(s=>s.startsWith('mouseon_session='))?.slice(16);
      const expires = sessions.get(token);
      if (!expires || expires < Date.now()) { sessions.delete(token); return false; }
      return true;
    },
    async login(req, res) {
      if (req.headers.origin && req.headers.origin !== `http://${req.headers.host}` && req.headers.origin !== `https://${req.headers.host}`) {
        res.writeHead(403); return res.end('{"error":"다른 사이트에서의 로그인 요청은 허용하지 않습니다."}');
      }
      failures = failures.filter(t => Date.now()-t < 60_000);
      if (failures.length >= 30) {res.writeHead(429,{'Retry-After':'60'});return res.end('{"error":"시도가 많습니다. 1분 뒤 다시 입력해주세요."}');}
      let body = '';
      for await (const chunk of req) {
        body += chunk;
        if (body.length > 2048) {res.writeHead(413);return res.end('{"error":"요청이 너무 큽니다."}');}
      }
      let input;
      try {input = JSON.parse(body).password;} catch {}
      if (password && (typeof input !== 'string' || !timingSafeEqual(digest(input),digest(password)))) {
        failures.push(Date.now());res.writeHead(401);return res.end('{"error":"회의 비밀번호가 맞지 않습니다."}');
      }
      const token = randomBytes(32).toString('hex');
      for (const [key,expires] of sessions) if (expires<Date.now()) sessions.delete(key);
      sessions.set(token,Date.now()+12*60*60*1000);
      const secure = req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : '';
      res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store','Set-Cookie':`mouseon_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=43200${secure}`});
      res.end('{"ok":true}');
    }
  };
}
