import { createHash, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';

export function createAccess(password = '', cookieName = 'mouseon_session') {
  const sessions = new Map();
  let failures = [];
  const digest = value => typeof password==='object' ? scryptSync(value,password.salt,32) : createHash('sha256').update(value).digest();
  const expected=typeof password==='object'?Buffer.from(password.hash,'hex'):digest(password);
  function grant(req,res,body={ok:true}){
    const token=randomBytes(32).toString('hex');
    for(const [key,expires] of sessions)if(expires<Date.now())sessions.delete(key);
    sessions.set(token,Date.now()+12*60*60*1000);
    const secure=req.headers['x-forwarded-proto']==='https'?'; Secure':'';
    res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store','Set-Cookie':`${cookieName}=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=43200${secure}`});res.end(JSON.stringify(body));
  }
  return {
    required: Boolean(password), grant,
    allowed(req) {
      if (!password) return true;
      const token = (req.headers.cookie || '').split(';').map(s=>s.trim()).find(s=>s.startsWith(cookieName+'='))?.slice(cookieName.length+1);
      const expires = sessions.get(token);
      if (!expires || expires < Date.now()) { sessions.delete(token); return false; }
      return true;
    },
    async login(req, res) {
      if (req.headers.origin && req.headers.origin !== `http://${req.headers.host}` && req.headers.origin !== `https://${req.headers.host}`) {
        res.writeHead(403); return res.end('{"error":"다른 사이트에서의 로그인 요청은 허용하지 않습니다."}');
      }
      failures = failures.filter(t => Date.now()-t < 60_000);
      if (failures.length >= 30) {res.writeHead(429,{'Retry-After':'60'});return res.end('{"error":"시도가 많습니다. 1분 뒤 다시 입력해주세요."}');}
      let body = '';
      for await (const chunk of req) {
        body += chunk;
        if (body.length > 2048) {res.writeHead(413);return res.end('{"error":"요청이 너무 큽니다."}');}
      }
      let input;
      try {input = JSON.parse(body).password;} catch {}
      if (password && (typeof input !== 'string' || !timingSafeEqual(digest(input),expected))) {
        failures.push(Date.now());res.writeHead(401);return res.end('{"error":"회의 비밀번호가 맞지 않습니다."}');
      }
      grant(req,res);
    }
  };
}
