import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {captureExpression} from './works-capture.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const key=randomBytes(24).toString('hex');
let browser,cdp,starting=false;
class CDP{
 constructor(url){this.ws=new WebSocket(url);this.pending=new Map();this.counter=0;this.ready=new Promise((resolve,reject)=>{this.ws.onopen=resolve;this.ws.onerror=()=>reject(Error('브라우저 연결 실패'));});this.ws.onmessage=e=>{const m=JSON.parse(e.data);const p=this.pending.get(m.id);if(p){clearTimeout(p.timer);this.pending.delete(m.id);m.error?p.reject(Error('브라우저 읽기 실패')):p.resolve(m.result);}};this.ws.onclose=()=>{for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(Error('연동용 브라우저가 닫혔습니다.'));}this.pending.clear();};}
 async call(method,params={}){await this.ready;return new Promise((resolve,reject)=>{const id=++this.counter,timer=setTimeout(()=>{this.pending.delete(id);reject(Error('브라우저 응답 대기 시간 초과'));},10000);this.pending.set(id,{resolve,reject,timer});this.ws.send(JSON.stringify({id,method,params}));});}
 close(){this.ws.close();}
}
async function launch(kind){
 if(starting||cdp)throw Error('이미 연동용 브라우저가 실행 중입니다. 그 창에서 로그인해주세요.');starting=true;
 try{
  const candidates=kind==='edge'?[path.join(process.env['PROGRAMFILES(X86)']||'','Microsoft/Edge/Application/msedge.exe'),path.join(process.env.PROGRAMFILES||'','Microsoft/Edge/Application/msedge.exe'),path.join(process.env.LOCALAPPDATA||'','Microsoft/Edge/Application/msedge.exe')]:[path.join(process.env.PROGRAMFILES||'','Google/Chrome/Application/chrome.exe'),path.join(process.env['PROGRAMFILES(X86)']||'','Google/Chrome/Application/chrome.exe'),path.join(process.env.LOCALAPPDATA||'','Google/Chrome/Application/chrome.exe')];
  const executable=process.env.WORKS_BROWSER_PATH||candidates.find(p=>fs.existsSync(p));if(!executable)throw Error('선택한 브라우저를 찾지 못했습니다. 크롬 또는 엣지 설치를 확인해주세요.');
  const profile=path.join(root,'data','works-sessions',randomBytes(8).toString('hex'));fs.mkdirSync(profile,{recursive:true});
  browser=spawn(executable,[`--user-data-dir=${profile}`,'--remote-debugging-port=0','--remote-debugging-address=127.0.0.1','--no-first-run','--no-default-browser-check',...(process.env.WORKS_HEADLESS==='1'?['--headless','--no-sandbox']:[]),'https://calendar.worksmobile.com/'],{stdio:'ignore'});
  let launchError=false;browser.on('error',()=>launchError=true);
  const portFile=path.join(profile,'DevToolsActivePort');for(let i=0;i<100&&!fs.existsSync(portFile)&&!launchError;i++)await new Promise(r=>setTimeout(r,150));
  if(!fs.existsSync(portFile)){browser.kill();throw Error('연동용 브라우저가 시작되지 않았습니다. 회사 보안 정책 또는 브라우저 설치를 확인해주세요.');}
  const port=Number(fs.readFileSync(portFile,'utf8').split('\n')[0]);const info=await(await fetch(`http://127.0.0.1:${port}/json/version`)).json();cdp=new CDP(info.webSocketDebuggerUrl);await cdp.ready;
  return {ok:true,message:'별도 브라우저에서 직접 로그인하고 우리 현장 캘린더와 날짜를 선택해주세요.'};
 }catch(error){cdp?.close();cdp=null;browser?.kill();throw error;}finally{starting=false;}
}
async function calendarSession(){
 if(!cdp)throw Error('연동용 브라우저를 먼저 여세요.');
 const {targetInfos}=await cdp.call('Target.getTargets');
 const targets=targetInfos.filter(t=>{try{return t.type==='page'&&new URL(t.url).hostname==='calendar.worksmobile.com';}catch{return false;}});
 if(targets.length!==1)throw Error('로그인 후 캘린더 탭 하나를 열어주세요. 로그인 페이지에서는 내용을 읽지 않습니다.');
 const {sessionId}=await cdp.call('Target.attachToTarget',{targetId:targets[0].targetId,flatten:true});
 return {async evaluate(expression){
  await cdp.ready;const id=++cdp.counter;
  const result=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{cdp.pending.delete(id);reject(Error('화면 읽기 대기 시간 초과'));},10000);cdp.pending.set(id,{resolve,reject,timer});cdp.ws.send(JSON.stringify({id,method:'Runtime.evaluate',params:{expression,returnByValue:true},sessionId}));});
  if(result.exceptionDetails)throw Error('화면 선택 도구를 실행하지 못했습니다.');return result.result.value;
 },async close(){await cdp.call('Target.detachFromTarget',{sessionId});}};
}
async function onPage(expression){const session=await calendarSession();try{return await session.evaluate(expression);}finally{await session.close();}}
const server=http.createServer(async(req,res)=>{
 res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');
 try{
  const url=new URL(req.url,'http://127.0.0.1');
  if(req.method==='GET'&&url.pathname==='/'){res.setHeader('Content-Type','text/html; charset=utf-8');return res.end(fs.readFileSync(path.join(root,'works-probe.html')));}
  if(req.headers['x-probe-key']!==key) {res.writeHead(403);return res.end('{}');}
  if(req.headers.origin&&req.headers.origin!==`http://127.0.0.1:${server.address().port}`){res.writeHead(403);return res.end('{}');}
  let body='';for await(const chunk of req){body+=chunk;if(body.length>4096){res.writeHead(413);return res.end('{}');}}
  let value={};if(body)value=JSON.parse(body);let result;
  if(req.method==='POST'&&url.pathname==='/open')result=await launch(value.browser==='edge'?'edge':'chrome');
  else if(req.method==='POST'&&url.pathname==='/select')result=await onPage(captureExpression);
  else if(req.method==='GET'&&url.pathname==='/preview')result=await onPage('window.__mouseonCalendarCapture?.items || []');
  else {res.writeHead(404);return res.end('{}');}
  res.setHeader('Content-Type','application/json');res.end(JSON.stringify(result));
 }catch(e){res.writeHead(400,{'Content-Type':'application/json'});res.end(JSON.stringify({error:e.message}));}
});
server.listen(0,'127.0.0.1',()=>{
 const url=`http://127.0.0.1:${server.address().port}/#key=${key}`;
 console.log('MouseOn calendar trial is ready. Keep this window open.');process.send?.({type:'ready',url,key});
 if(process.env.WORKS_NO_BROWSER!=='1'){
 const command=process.platform==='win32'?['cmd.exe',['/d','/c','start','',url]]:['xdg-open',[url]];
 const ui=spawn(...command,{stdio:'ignore'});ui.on('error',()=>console.error('Could not open the trial control screen.'));
 }
});
function stop(){cdp?.close();browser?.kill();server.close();}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
