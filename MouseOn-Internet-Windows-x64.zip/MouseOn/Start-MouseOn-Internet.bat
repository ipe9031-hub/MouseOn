@echo off
cd /d "%~dp0"
set "MOUSEON_INTERNET=1"
"runtime\node.exe" launcher.mjs
pause
