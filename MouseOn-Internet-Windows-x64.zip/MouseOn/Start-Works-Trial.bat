@echo off
cd /d "%~dp0"
"runtime\node.exe" works-probe.mjs
pause
