import http from 'node:http';
import { networkInterfaces } from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { randomBytes, scryptSync } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';
import QRCode from 'qrcode';
import { isTower } from './public/icons.js';
import { schedule, validDate } from './public/calendar.js';
import { createAccess } from './access.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const data = path.resolve(process.env.DATA_DIR || path.join(root, 'data'));
fs.mkdirSync(path.join(data, 'images'), { recursive: true });
const rooms = new Map();
const hostSetup=process.env.MOUSEON_HOST_SETUP==='1';
if(process.env.MOUSEON_INTERNET==='1' && !hostSetup && !process.env.MOUSEON_PASSWORD) throw new Error('Internet mode requires a meeting password.');
const access=createAccess(process.env.MOUSEON_PASSWORD);
const roomAccess=new Map();
function gate(id){
 if(!validId(id))return null;
 if(roomAccess.has(id))return roomAccess.get(id);
 const file=path.join(data,id+'.access.json');
 if(!fs.existsSync(file))return null;
 const value=createAccess(JSON.parse(fs.readFileSync(file)), 'mouseon_session_'+id);roomAccess.set(id,value);return value;
}
function requestGate(req,url){
 const id=url.searchParams.get('room') || url.pathname.match(/^\/api\/rooms\/([a-f0-9]{12})/)?.[1];
 return hostSetup?gate(id):access;
}
let tunnel={status:process.env.MOUSEON_INTERNET==='1'?'starting':'local',url:null,message:''};
process.on('message',m=>{if(m?.type==='tunnel')tunnel=m.state;});
const validId = id => /^[a-f0-9]{12}$/.test(id || '');
function getRoom(id) {
  if (!validId(id)) return null;
  if (rooms.has(id)) return rooms.get(id);
  const file = path.join(data, id + '.json');
  if (!fs.existsSync(file)) return null;
  const room = JSON.parse(fs.readFileSync(file)); rooms.set(id, room); return room;
}
function save(room) {
  const file = path.join(data, room.id + '.json');
  fs.writeFileSync(file + '.tmp', JSON.stringify(room)); fs.renameSync(file + '.tmp', file);
}
function createRoom() {
  const room = { id: randomBytes(6).toString('hex'), revision: 0, image: null, topImage: null, strokes: [], tasks: [
    { id: 't1', title: '101동 철근 인양', detail: '09:00 · 101동 북측 · 시공팀', equipment: '크레인 1호', icon: '🏗️', x: .30, y: .32 },
    { id: 't2', title: '103동 자재 인양', detail: '11:00 · 103동 · 시공팀', equipment: '크레인 1호', icon: '🏗️', x: .70, y: .34 },
    { id: 't3', title: '야적장 정리', detail: '14:00 · 자재 야적장 · 시공팀', equipment: '크레인 1호', icon: '🏗️', x: .74, y: .75 },
    { id: 't4', title: '102동 콘크리트 타설', detail: '10:00 · 102동 · 골조팀', equipment: '펌프카 1호', icon: '🚧', x: .30, y: .70 }
  ] };
  room.tasks.forEach((task,i)=>task.date=schedule().dates[i%schedule().dates.length]);
  rooms.set(room.id, room); save(room); return room;
}
const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control':'no-store' }); res.end(JSON.stringify(obj)); };
function imageExt(b) {
  if (b.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return 'png';
  if (b[0] === 255 && b[1] === 216 && b[2] === 255) return 'jpg';
  if (b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  return null;
}
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if(req.method==='GET' && url.pathname==='/api/access') return json(res,200,{hostSetup,passwordRequired:hostSetup||access.required,authenticated:hostSetup?Boolean(requestGate(req,url)?.allowed(req)):access.allowed(req)});
    if(req.method==='POST' && url.pathname==='/api/login') {
 const selected=requestGate(req,url);if(!selected)return json(res,404,{error:'회의를 찾을 수 없습니다. 새 회의를 만들어주세요.'});return selected.login(req,res);
 }
 if(hostSetup && req.method==='POST' && url.pathname==='/api/rooms'){
  if(!process.env.MOUSEON_HOST_TOKEN || req.headers['x-mouseon-host']!==process.env.MOUSEON_HOST_TOKEN)return json(res,403,{error:'PC의 실행 파일로 열린 주최자 화면에서 회의를 생성해주세요.'});
  let body='';for await(const chunk of req){body+=chunk;if(body.length>2048)return json(res,413,{error:'요청이 너무 큽니다.'});}
  let password;try{password=JSON.parse(body).password;}catch{}
  if(typeof password!=='string'||password.length<4||password.length>128)return json(res,400,{error:'비밀번호를 4~128자로 정해주세요.'});
  const salt=randomBytes(16).toString('hex'), secret={salt,hash:scryptSync(password,salt,32).toString('hex')};
  const room=createRoom();fs.writeFileSync(path.join(data,room.id+'.access.json'),JSON.stringify(secret),{mode:0o600});
  const selected=gate(room.id);return selected.grant(req,res,room);
 }
    if((url.pathname.startsWith('/api/') || url.pathname.startsWith('/images/')) && !(hostSetup && url.pathname==='/api/network' && req.headers['x-mouseon-host']===process.env.MOUSEON_HOST_TOKEN) && !requestGate(req,url)?.allowed(req)) return json(res,401,{error:'회의 비밀번호를 입력하고 참여해주세요.'});
    if(req.method==='POST' && req.headers.origin && ![`http://${req.headers.host}`,`https://${req.headers.host}`].includes(req.headers.origin))return json(res,403,{error:'허용되지 않은 요청입니다.'});
    if (req.method === 'GET' && url.pathname === '/api/network') {
      const port=server.address().port;
      const addresses=[...new Set(Object.values(networkInterfaces()).flat().filter(n=>n && n.family==='IPv4' && !n.internal && /^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/.test(n.address)).map(n=>'http://'+n.address+':'+port))];
      return json(res,200,{addresses, tunnel});
    }
    if (req.method === 'POST' && url.pathname === '/api/rooms') return json(res, 201, createRoom());
    if (req.method === 'GET' && url.pathname === '/api/qr') {
      const value = url.searchParams.get('url') || '';
      if (value.length > 2048 || !/^https?:\/\//.test(value)) return json(res, 400, { error: '잘못된 참여 주소입니다.' });
      res.writeHead(200, { 'Content-Type': 'image/png' }); return res.end(await QRCode.toBuffer(value, { width: 240, margin: 1 }));
    }
    const upload = url.pathname.match(/^\/api\/rooms\/([a-f0-9]{12})\/image$/);
    if (req.method === 'POST' && upload) {
      const room = getRoom(upload[1]); if (!room) return json(res, 404, { error: '회의를 찾을 수 없습니다.' });
      if (!['top','photo'].includes(url.searchParams.get('kind'))) return json(res, 400, {error:'이미지 종류가 잘못되었습니다.'});
      const chunks = []; let size = 0;
      for await (const chunk of req) {
        size += chunk.length;
        if (size > 50 * 1024 * 1024) { req.resume(); return json(res, 413, {error:'사진은 50MB까지 올릴 수 있습니다.'}); }
        chunks.push(chunk);
      }
      const buffer = Buffer.concat(chunks), ext = imageExt(buffer);
      if (!ext) return json(res, 415, {error:'JPG, PNG, WebP 사진만 지원합니다.'});
      const name = randomBytes(16).toString('hex') + '.' + ext;
      fs.writeFileSync(path.join(data, 'images', name), buffer);
      const image = '/images/' + name + (hostSetup?'?room='+room.id:'');
      if (url.searchParams.get('kind') === 'top') room.topImage = image;
      room.image = image; room.strokes = []; room.revision++; save(room);
      broadcast(room.id, {type:'state', room, notice: url.searchParams.get('kind') === 'top' ? '새 탑뷰가 표시되었습니다.' : '문제 사진이 표시되었습니다.'});
      return json(res, 200, {image});
    }
    if (req.method !== 'GET') return json(res, 405, {error:'지원하지 않는 요청입니다.'});
    let file;
    if (/^\/images\/[a-f0-9]{32}\.(png|jpg|webp)$/.test(url.pathname)) file = path.join(data, url.pathname);
    else if (['/','/app.js','/style.css','/sample.svg','/calendar.js','/icons.js'].includes(url.pathname)) file = path.join(root,'public',url.pathname === '/' ? 'index.html' : url.pathname);
    if (!file || !fs.existsSync(file)) return json(res,404,{error:'찾을 수 없습니다.'});
    const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp'};
    res.writeHead(200, {'Content-Type':types[path.extname(file)], 'X-Content-Type-Options':'nosniff', 'Cache-Control':'no-cache'});
    fs.createReadStream(file).pipe(res);
  } catch (err) { console.error(err.message); if (!res.headersSent) json(res,500,{error:'요청 처리 중 오류가 발생했습니다.'}); else res.end(); }
});
const wss = new WebSocketServer({server, maxPayload: 64 * 1024});
function broadcast(id, message, except) {
  const value = JSON.stringify(message);
  for (const client of wss.clients) if (client.roomId === id && client !== except && client.readyState === WebSocket.OPEN) client.send(value);
}
const coord = v => typeof v === 'number' && Number.isFinite(v) && v >= 0 && v <= 1;
wss.on('connection', (ws, req) => {
  if(!(hostSetup?gate(new URL(req.url,'http://localhost').searchParams.get('room')):access)?.allowed(req)){ws.close(1008,'회의 비밀번호를 입력해주세요.');return;}
  if(req.headers.origin && ![`http://${req.headers.host}`,`https://${req.headers.host}`].includes(req.headers.origin)){ws.close(1008,'허용되지 않은 요청입니다.');return;}
  const url = new URL(req.url,'http://localhost'), room = getRoom(url.searchParams.get('room'));
  if (!room) { ws.close(1008,'회의를 찾을 수 없습니다.'); return; }
  ws.roomId = room.id; ws.person = (url.searchParams.get('name') || '참여자').slice(0,30); ws.peer = randomBytes(6).toString('hex');
  ws.send(JSON.stringify({type:'state',room}));
  const count = () => broadcast(room.id,{type:'presence',count:[...wss.clients].filter(c=>c.roomId===room.id && c.readyState===WebSocket.OPEN).length});
  count(); ws.on('close',count);
  ws.on('message', raw => {
    try {
      if(!(hostSetup?gate(new URL(req.url,'http://localhost').searchParams.get('room')):access)?.allowed(req)){ws.close(1008,'참여 인증이 만료되었습니다.');return;}
      const m = JSON.parse(raw);
      if (m.type === 'pointer' && coord(m.x) && coord(m.y)) return broadcast(room.id,{type:'pointer',x:m.x,y:m.y,person:ws.person,peer:ws.peer},ws);
      if (m.type === 'stroke') {
        if (m.image !== room.image) return;
        if (!Array.isArray(m.points) || m.points.length < 1 || m.points.length > 100 || !m.points.every(p=>Array.isArray(p)&&p.length===2&&p.every(coord))) return;
        if (room.strokes.length >= 3000) return ws.send(JSON.stringify({type:'error',message:'그림이 많습니다. 그림을 지운 뒤 다시 그려주세요.'}));
        const stroke = {points:m.points,color:'#ff6847'}; room.strokes.push(stroke); save(room);
        return broadcast(room.id,{type:'stroke',stroke,image:room.image},ws);
      }
      let notice;
      if(m.type==='addTask'){
        if(room.tasks.length>=200)return ws.send(JSON.stringify({type:'error',message:'한 회의에 작업은 200개까지 등록할 수 있습니다.'}));
        const t=m.task;
        if(!t||typeof t.title!=='string'||!t.title.trim()||t.title.length>80||!validDate(t.date)||!coord(t.x)||!coord(t.y)||typeof t.equipment!=='string'||t.equipment.length>50||typeof t.detail!=='string'||t.detail.length>180||!['🏗️','🚧','🚜','🚛','📦','🦺','tower','mobile','concrete','mixer','dump','excavator','forklift','other'].includes(t.icon))return ws.send(JSON.stringify({type:'error',message:'작업 이름·날짜·위치를 확인해주세요.'}));
        if(!['point','area','route'].includes(t.shape)||!Array.isArray(t.points)||t.points.length>100||!t.points.every(p=>Array.isArray(p)&&p.length===2&&p.every(coord))||(t.shape==='area'&&t.points.length<3)||(t.shape==='route'&&t.points.length<2))return ws.send(JSON.stringify({type:'error',message:'영역은 3점 이상, 동선은 2점 이상 지정해주세요.'}));
        room.tasks.push({id:randomBytes(6).toString('hex'),title:t.title.trim(),detail:t.detail,equipment:t.equipment.trim()||'기타 작업',icon:t.icon,date:t.date,x:t.x,y:t.y,shape:t.shape,points:t.points});
        notice=`${ws.person}님이 작업을 등록했습니다.`;
      } else if(m.type==='deleteTask'){
        const index=room.tasks.findIndex(t=>t.id===m.id);if(index<0)return;
        room.tasks.splice(index,1);notice=`${ws.person}님이 작업을 삭제했습니다.`;
      } else if (m.type === 'move' && coord(m.x) && coord(m.y)) {
        const task = room.tasks.find(t=>t.id===m.id); if (!task || room.image !== room.topImage) return;
        task.x=m.x; task.y=m.y; notice=`${ws.person}님이 작업 위치를 옮겼습니다.`;
      } else if (m.type === 'reorder') {
        if (m.revision !== room.revision) return ws.send(JSON.stringify({type:'state',room,notice:'다른 변경이 먼저 반영되었습니다. 최신 목록에서 다시 변경해주세요.'}));
        const task = room.tasks.find(t=>t.id===m.id); if (!task || isTower(task) || ![-1,1].includes(m.direction)) return;
        const indexes = room.tasks.map((t,i)=>t.equipment===task.equipment?i:-1).filter(i=>i>=0);
        const pos = indexes.indexOf(room.tasks.indexOf(task)), other = indexes[pos+m.direction]; if (other===undefined) return;
        const current = indexes[pos]; [room.tasks[current],room.tasks[other]]=[room.tasks[other],room.tasks[current]];
        notice=`${ws.person}님이 ${task.equipment} 작업 순서를 변경했습니다.`;
      } else if (m.type === 'clear') { room.strokes=[]; notice=`${ws.person}님이 그림을 지웠습니다.`;
      } else if (m.type === 'top') { room.image=room.topImage; room.strokes=[]; notice='현장 탑뷰로 돌아왔습니다.';
      } else return;
      room.revision++; save(room); broadcast(room.id,{type:'state',room,notice});
    } catch { ws.send(JSON.stringify({type:'error',message:'변경을 처리하지 못했습니다.'})); }
  });
});
server.on('error', error => { console.error(error.code==='EADDRINUSE' ? 'Port already in use. Close the other MouseOn window and try again.' : error.message); wss.close(); process.exitCode=1; });
server.listen(Number(process.env.PORT || 3000), '0.0.0.0', () => { console.log('MouseOn server listening on port ' + server.address().port);process.send?.({type:'ready',port:server.address().port}); });
