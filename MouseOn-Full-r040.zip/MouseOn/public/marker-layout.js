import {limitWorkMove} from './work-area.js';
import {inside,insideRegion} from './interpret.js';
const overlap=(a,b)=>Math.max(0,Math.min(a.right,b.right)-Math.max(a.left,b.left))*Math.max(0,Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
// Visual spacing only: stored work coordinates and region assignments never change.
export function arrangeTaskMarkers(scene,viewport,tasks,site={}){
 const bounds=scene.getBoundingClientRect(),view=viewport.getBoundingClientRect();if(!bounds.width||!bounds.height)return;
 const byId=new Map(tasks.map(t=>[t.id,t])),nodes=[...scene.querySelectorAll('.marker')].sort((a,b)=>a.dataset.id.localeCompare(b.dataset.id)),blocks=[];
 for(const node of nodes){
  const task=byId.get(node.dataset.id);if(!task||!Number.isFinite(task.x)||!Number.isFinite(task.y))continue;
  if(node.classList.contains('area-marker')){blocks.push(node.getBoundingClientRect());continue;}
  node.style.left=task.x*100+'%';node.style.top=task.y*100+'%';
  const rect=node.getBoundingClientRect(),w=rect.width,h=rect.height,scale=w/Math.max(1,node.offsetWidth),attention=node.querySelector('.attention'),margin=attention?9*scale:0;
  const x=bounds.left+task.x*bounds.width,y=bounds.top+task.y*bounds.height,region=(site.regions||[]).find(r=>r.id===task.regionId);
  const anchorVisible=x>=view.left&&x<=view.right&&y>=view.top&&y<=view.bottom;
  const candidates=[];
  for(const radius of [0,12,24,40,64,96,144,216,300])for(let n=0;n<(radius?24:1);n++){
   const angle=n*Math.PI/12,px=x+radius*Math.cos(angle),py=y+radius*Math.sin(angle),point=[(px-bounds.left)/bounds.width,(py-bounds.top)/bounds.height];
   if(point.some(v=>v<0||v>1))continue;
   if(region&&task.manuallyPlaced){const q=limitWorkMove(task,point,site.regions,{width:bounds.width,height:bounds.height});if(Math.hypot((q[0]-point[0])*bounds.width,(q[1]-point[1])*bounds.height)>.1)continue;}else if(region&&task.placement==='inside'&&!insideRegion(point,region))continue;
   if(region&&task.placement==='surrounding'&&insideRegion(point,region))continue;
   if(!task.manuallyPlaced&&site.outline?.length&&inside([task.x,task.y],site.outline)&&!inside(point,site.outline))continue;
   const box={left:px-w/2-margin,top:py-h/2-margin,right:px+w/2,bottom:py+h/2};
   let score=radius;
   if(anchorVisible&&(box.left<view.left+3||box.right>view.right-3||box.top<view.top+3||box.bottom>view.bottom-3))score+=1e6;
   for(const b of blocks)score+=overlap(box,{left:b.left-6,top:b.top-6,right:b.right+6,bottom:b.bottom+6})*10000;
   candidates.push({point,box,score});
  }
  candidates.sort((a,b)=>a.score-b.score);const best=candidates[0];
  if(best){node.style.left=best.point[0]*100+'%';node.style.top=best.point[1]*100+'%';blocks.push(best.box);}else blocks.push(rect);
 }
}
