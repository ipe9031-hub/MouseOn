import {regionPieces,regionArea,withPieces} from './region-geometry.js';
import './vendor/polygon-clipping.js';
import {polygonArea,conformRegions,validMesh} from './region-mesh.js';
import {inside,insideRegion,regionPoint} from './interpret.js';
const clip=globalThis.polygonClipping;
export const defaultOutline=()=>[[0,0],[1,0],[1,1],[0,1]];
export function validateOutline(points){if(!Array.isArray(points)||points.length<3||points.length>160||!validMesh([{points}]))throw Error('외곽선을 3점 이상 찍고 교차하지 않도록 지정해주세요.');return points;}
function halfPlane(points,a,b){const nx=b[0]-a[0],ny=b[1]-a[1],limit=(b[0]*b[0]+b[1]*b[1]-a[0]*a[0]-a[1]*a[1])/2;const out=[];for(let i=0;i<points.length;i++){const p=points[i],q=points[(i+1)%points.length],u=nx*p[0]+ny*p[1]-limit,v=nx*q[0]+ny*q[1]-limit;if(u<=1e-12)out.push(p);if((u<0&&v>0)||(u>0&&v<0)){const t=u/(u-v);out.push([p[0]+(q[0]-p[0])*t,p[1]+(q[1]-p[1])*t]);}}return out;}
export function partitionSite(outline,regions){
 validateOutline(outline);const fixed=regions.filter(r=>r.fixed),free=regions.filter(r=>!r.fixed),seeds=free.map(r=>r.seed||regionPoint(r));
 const occupied=fixed.flatMap(regionPieces);
 const next=free.map((r,i)=>{let cell=[[-2,-2],[3,-2],[3,3],[-2,3]];for(let j=0;j<seeds.length;j++)if(i!==j){if(Math.hypot(seeds[i][0]-seeds[j][0],seeds[i][1]-seeds[j][1])<1e-6)throw Error('영역의 중심이 너무 가깝습니다. 다른 위치에 추가해주세요.');cell=halfPlane(cell,seeds[i],seeds[j]);}
  if(cell.length<3)throw Error('새 영역을 만들 공간이 부족합니다.');let result=clip.intersection([outline],[cell]);if(occupied.length)result=clip.difference(result,occupied);if(!result.length)throw Error('새 영역을 만들 공간이 부족합니다.');return withPieces({...r,seed:seeds[i]},result);});
 const ordered=regions.map(r=>r.fixed?r:next.find(n=>n.id===r.id));const conformed=conformRegions(ordered);if(!validMesh(conformed))throw Error('영역이 너무 작아 나눌 수 없습니다.');return conformed;
}
export function insertManualRegion(outline,regions,points,id){
 if(regions.length>=100)throw Error('영역은 최대 100개입니다.');
 validateOutline(points);validateOutline(outline);
 const footprint=clip.intersection([points],[outline]);if(!footprint.length)throw Error('현장 외곽선 안에 걸치는 영역을 그려주세요.');
 // The completed shape owns overlapping space; retain the remaining pieces of its neighbors.
 const next=[];for(const r of regions){const difference=clip.difference(regionPieces(r),footprint);if(difference.length){const cut=withPieces(r,difference);cut.seed=regionPoint(cut);next.push(cut);}}
 const added=withPieces({id,name:'',aliases:[],fixed:true},footprint);added.seed=regionPoint(added);next.push(added);const result=conformRegions(next);if(!validMesh(result))throw Error('경계가 너무 좁거나 교차합니다. 점을 다시 조정해주세요.');return result;
}

export function addSiteRegion(outline,regions,id){
 validateOutline(outline);if(regions.length>=100)throw Error('영역은 최대 100개입니다.');
 if(!regions.length)return [{id,name:'',aliases:[],seed:regionPoint({points:outline}),points:structuredClone(outline)}];
 if(regions.every(r=>r.fixed)){const free=clip.difference([outline],regions.flatMap(regionPieces));if(!free.length)throw Error('빈 영역이 없습니다.');const region=withPieces({id,name:'',aliases:[],fixed:false},free);region.seed=regionPoint(region);return conformRegions([...regions,region]);}
 const largestCell=[...regions].filter(r=>!r.fixed).sort((a,b)=>regionArea(b)-regionArea(a))[0],boxX=largestCell.points.map(p=>p[0]),boxY=largestCell.points.map(p=>p[1]),cx=(Math.min(...boxX)+Math.max(...boxX))/2,cy=(Math.min(...boxY)+Math.max(...boxY))/2;
 for(const axis of [(Math.max(...boxX)-Math.min(...boxX))>=(Math.max(...boxY)-Math.min(...boxY))?0:1,1,0]){
  const delta=axis===0?(Math.max(...boxX)-Math.min(...boxX))/4:(Math.max(...boxY)-Math.min(...boxY))/4,a=[cx,cy],b=[cx,cy];a[axis]-=delta;b[axis]+=delta;
  if(insideRegion(a,largestCell)&&insideRegion(b,largestCell))try{return partitionSite(outline,[...regions.map(r=>r.id===largestCell.id?{...r,seed:a}:r),{id,name:'',aliases:[],seed:b,points:outline}]);}catch{}
 }
 const seeds=regions.map(r=>r.seed||regionPoint(r)),xs=outline.map(p=>p[0]),ys=outline.map(p=>p[1]),candidates=[];
 for(let y=1;y<24;y++)for(let x=1;x<24;x++){const p=[Math.min(...xs)+(Math.max(...xs)-Math.min(...xs))*x/24,Math.min(...ys)+(Math.max(...ys)-Math.min(...ys))*y/24];if(inside(p,outline)&&!regions.some(r=>r.fixed&&insideRegion(p,r)))candidates.push({p,score:Math.min(...seeds.map(s=>Math.hypot(s[0]-p[0],s[1]-p[1]))) });}
 // Choose inside the largest cell near its center; alternative candidates avoid disconnected concave cells.
 const largest=largestCell,center=regionPoint(largest);
 candidates.sort((a,b)=>{const score=c=>c.score*(insideRegion(c.p,largest)?1.4:1)-Math.hypot(c.p[0]-center[0],c.p[1]-center[1])*.15;return score(b)-score(a);});
 for(const {p}of candidates.slice(0,100))try{return partitionSite(outline,[...regions,{id,name:'',aliases:[],seed:p,points:outline}]);}catch{}
 throw Error('이 외곽선에서는 새 영역을 자동으로 나누지 못했습니다. 외곽선을 단순하게 조정하거나 경계를 직접 편집해주세요.');
}
export function withinOutline(regions,outline){if(!outline?.length||!regions.length)return true;const outside=clip.difference(regions.flatMap(regionPieces),[outline]);return outside.reduce((sum,p)=>sum+Math.abs(polygonArea(p[0])),0)<1e-7;}
// Project outside points onto the closest outline segment, including concave boundaries.
export function snapToOutline(outline,point,tolerance=0){
 if(!outline?.length)return [...point];let nearest=null,distance=Infinity;
 for(let i=0;i<outline.length;i++){const a=outline[i],b=outline[(i+1)%outline.length],dx=b[0]-a[0],dy=b[1]-a[1],length=dx*dx+dy*dy;if(length<1e-16)continue;const t=Math.max(0,Math.min(1,((point[0]-a[0])*dx+(point[1]-a[1])*dy)/length)),p=[a[0]+t*dx,a[1]+t*dy],d=Math.hypot(point[0]-p[0],point[1]-p[1]);if(d<distance){distance=d;nearest=p;}}
 return nearest&&(!inside(point,outline)||distance<=tolerance)?nearest:[...point];
}
export function constrainToOutline(outline,changes){if(!outline?.length)return changes;return changes.map(({from,to})=>{
 if(outline.some(p=>Math.hypot(p[0]-from[0],p[1]-from[1])<1e-8))return {from,to:[...from]};
 for(let i=0;i<outline.length;i++){const a=outline[i],b=outline[(i+1)%outline.length],dx=b[0]-a[0],dy=b[1]-a[1],d=dx*dx+dy*dy;if(d<1e-16)continue;const t=((from[0]-a[0])*dx+(from[1]-a[1])*dy)/d;if(t>=0&&t<=1&&Math.hypot(from[0]-a[0]-t*dx,from[1]-a[1]-t*dy)<1e-8){const u=Math.max(0,Math.min(1,((to[0]-a[0])*dx+(to[1]-a[1])*dy)/d));return {from,to:[a[0]+u*dx,a[1]+u*dy]};}}
 return {from,to:snapToOutline(outline,to,.008)};
 });}

// Edit one shape independently of outline vertices, then redistribute its released space.
export function reshapeSiteRegion(outline,regions,id,shape){
 const old=regions.find(r=>r.id===id);if(!old)throw Error('영역을 먼저 선택해주세요.');
 const footprint=clip.intersection(regionPieces(shape),[outline]);if(!footprint.length)throw Error('영역이 현장 안에 남아 있어야 합니다.');
 const edited=conformRegions([withPieces({...old,fixed:old.fixed},footprint),shape])[0];if(!validMesh([edited]))throw Error('영역이 너무 작거나 경계가 올바르지 않습니다.');edited.seed=regionPoint(edited);
 const released=clip.difference(regionPieces(old),footprint),others=regions.filter(r=>r.id!==id).map(r=>structuredClone(r));
 for(const piece of released){if(!others.length)break;const center=regionPoint(withPieces({},[piece]));const target=[...others].sort((a,b)=>{const distance=r=>{const p=regionPoint(r);return Math.hypot(p[0]-center[0],p[1]-center[1]);};return distance(a)-distance(b);})[0];Object.assign(target,withPieces(target,clip.union(regionPieces(target),[piece])));}
 const result=[];for(const r of regions){if(r.id===id){result.push(edited);continue;}const other=others.find(o=>o.id===r.id),rest=clip.difference(regionPieces(other),footprint);if(rest.length){const cut=withPieces(other,rest);cut.seed=regionPoint(cut);result.push(cut);}}
 const conformed=conformRegions(result);if(!validMesh(conformed))throw Error('경계가 너무 좁습니다. 점을 조금 옮겨주세요.');return conformed;
}
