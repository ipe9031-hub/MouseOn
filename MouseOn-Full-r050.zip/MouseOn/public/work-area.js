// Manual icon movement is independent of building footprints and work areas.
// Keep the public signature for older clients; only photo bounds constrain the point.
export function limitWorkMove(task,point,regions,frame){return point.map(value=>Math.max(0,Math.min(1,value)));}

// Build physical footprints in image pixels so circles stay round on non-square photos.
export function workAreaPoints(shape,start,end,frame){
 const w=Math.max(1,frame.width),h=Math.max(1,frame.height),[x,y]=start,[u,v]=end;
 if(shape==='rectangle')return [[Math.min(x,u),Math.min(y,v)],[Math.max(x,u),Math.min(y,v)],[Math.max(x,u),Math.max(y,v)],[Math.min(x,u),Math.max(y,v)]];
 const dx=(u-x)*w,dy=(v-y)*h,angle=Math.atan2(dy,dx),radius=Math.hypot(dx,dy);
 let pixels;
 if(shape==='circle')pixels=Array.from({length:64},(_,i)=>{const a=i*Math.PI/32;return [radius*Math.cos(a),radius*Math.sin(a)];});
 else if(shape==='sector')pixels=[[0,0],...Array.from({length:33},(_,i)=>{const a=angle-Math.PI/6+i*Math.PI/96;return [radius*Math.cos(a),radius*Math.sin(a)];})];
 else if(shape==='arrow'){
  const half=radius*.08,head=radius*.25,wide=radius*.2;
  pixels=[[0,-half],[radius-head,-half],[radius-head,-wide],[radius,0],[radius-head,wide],[radius-head,half],[0,half]].map(([a,b])=>[a*Math.cos(angle)-b*Math.sin(angle),a*Math.sin(angle)+b*Math.cos(angle)]);
 }else return [];
 // Shrink uniformly at image edges instead of flattening curved footprints.
 let scale=1;for(const [a,b] of pixels){if(a>0)scale=Math.min(scale,(1-x)*w/a);if(a<0)scale=Math.min(scale,-x*w/a);if(b>0)scale=Math.min(scale,(1-y)*h/b);if(b<0)scale=Math.min(scale,-y*h/b);}
 return pixels.map(([a,b])=>[Math.max(0,Math.min(1,x+a*scale/w)),Math.max(0,Math.min(1,y+b*scale/h))]);
}
