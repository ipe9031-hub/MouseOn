-- MouseOn sharing, scoped to the signed-in user's workspace. Does not replace existing tables.
-- Safe to rerun: refreshes only MouseOn policies inside this transaction; preserves stored data.
begin;
create table if not exists public.mouseon_shared_sites (
 owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
 id uuid not null,
 name text not null check (length(name) between 1 and 80),
 revision bigint not null default 1 check (revision > 0),
 snapshot jsonb not null check (coalesce(snapshot->>'format','') = 'mouseon-share/v1' and octet_length(snapshot::text) <= 4194304),
 updated_at timestamptz not null default now(),
 primary key (owner_id,id)
);
alter table public.mouseon_shared_sites enable row level security;
revoke all on public.mouseon_shared_sites from anon;
grant select, insert, update on public.mouseon_shared_sites to authenticated;
drop policy if exists mouseon_shared_sites_owner on public.mouseon_shared_sites;
create policy mouseon_shared_sites_owner on public.mouseon_shared_sites for all to authenticated using (owner_id=auth.uid()) with check (owner_id=auth.uid());
create or replace function public.mouseon_commit_site(p_id uuid,p_name text,p_expected_revision bigint,p_snapshot jsonb)
returns table(id uuid,name text,revision bigint,updated_at timestamptz)
language plpgsql security invoker set search_path=public,pg_temp as $$
begin
 if auth.uid() is null then raise exception 'authentication_required' using errcode='42501'; end if;
 if p_expected_revision=0 then
  return query insert into public.mouseon_shared_sites as s(owner_id,id,name,revision,snapshot) values(auth.uid(),p_id,p_name,1,p_snapshot) on conflict do nothing returning s.id,s.name,s.revision,s.updated_at;
 else
  return query update public.mouseon_shared_sites as s set name=p_name,revision=s.revision+1,snapshot=p_snapshot,updated_at=now() where s.owner_id=auth.uid() and s.id=p_id and s.revision=p_expected_revision returning s.id,s.name,s.revision,s.updated_at;
 end if;
 if not found then raise exception 'revision_conflict' using errcode='40001'; end if;
end; $$;
revoke all on function public.mouseon_commit_site(uuid,text,bigint,jsonb) from public,anon;
grant execute on function public.mouseon_commit_site(uuid,text,bigint,jsonb) to authenticated;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('mouseon-data','mouseon-data',false,52428800,array['image/png','image/jpeg','image/webp']) on conflict(id) do nothing;
do $$ begin if exists(select 1 from storage.buckets where id='mouseon-data' and public) then raise exception 'mouseon-data must be a private bucket'; end if; end; $$;
drop policy if exists mouseon_files_read on storage.objects;
create policy mouseon_files_read on storage.objects for select to authenticated using(bucket_id='mouseon-data' and (storage.foldername(name))[1]=(select auth.uid()::text));
drop policy if exists mouseon_files_insert on storage.objects;
create policy mouseon_files_insert on storage.objects for insert to authenticated with check(bucket_id='mouseon-data' and (storage.foldername(name))[1]=(select auth.uid()::text));
drop policy if exists mouseon_files_update on storage.objects;
create policy mouseon_files_update on storage.objects for update to authenticated using(bucket_id='mouseon-data' and (storage.foldername(name))[1]=(select auth.uid()::text)) with check(bucket_id='mouseon-data' and (storage.foldername(name))[1]=(select auth.uid()::text));
commit;
