import {regionPieces} from './region-geometry.js';
import {limitWorkMove} from './work-area.js';
import {inside,insideRegion,isBuildingRegion} from './interpret.js';
const placed=new WeakMap();
const overlap=(a,b)=>Math.max(0,Math.min(a.right,b.right)-Math.max(a.left,b.left))*Math.max(0,Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
// Visual spacing only: stored work coordinates and region assignments never change.
export function arrangeTaskMarkers(scene,viewport,tasks,site={}){
 const bounds=scene.getBoundingClientRect(),view=viewport.getBoundingClientRect();if(!bounds.width||!bounds.height)return;
 let cache=placed.get(scene);if(!cache){cache=new Map();placed.set(scene,cache);}
 const byId=new Map(tasks.map(t=>[t.id,t])),nodes=[...scene.querySelectorAll('.marker')].sort((a,b)=>a.dataset.id.localeCompare(b.dataset.id)),blocks=[];
 // Existing pins must occupy their saved slots before newly arrived IDs are arranged.
 const fixed=new Set();for(const node of nodes){const task=byId.get(node.dataset.id);if(!task||!Number.isFinite(task.x)||!Number.isFinite(task.y))continue;const key=JSON.stringify([task.x,task.y,task.manuallyPlaced,task.regionId,task.placement,scene.querySelector('img')?.getAttribute('src')]),saved=cache.get(task.id);if(task.manuallyPlaced||saved?.key===key){const point=task.manuallyPlaced?[task.x,task.y]:saved.point;node.style.left=point[0]*100+'%';node.style.top=point[1]*100+'%';cache.set(task.id,{key,point});fixed.add(task.id);blocks.push(node.getBoundingClientRect());}}

 for(const node of nodes){
  const task=byId.get(node.dataset.id);if(!task||!Number.isFinite(task.x)||!Number.isFinite(task.y)||fixed.has(task.id))continue;
  const key=JSON.stringify([task.x,task.y,task.manuallyPlaced,task.regionId,task.placement,scene.querySelector('img')?.getAttribute('src')]),saved=cache.get(task.id);
  if(saved?.key===key){node.style.left=saved.point[0]*100+'%';node.style.top=saved.point[1]*100+'%';blocks.push(node.getBoundingClientRect());continue;}
  if(task.manuallyPlaced){node.style.left=task.x*100+'%';node.style.top=task.y*100+'%';cache.set(task.id,{key,point:[task.x,task.y]});blocks.push(node.getBoundingClientRect());continue;}
  if(node.classList.contains('area-marker')){blocks.push(node.getBoundingClientRect());continue;}
  node.style.left=task.x*100+'%';node.style.top=task.y*100+'%';
  const rect=node.getBoundingClientRect(),w=rect.width,h=rect.height,scale=w/Math.max(1,node.offsetWidth),attention=node.querySelector('.attention'),margin=attention?9*scale:0;
  const x=bounds.left+task.x*bounds.width,y=bounds.top+task.y*bounds.height,region=(site.regions||[]).find(r=>r.id===task.regionId);
  const anchorVisible=x>=view.left&&x<=view.right&&y>=view.top&&y<=view.bottom;
  const candidates=[],positions=[];
  for(const radius of [0,12,24,40,64,96,144,216,300])for(let n=0;n<(radius?24:1);n++){
   const angle=n*Math.PI/12,px=x+radius*Math.cos(angle),py=y+radius*Math.sin(angle),point=[(px-bounds.left)/bounds.width,(py-bounds.top)/bounds.height];
   positions.push({point,px,py,radius});
  }
  if(region&&task.placement==='equipment-ground'&&!task.manuallyPlaced)for(const polygon of regionPieces(region))for(const ring of polygon)for(let i=0;i<ring.length;i++){
   const a=ring[i],b=ring[(i+1)%ring.length],dx=(b[0]-a[0])*bounds.width,dy=(b[1]-a[1])*bounds.height,len=Math.hypot(dx,dy);if(!len)continue;
   for(const t of [.1,.25,.5,.75,.9])for(const side of [-1,1]){const gap=Math.max(w,h)/2+10,point=[a[0]+(b[0]-a[0])*t-side*dy/len*gap/bounds.width,a[1]+(b[1]-a[1])*t+side*dx/len*gap/bounds.height],px=bounds.left+point[0]*bounds.width,py=bounds.top+point[1]*bounds.height;positions.push({point,px,py,radius:Math.hypot(px-x,py-y)});}
  }
  for(const {point,px,py,radius} of positions){
   if(point.some(v=>v<0||v>1))continue;
   if(region&&task.manuallyPlaced){const q=limitWorkMove(task,point,site.regions,{width:bounds.width,height:bounds.height});if(Math.hypot((q[0]-point[0])*bounds.width,(q[1]-point[1])*bounds.height)>.1)continue;}else if(region&&task.placement==='inside'&&!insideRegion(point,region))continue;
   if(task.placement==='equipment-ground'&&!task.manuallyPlaced&&(site.regions||[]).filter(isBuildingRegion).some(r=>[[0,0],[-w/2,-h/2],[w/2,-h/2],[-w/2,h/2],[w/2,h/2]].some(([dx,dy])=>insideRegion([point[0]+dx/bounds.width,point[1]+dy/bounds.height],r))))continue;
   if(region&&task.placement==='surrounding'&&insideRegion(point,region))continue;
   if(!task.manuallyPlaced&&site.outline?.length&&inside([task.x,task.y],site.outline)&&!inside(point,site.outline))continue;
   const box={left:px-w/2-margin,top:py-h/2-margin,right:px+w/2,bottom:py+h/2};
   let score=radius;
   if((anchorVisible||task.placement==='equipment-ground')&&(box.left<view.left+3||box.right>view.right-3||box.top<view.top+3||box.bottom>view.bottom-3))score+=1e6;
   for(const control of scene.closest('#workspace')?.querySelectorAll('#titleNav,#menuToggle,#siteSettingsButton,#bulkDeleteButton,#photoInboxButton,#fullScreen')||[]){if(!control.hidden)score+=overlap(box,control.getBoundingClientRect())*10000;}
   for(const b of blocks)score+=overlap(box,{left:b.left-6,top:b.top-6,right:b.right+6,bottom:b.bottom+6})*10000;
   candidates.push({point,box,score});
  }
  candidates.sort((a,b)=>a.score-b.score);const best=candidates[0];
  if(best){cache.set(task.id,{key,point:best.point});node.style.left=best.point[0]*100+'%';node.style.top=best.point[1]*100+'%';blocks.push(best.box);}else blocks.push(rect);
 }
}
