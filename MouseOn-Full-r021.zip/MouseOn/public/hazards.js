export const defaultHazards=()=>[{id:'formwork',name:'갱폼 작업',icon:'formwork',color:'#c2410c'},{id:'rope',name:'로프 작업',icon:'rope',color:'#be185d'},{id:'general-risk',name:'기타 고위험 작업',icon:'hazard',color:'#9f1239'}];
export const hazardColors=['#9f1239','#a21caf','#c2410c','#0e7490','#7c3aed','#be185d'];
