const shapes={
 hazard:'<path d="M32 7 59 54H5Z"/><path d="M32 23v15"/><circle cx="32" cy="46" r="1"/>',
 formwork:'<path d="M8 17h31v37H8zM8 29h31M8 42h31M19 17v37M29 17v37M51 49V9m-7 7 7-7 7 7"/>',
 rope:'<path d="M8 7h48M28 7v13M35 30l-9 10 8 9-4 10M35 30l10 8 8-5M34 49l11 5M44 7v52"/><circle cx="34" cy="23" r="6"/>',
 tower:'<path d="M25 53V13h8v40M25 23l8 8-8 8 8 8M7 13h49L33 5 15 13M33 13v-8M49 13v23m-4 0h8v7h-8zM19 54h20"/>',
 mobile:'<path d="M7 44h40v9H7zM12 44V32h14v12M18 32l7-12 30-12 2 5-29 13M54 13v20m-4 0h8v5h-8z"/><circle cx="16" cy="53" r="5"/><circle cx="40" cy="53" r="5"/>',
 concrete:'<path d="M5 43h50v9H5zM9 43V29h13v14M28 29l5-11h16l7 11-6 14H33zM35 19l13 23M55 35v12h5"/><circle cx="14" cy="53" r="5"/><circle cx="44" cy="53" r="5"/>',
 mixer:'<path d="M4 43h51v9H4zM7 43V29h13v14M24 28l9-11 19 9-5 15-16 1zM34 20l12 18M52 37l7 8"/><circle cx="13" cy="53" r="5"/><circle cx="44" cy="53" r="5"/>',
 dump:'<path d="M5 43h50v9H5zM7 43V28h13v15M25 24h33l-5 17H29z"/><circle cx="13" cy="53" r="5"/><circle cx="43" cy="53" r="5"/>',
 excavator:'<path d="M9 44h32l5 8H5zM13 44V27h16v17M29 30l10-17 13 9 5 18-7 3-3-18-5-4-7 14M50 43h11l-3 8H47z"/>',
 forklift:'<path d="M8 45V29h17v16M12 29V18h18v28M35 14v35h23M43 29h14v17H43zM5 46h30"/><circle cx="13" cy="51" r="6"/><circle cx="31" cy="51" r="5"/>',
 other:'<path d="M16 34v-8a16 16 0 0132 0v8M10 35h44v7H10zM27 11v17M37 11v17M17 53h30"/>'
};
const legacy={'🏗️':'mobile','🚧':'concrete','🚜':'excavator','📦':'forklift','🚛':'dump','🦺':'other'};
export const iconType=task=>/타워|tower/i.test(task.equipment||'')?'tower':legacy[task.icon]||task.icon||'other';
export const isTower=task=>iconType(task)==='tower';
export function equipmentIcon(task){const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 64 64');svg.setAttribute('aria-hidden','true');svg.innerHTML='<g fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">'+(shapes[iconType(task)]||shapes.other)+'</g>';return svg;}
