export function tiledRegions(count,aspect=1.6){
 if(!Number.isInteger(count)||count<0||count>100)throw Error('간편 영역 개수는 0~100개로 지정해주세요.');
 if(!count)return [];
 const rows=Math.max(1,Math.min(count,Math.round(Math.sqrt(count/Math.max(.1,aspect)))));const result=[];let index=0;
 for(let row=0;row<rows;row++){const columns=Math.floor(count/rows)+(row<count%rows?1:0);for(let column=0;column<columns;column++){const x=column/columns,y=row/rows,w=1/columns,h=1/rows;result.push({points:[[x,y],[x+w,y],[x+w,y+h],[x,y+h]],index:index++});}}
 return result;
}
export function boundsOf(points){const x=points.map(p=>p[0]),y=points.map(p=>p[1]);return {left:Math.min(...x),right:Math.max(...x),top:Math.min(...y),bottom:Math.max(...y)};}
export function transformRegion(points,dx,dy,corner=null){
 const b=boundsOf(points);
 if(!corner){dx=Math.max(-b.left,Math.min(1-b.right,dx));dy=Math.max(-b.top,Math.min(1-b.bottom,dy));return points.map(p=>[p[0]+dx,p[1]+dy]);}
 const box={...b},minimum=.01;
 if(corner.includes('w'))box.left=Math.max(0,Math.min(b.right-minimum,b.left+dx));else box.right=Math.min(1,Math.max(b.left+minimum,b.right+dx));
 if(corner.includes('n'))box.top=Math.max(0,Math.min(b.bottom-minimum,b.top+dy));else box.bottom=Math.min(1,Math.max(b.top+minimum,b.bottom+dy));
 return points.map(([x,y])=>[box.left+(x-b.left)/Math.max(.000001,b.right-b.left)*(box.right-box.left),box.top+(y-b.top)/Math.max(.000001,b.bottom-b.top)*(box.bottom-box.top)]);
}
