function checkCalendar(){
 if(location.hostname!=='calendar.worksmobile.com'||!location.pathname.startsWith('/web/calendar'))throw Error('캘린더 본문 화면에서만 진단할 수 있습니다. 직접 로그인 후 캘린더를 열어주세요.');
 if([...document.querySelectorAll('input[type=password]')].some(e=>e.getBoundingClientRect().width&&e.getBoundingClientRect().height))throw Error('로그인 입력 화면에서는 진단하지 않습니다.');
}
function beginDiagnostic(){
 const legacy=window.__mouseonCalendarCapture;if(legacy?.handler){document.removeEventListener('click',legacy.handler,true);legacy.handler=null;}document.getElementById('mouseon-calendar-banner')?.remove();
 const key='__mouseonDiagnostic';const old=window[key];old?.cleanup?.();
 const state={rect:null};window[key]=state;
 const overlay=document.createElement('div');overlay.dataset.mouseonDiagnostic='true';Object.assign(overlay.style,{position:'fixed',inset:'0',zIndex:'2147483647',background:'#163f2c12',cursor:'crosshair',touchAction:'none'});
 const instruction=document.createElement('div');instruction.textContent='일정 목록 부분만 사각형으로 드래그하세요. 계정 메뉴·연락처는 제외하세요. ';Object.assign(instruction.style,{position:'absolute',top:'8px',left:'50%',transform:'translateX(-50%)',padding:'12px',borderRadius:'8px',background:'#214c3e',color:'white',font:'14px sans-serif',cursor:'default'});
 const cancel=document.createElement('button');cancel.textContent='취소';instruction.append(cancel);overlay.append(instruction);
 const box=document.createElement('div');Object.assign(box.style,{position:'absolute',border:'2px solid #2491c1',background:'#2491c125',pointerEvents:'none',boxSizing:'border-box'});overlay.append(box);document.body.append(overlay);
 let start=null;
 function move(e){if(!start)return;const x=Math.max(0,Math.min(innerWidth,e.clientX)),y=Math.max(0,Math.min(innerHeight,e.clientY));state.rect={x:Math.min(start.x,x),y:Math.min(start.y,y),width:Math.abs(x-start.x),height:Math.abs(y-start.y)};Object.assign(box.style,{left:state.rect.x+'px',top:state.rect.y+'px',width:state.rect.width+'px',height:state.rect.height+'px'});}
 function cleanup(){document.removeEventListener('keydown',escape,true);overlay.remove();state.outline?.remove();}
 function escape(e){if(e.key==='Escape'){e.preventDefault();cleanup();state.rect=null;}}
 cancel.onclick=e=>{e.stopPropagation();cleanup();state.rect=null;};
 overlay.onpointerdown=e=>{if(instruction.contains(e.target))return;e.preventDefault();e.stopImmediatePropagation();start={x:e.clientX,y:e.clientY};overlay.setPointerCapture(e.pointerId);move(e);};
 overlay.onpointermove=move;overlay.onpointerup=e=>{if(!start)return;e.preventDefault();move(e);start=null;if(state.rect.width<20||state.rect.height<20){state.rect=null;instruction.firstChild.textContent='일정 목록 부분을 더 크게 지정해주세요. ';return;}state.viewport={width:innerWidth,height:innerHeight,scrollX,scrollY};state.selectedAt=Date.now();cleanup();
  const outline=document.createElement('div');outline.dataset.mouseonDiagnostic='true';Object.assign(outline.style,{position:'fixed',left:state.rect.x+'px',top:state.rect.y+'px',width:state.rect.width+'px',height:state.rect.height+'px',border:'2px dashed #2491c1',boxSizing:'border-box',pointerEvents:'none',zIndex:'2147483646'});document.body.append(outline);state.outline=outline;
 };
 state.cleanup=cleanup;document.addEventListener('keydown',escape,true);
 return {ok:true,message:'캘린더 창에서 일정 목록 영역을 드래그한 뒤 앱으로 돌아와 진단 미리보기를 누르세요.'};
}
function readDiagnostic(includeText){
 const state=window.__mouseonDiagnostic;if(!state?.rect||!state.viewport)throw Error('먼저 진단 영역 지정을 누르고 캘린더에서 목록 영역을 드래그해주세요.');
 if(innerWidth!==state.viewport.width||innerHeight!==state.viewport.height||scrollX!==state.viewport.scrollX||scrollY!==state.viewport.scrollY)throw Error('화면 크기나 스크롤 위치가 바뀌었습니다. 영역을 다시 지정해주세요.');
 const area=state.rect,nodes=[],indexes=new Map();let truncated=false,visited=0;
 const blocked='input,textarea,select,option,script,style,noscript,template,iframe,canvas,[contenteditable],[autocomplete],[data-mouseon-diagnostic]';
 const redact=text=>text.replace(/https?:\/\/[^\s<>]+/gi,'[주소 제외]').replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi,'[이메일 제외]').replace(/\b(?:01[016789][ -]?\d{3,4}[ -]?\d{4}|\+\d[\d -]{8,}\d)\b/g,'[전화번호 제외]').replace(/\b(?:Bearer\s+\S+|[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,}\.[A-Za-z0-9_-]{12,})\b/gi,'[인증 문자열 제외]').replace(/\b(?:access_token|refresh_token|password|secret|cookie|sessionid)\s*[:=]\s*\S+/gi,'[인증 문자열 제외]');
 for(const element of document.querySelectorAll('body *')){
  if(++visited>25000){truncated=true;break;}
  if(element.closest(blocked))continue;
  const r=element.getBoundingClientRect();if(!r.width||!r.height||r.left<area.x-.5||r.top<area.y-.5||r.right>area.x+area.width+.5||r.bottom>area.y+area.height+.5)continue;
  if(element.checkVisibility&&!element.checkVisibility({checkOpacity:true,checkVisibilityCSS:true}))continue;
  const css=getComputedStyle(element);if(css.visibility==='hidden'||css.display==='none'||css.opacity==='0')continue;
  if(nodes.length>=500){truncated=true;break;}
  const tokens=[...element.classList].filter(s=>/^[A-Za-z_][A-Za-z0-9_-]{0,47}$/.test(s)&&!/(?:token|session|oauth|secret|password|credential|csrf)/i.test(s)).slice(0,10);
  let parent=element.parentElement;while(parent&&!indexes.has(parent))parent=parent.parentElement;
  const own=[...element.childNodes].filter(n=>n.nodeType===Node.TEXT_NODE).map(n=>n.textContent).join(' ').replace(/\s+/g,' ').trim();
  const item={tag:element.tagName.toLowerCase(),classes:tokens,parent:parent?indexes.get(parent):null,box:{x:Math.round(r.x-area.x),y:Math.round(r.y-area.y),width:Math.round(r.width),height:Math.round(r.height)},hasOwnText:Boolean(own)};
  const role=element.getAttribute('role');if(role&&/^[a-z]{1,30}$/.test(role))item.role=role;
  if(includeText&&own)item.text=redact(own).slice(0,400);
  indexes.set(element,nodes.length);nodes.push(item);
 }
 if(!nodes.length)throw Error('선택 영역 안의 화면 요소를 찾지 못했습니다. 일정 목록을 더 넓게 지정해주세요.');
 return {format:'mouseon-works-diagnostic/v1',hostname:'calendar.worksmobile.com',pageKind:'calendar',includesText:Boolean(includeText),region:{x:Math.round(area.x),y:Math.round(area.y),width:Math.round(area.width),height:Math.round(area.height)},viewport:{width:innerWidth,height:innerHeight},truncated,nodes,notes:['선택 영역의 현재 가시 요소만 포함합니다. 전체 DOM/HTML/주소/입력값/쿠키/스크립트를 포함하지 않습니다.','일정 글자를 선택적으로 포함했다면 저장 전 원문과 민감정보를 직접 확인해주세요.','화면 구조 진단용입니다. 일정 수집 성공이나 API 권한을 의미하지 않습니다.']};
}
const preamble=`(${checkCalendar.toString()})();`;
const allowedErrors=['캘린더 본문 화면에서만 진단할 수 있습니다. 직접 로그인 후 캘린더를 열어주세요.','로그인 입력 화면에서는 진단하지 않습니다.','먼저 진단 영역 지정을 누르고 캘린더에서 목록 영역을 드래그해주세요.','화면 크기나 스크롤 위치가 바뀌었습니다. 영역을 다시 지정해주세요.','선택 영역 안의 화면 요소를 찾지 못했습니다. 일정 목록을 더 넓게 지정해주세요.'];
function wrap(expression){return `(()=>{try{${preamble}return ${expression};}catch(error){return {diagnosticError:${JSON.stringify(allowedErrors)}.includes(error.message)?error.message:'화면 구조 진단에 실패했습니다. 캘린더를 다시 열고 영역을 지정해주세요.'};}})()`;}
export const beginDiagnosticExpression=wrap(`(${beginDiagnostic.toString()})()`);
export const readDiagnosticExpression=includeText=>wrap(`(${readDiagnostic.toString()})(${JSON.stringify(Boolean(includeText))})`);
