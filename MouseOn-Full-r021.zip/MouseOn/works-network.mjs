import {createHash,randomBytes} from 'node:crypto';
import {validDate} from './public/calendar.js';
import {interpret,regionPoint} from './public/interpret.js';
const text=(v,max=300)=>typeof v==='string'?v.trim().slice(0,max):typeof v==='number'&&Number.isFinite(v)?String(v):'';
const first=(o,keys)=>keys.map(k=>o?.[k]).find(v=>v!==undefined&&v!==null&&v!=='');
export function scheduleDate(v){
 if(v&&typeof v==='object')v=first(v,['date','dateTime','datetime','startDate','value']);
 if((typeof v==='number'||typeof v==='string'&&/^\d{10,13}$/.test(v))&&Number(v)>=1e9){const date=new Date(Number(v)*(Number(v)<1e11?1000:1));if(!Number.isFinite(+date))return null;return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);}
 const s=text(v,80);const m=s.match(/^(\d{4})-?(\d{2})-?(\d{2})(?:$|[T\s])/);if(!m)return null;
 const d=m.slice(1).join('-');if(!validDate(d))return null;
 if(/[T\s]\d{2}:\d{2}.*(?:Z|[+-]\d{2}:?\d{2})$/.test(s)){const date=new Date(s);if(!Number.isFinite(+date))return null;return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);}
 return d;
}
// Only known schedule fields are retained. Credentials, URLs and arbitrary JSON never leave the helper.
export function extractSchedules(payload){
 const events=[],seen=new Set();let visited=0,unscoped=0;
 function walk(value,context={},depth=0){
  if(!value||typeof value!=='object'||depth>12||++visited>30000)return;
  if(Array.isArray(value)){for(const item of value.slice(0,2000))walk(item,context,depth+1);return;}
  const calendarId=text(first(value,['calendarId','calendarUid','calendarNo','calendarID','calendarUniqueId','calId','calNo'])??value.calendar?.id??context.id,120);
  const calendarName=text(first(value,['calendarName','calendarTitle'])??value.calendar?.name??context.name,100);
  const title=text(first(value,['summary','subject','title','eventTitle','scheduleTitle','scheduleName','eventName']));
  const date=scheduleDate(first(value,['start','startDateTime','startDatetime','startDate','beginDate','dtstart','startTime','startDt','startYmd']));
  const id=text(first(value,['eventId','scheduleId','eventUid','scheduleNo','eventNo','uid','id']),120);
  if(title&&date&&id){
   if(!calendarId)unscoped++;
   else{
    const key=JSON.stringify([calendarId,id,date]);
    if(!seen.has(key)&&events.length<2000){seen.add(key);events.push({id,calendarId,calendarName:calendarName||calendarId,title,date,description:text(first(value,['description','detail','memo']),800),cancelled:value.cancelled===true||value.isCancelled===true||value.deleted===true||value.isDeleted===true||/^(cancelled|canceled|cancel|deleted|delete|removed)$/i.test(text(value.status,30))});}
   }
  }
  for(const [key,item] of Object.entries(value)){if(/token|cookie|password|secret|auth|session|headers/i.test(key))continue;if(item&&typeof item==='object')walk(item,{id:calendarId,name:calendarName},depth+1);}
 }
 walk(payload);return {events,unscoped};
}
export const networkSourceId=(path,method,calendarId)=>createHash('sha256').update(JSON.stringify([path,method,calendarId])).digest('hex').slice(0,20);
export function mergeNetworkSchedules(room,events,site,scope){
 if(!scope||!validDate(scope.date)||!Array.isArray(events)||events.length>2000)throw Error('자동 수집 범위를 확인해주세요.');
 let added=0,updated=0,skipped=0;
 for(const event of events){
  if(event.calendarId!==scope.calendarId||event.date!==scope.date||!text(event.id,120)||!text(event.title))continue;
  const sourceKey=createHash('sha256').update(JSON.stringify(['works-network',event.calendarId,event.id])).digest('hex');
  const old=room.tasks.find(t=>t.sourceKey===sourceKey),fingerprint=createHash('sha256').update(JSON.stringify(event)).digest('hex');
  if(old?.networkVersion===fingerprint){skipped++;continue;}
  if(!old&&(event.cancelled||room.tasks.length>=200)){skipped++;continue;}
  const original=(event.title+'\n'+(event.description||'')).trim().slice(0,1200);
  const candidate=interpret({text:original,date:event.date,calendar:event.calendarName},site.regions);
  candidate.title=event.title.slice(0,80);candidate.detail=(event.description||'').slice(0,180);
  if(event.cancelled)candidate.reasons.push('웍스에서 취소된 일정입니다. 작업 유지·삭제 확인 필요');
  if(old){
   const geometry={x:old.x,y:old.y,regionId:old.regionId};
   Object.assign(old,candidate,{networkVersion:fingerprint,networkCancelled:Boolean(event.cancelled)});
   if(old.manuallyPlaced||old.shape!=='point'){Object.assign(old,geometry);old.reasons=old.reasons.filter(s=>!s.includes('동·시설')&&!s.includes('여러 영역'));}
   updated++;
  }else{
   if(candidate.regionId){const r=site.regions.find(r=>r.id===candidate.regionId);const p=regionPoint(r,room.tasks.filter(t=>t.regionId===r.id).length);candidate.x=p[0];candidate.y=p[1];}
   room.tasks.push({...candidate,id:randomBytes(6).toString('hex'),equipment:'웍스 일정',shape:'point',points:[],sourceKey,networkVersion:fingerprint,networkCancelled:false});added++;
  }
 }
 return {added,updated,skipped};
}
