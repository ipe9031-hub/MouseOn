export const ringArea=p=>p.reduce((s,a,i)=>{const b=p[(i+1)%p.length];return s+a[0]*b[1]-b[0]*a[1];},0)/2;
export const regionPieces=r=>r.pieces||[[r.points]];
export const regionRings=r=>regionPieces(r).flat();
export const regionArea=r=>regionPieces(r).reduce((s,p)=>s+Math.abs(ringArea(p[0]))-p.slice(1).reduce((h,ring)=>h+Math.abs(ringArea(ring)),0),0);
export function withPieces(region,pieces){const clean=pieces.map(p=>p.map(r=>{const out=r.map(p=>[...p]);if(out.length>1&&out[0][0]===out.at(-1)[0]&&out[0][1]===out.at(-1)[1])out.pop();return out;}));clean.sort((a,b)=>Math.abs(ringArea(b[0]))-Math.abs(ringArea(a[0])));const result={...region,points:clean[0]?.[0]||[]};if(clean.length===1&&clean[0].length===1)delete result.pieces;else result.pieces=clean;return result;}
export const regionPath=r=>regionRings(r).map(ring=>'M'+ring.map(p=>p.map(v=>v*1000).join(' ')).join('L')+'Z').join(' ');
export function mapRegionRings(region,fn){return withPieces(region,regionPieces(region).map(p=>p.map(fn)));}
