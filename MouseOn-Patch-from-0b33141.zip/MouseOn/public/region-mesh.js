import './vendor/polygon-clipping.js';
import {regionRings,mapRegionRings,regionPieces,regionArea,withPieces} from './region-geometry.js';
const eps=1e-8;
export const nodeKey=p=>p.map(v=>Math.round(v*1e8)).join(':');
const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
export const polygonArea=p=>p.reduce((s,a,i)=>{const b=p[(i+1)%p.length];return s+a[0]*b[1]-b[0]*a[1];},0)/2;
const crossing=(a,b,c,d)=>cross(a,b,c)*cross(a,b,d)<-1e-14&&cross(c,d,a)*cross(c,d,b)<-1e-14;
export function conformRegions(regions){
 const vertices=[...new Map(regions.flatMap(r=>regionRings(r).flat()).map(p=>[nodeKey(p),p])).values()];
 return regions.map(r=>mapRegionRings(r,ring=>ring.flatMap((a,i)=>{const b=ring[(i+1)%ring.length],dx=b[0]-a[0],dy=b[1]-a[1],length=dx*dx+dy*dy;if(length<eps)return [a];return [a,...vertices.map(p=>({p,t:((p[0]-a[0])*dx+(p[1]-a[1])*dy)/length})).filter(v=>v.t>eps&&v.t<1-eps&&Math.abs(cross(a,b,v.p))<eps).sort((x,y)=>x.t-y.t).map(v=>[...v.p])];})));
}
export function validMesh(regions){
 const edges=new Map();
 for(const r of regions){for(const p of regionRings(r)){if(p.length<3||p.length>100||Math.abs(polygonArea(p))<.00002||p.some(a=>a.some(v=>!Number.isFinite(v)||v<0||v>1)))return false;
  for(let i=0;i<p.length;i++){const a=p[i],b=p[(i+1)%p.length];if(nodeKey(a)===nodeKey(b))return false;for(let j=i+2;j<p.length;j++){if(i===0&&j===p.length-1)continue;if(crossing(a,b,p[j],p[(j+1)%p.length]))return false;}edges.set([nodeKey(a),nodeKey(b)].sort().join('/'),[a,b]);}
 }}
 const unique=[...edges.values()];for(let i=0;i<unique.length;i++)for(let j=i+1;j<unique.length;j++)if(crossing(...unique[i],...unique[j]))return false;return true;
}
export function moveSharedNodes(regions,changes){
 const map=new Map(changes.map(({from,to})=>[nodeKey(from),[from[0]<eps?0:from[0]>1-eps?1:Math.max(0,Math.min(1,to[0])),from[1]<eps?0:from[1]>1-eps?1:Math.max(0,Math.min(1,to[1]))]]));
 const next=regions.map(r=>mapRegionRings(r,ring=>ring.map(p=>map.get(nodeKey(p))||[...p])));
 if(!validMesh(next)||next.some((r,i)=>polygonArea(r.points)*polygonArea(regions[i].points)<=0))throw Error('다른 영역이 뒤집히거나 너무 작아지는 위치로는 옮길 수 없습니다.');return next;
}
export function insertSharedPoint(regions,id,index,t=.5){
 const next=structuredClone(regions),r=next.find(r=>r.id===id);const a=r.points[index],b=r.points[(index+1)%r.points.length];t=Math.max(.05,Math.min(.95,t));const point=[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t];r.points.splice(index+1,0,point);const conformed=conformRegions(next);if(!validMesh(conformed))throw Error('이 위치에는 점을 추가할 수 없습니다.');return {regions:conformed,point};
}
export function removeSharedPoint(regions,key){
 const sample=regions.flatMap(r=>regionRings(r).flat()).find(p=>nodeKey(p)===key);if(!sample)throw Error('점을 먼저 선택해주세요.');if((sample[0]<eps||sample[0]>1-eps)&&(sample[1]<eps||sample[1]>1-eps))throw Error('사진 모서리는 삭제할 수 없습니다.');
 const neighbors=new Set();for(const r of regions)for(const ring of regionRings(r)){const i=ring.findIndex(p=>nodeKey(p)===key);if(i>=0){neighbors.add(nodeKey(ring[(i+ring.length-1)%ring.length]));neighbors.add(nodeKey(ring[(i+1)%ring.length]));}}
 if(neighbors.size>2)throw Error('여러 영역이 만나는 교차점은 삭제하지 않습니다. 경계에 추가한 점을 선택해주세요.');
 const next=regions.map(r=>mapRegionRings(r,ring=>ring.filter(p=>nodeKey(p)!==key)));if(!validMesh(next))throw Error('영역을 유지하려면 이 점이 필요합니다.');return next;
}
export function mergeDeletedRegion(regions,id){
 const removed=regions.find(r=>r.id===id);if(!removed)return regions;if(regions.length===1)return [];
 let best=null,length=0;
 for(const r of regions.filter(r=>r.id!==id)){let score=0;for(const outer of regionRings(removed))for(let i=0;i<outer.length;i++){const a=outer[i],b=outer[(i+1)%outer.length];for(const ring of regionRings(r))for(let j=0;j<ring.length;j++){const c=ring[j],d=ring[(j+1)%ring.length];if(nodeKey(a)===nodeKey(d)&&nodeKey(b)===nodeKey(c))score+=Math.hypot(a[0]-b[0],a[1]-b[1]);}}if(score>length){length=score;best=r;}}
 if(!best)throw Error('맞닿은 이웃이 없습니다. 개수 설정에서 삭제 후 전체 자동 배치를 사용해주세요.');
 const merged=globalThis.polygonClipping?.union(regionPieces(removed),regionPieces(best));if(!merged)throw Error('영역 합치기를 불러오지 못했습니다.');const next=regions.filter(r=>r.id!==id).map(r=>r.id===best.id?withPieces({...r,fixed:false},merged):r);if(!validMesh(next))throw Error('영역 합치기에 실패했습니다.');return conformRegions(next);
}
