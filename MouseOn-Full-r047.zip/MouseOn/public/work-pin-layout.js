import {inside,insideRegion,isBuildingRegion} from './interpret.js';
import {regionPieces} from './region-geometry.js';
const frame={width:1000,height:600},half=26;
const overlap=(a,b)=>Math.max(0,Math.min(a.right,b.right)-Math.max(a.left,b.left))*Math.max(0,Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
export function assignWorkPins(tasks,site={}){
 const regions=site.regions||[],byId=new Map(regions.map(r=>[r.id,r])),buildings=regions.filter(isBuildingRegion),blocks=[],fresh=[];
 const source=t=>JSON.stringify(['pin-v1',t.x,t.y,Boolean(t.manuallyPlaced),t.regionId||null,t.placement||'',t.shape||'point',t.manuallyPlaced?0:site.revision||0]);
 const box=p=>({left:p[0]*frame.width-half,right:p[0]*frame.width+half,top:p[1]*frame.height-half,bottom:p[1]*frame.height+half});
 for(const t of tasks){if(!Number.isFinite(t.x)||!Number.isFinite(t.y)){delete t.displayPoint;delete t.displaySource;continue;}const key=source(t),valid=t.displaySource===key&&Array.isArray(t.displayPoint)&&t.displayPoint.length===2&&t.displayPoint.every(v=>Number.isFinite(v)&&v>=0&&v<=1);if(t.manuallyPlaced||t.shape==='area'){t.displayPoint=[t.x,t.y];t.displaySource=key;blocks.push(box(t.displayPoint));}else if(valid)blocks.push(box(t.displayPoint));else fresh.push({task:t,key});}
 fresh.sort((a,b)=>String(a.task.id).localeCompare(String(b.task.id)));
 for(const {task:t,key} of fresh){const positions=[],region=byId.get(t.regionId),x=t.x*frame.width,y=t.y*frame.height;
  for(const radius of [0,20,40,64,90,130,180,240])for(let i=0;i<(radius?24:1);i++){const angle=i*Math.PI/12;positions.push([(x+radius*Math.cos(angle))/frame.width,(y+radius*Math.sin(angle))/frame.height]);}
  if(region&&t.placement==='equipment-ground')for(const polygon of regionPieces(region))for(const ring of polygon)for(let i=0;i<ring.length;i++){const a=ring[i],b=ring[(i+1)%ring.length],dx=(b[0]-a[0])*frame.width,dy=(b[1]-a[1])*frame.height,len=Math.hypot(dx,dy);if(!len)continue;for(const v of [.1,.25,.5,.75,.9])for(const side of [-1,1])positions.push([a[0]+(b[0]-a[0])*v-side*dy/len*34/frame.width,a[1]+(b[1]-a[1])*v+side*dx/len*34/frame.height]);}
  let best=null;for(const p of positions){if(p.some(v=>v<0||v>1))continue;if(region&&t.placement==='inside'&&!insideRegion(p,region))continue;if(region&&t.placement==='surrounding'&&insideRegion(p,region))continue;if(t.placement==='equipment-ground'&&buildings.some(r=>[[0,0],[-half,-half],[half,-half],[-half,half],[half,half]].some(([dx,dy])=>insideRegion([p[0]+dx/frame.width,p[1]+dy/frame.height],r))))continue;if(site.outline?.length&&inside([t.x,t.y],site.outline)&&!inside(p,site.outline))continue;const b=box(p);let score=Math.hypot((p[0]-t.x)*frame.width,(p[1]-t.y)*frame.height);for(const previous of blocks)score+=overlap(b,{left:previous.left-6,right:previous.right+6,top:previous.top-6,bottom:previous.bottom+6})*10000;if(!best||score<best.score)best={p,b,score};}
  t.displayPoint=best?.p||[t.x,t.y];t.displaySource=key;blocks.push(best?.b||box(t.displayPoint));
 }
 return tasks;
}
