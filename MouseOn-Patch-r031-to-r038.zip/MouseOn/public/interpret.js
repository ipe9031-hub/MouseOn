import {regionPieces,regionArea} from './region-geometry.js';
import './vendor/polygon-clipping.js';
import {validDate} from './calendar.js';
export const kindInfo={formwork:['갱폼','#c2410c'],rope:['로프 작업','#be185d'],sky:['스카이·고소작업차','#9333ea'],roller:['롤러','#a16207'],tower:['타워크레인','#6d28d9'],mobile:['이동식 크레인','#7c3aed'],concrete:['타설','#0369a1'],mixer:['레미콘','#1d4ed8'],excavator:['굴착기','#b45309'],forklift:['지게차·하역','#047857'],dump:['덤프','#4d7c0f'],other:['기타','#475569']};
export function kindOf(text){return /스카이|고소\s*작업\s*차|고소\s*작업\s*대|붐\s*리프트|\bsky(?:lift)?\b/i.test(text)?'sky':/포장|투수\s*콘|롤러|로울러|진동\s*로라|로드\s*롤러/i.test(text)?'roller':/갱폼/.test(text)?'formwork':/로프/.test(text)?'rope':/타워/.test(text)?'tower':/크레인|인양|양중/.test(text)?'mobile':/레미콘/.test(text)?'mixer':/타설|콘크리트/.test(text)?'concrete':/지게차|하역/.test(text)?'forklift':/덤프/.test(text)?'dump':/굴착|백호/.test(text)?'excavator':'other';}
export function excludedSchedule(entry){
 const title=(entry.text||entry.original||entry.title||'').split(/\r?\n/)[0];
 return !mapCalendar(entry.calendar)||/^\s*7\.\s*/.test(title)||/미팅|회의|행사|회식|건강검진|안전교육|점검(?!구|로|통로|발판|계단)/.test(title);
}
// Site convention: road/ground passage pours use an excavator; structure pours use a pump.
// This is an editable interpretation rule, not verification of equipment on site.
export function concreteContext(text){
 const clean=text.normalize('NFKC').replace(/\s+/g,' '),compact=clean.replace(/\s/g,'');
 const target=compact.replace(/(?:펌프카|레미콘|차량|장비)?[^,;。\n]*?(?:도로|통로|통행로|진입로|출입로|동선)(?:확보|정리|조정|이동|진입|통제|개방|사용)(?:후|하고|및)?/g,' ');
 const explicit=target.replace(/(?:굴착기|굴삭기|백호|포크레인|펌프\s*카|콘크리트\s*펌프|붐\s*펌프|라인\s*펌프)\s*(?:미사용|없음|제외|사용하지\s*않음)/g,'');
 const excavator=/굴착기|굴삭기|백호|포크레인/.test(explicit),pump=/펌프\s*카|콘크리트\s*펌프|붐\s*펌프|라인\s*펌프/.test(explicit);
 if(pump||excavator)return {method:pump&&excavator?'mixed':pump?'pump':'excavator',inferred:false,basis:'원문에 명시된 장비'};
 const locations=/(?:피난|소방|비상|가설|단지내|단지|내부|외부|구내|연결|진입|출입|우회|임시|작업|차량|보행자전용|보행자|보행|산책|자전거)?(?:도로|통로|통행로)|진입로|출입로|대피로|피난로|연결로|우회로|작업로|비상차로|(?:비상|피난|대피|소방|차량|보행)동선|보행로|산책로|차도|보도|인도|자전거길|경사로|램프|RAMP/gi;
 // Discard access/logistics clauses before deciding what is actually being poured.
 const location=target.replace(/도로명|도로교통법|도로점용허가|보도자료|통로안내표지/g,' ').replace(/(?:도로|통로)(?:측|옆|인근|주변)(?=.{0,8}\d+동)/g,' ').match(locations)?.[0],structural=/(?:슬래브|스라브|벽체|기둥|보타설|거더|기초|매트|코어|옥상|지붕|피난계단|피난층|피난안전구역|실내|내부복도|공용복도|\d+층)[^,;。]{0,14}타설/.test(target);
 const excludedPump=/(?:펌프카|콘크리트펌프|붐펌프|라인펌프)(?:미사용|없음|제외|사용하지않음)/.test(compact),excludedExcavator=/(?:굴착기|굴삭기|백호|포크레인)(?:미사용|없음|제외|사용하지않음)/.test(compact);
 if(location&&!structural&&excludedExcavator||(!location||structural)&&excludedPump)return {method:'unspecified',inferred:true,basis:'장비 제외 표현으로 사용 장비 확인 필요'};
 if(location&&!structural)return {method:'excavator',inferred:true,basis:location+' 등 지상 통행 공간 타설'};
 return {method:'pump',inferred:true,basis:structural?'건물 구조부 타설':'일반 타설 기본 규칙'};
}
export function classifyWork(text,calendar='',hazards=[]){
 const compact=text.replace(/\s/g,''),clean=text.replace(/(?:굴착기|굴삭기|백호|포크레인|펌프카)\s*(?:미사용|없음|제외)/g,''),landscaping=/식재|수목|조경|녹지|잔디|관목|교목/.test(text);
 const excavator=/굴착기|굴삭기|백호|포크레인/.test(clean),pump=/펌프\s*카|콘크리트\s*펌프|붐\s*펌프|라인\s*펌프/.test(clean),pouring=/타설/.test(text)||pump&&/^(?:1[.\s]*)?타설/.test(calendar.replace(/\s/g,''));
 const hazard=hazards.find(h=>{const name=h.name.replace(/\s/g,'').replace(/작업$/,'');return name.length>=2&&compact.includes(name);});
 const calendarHigh=/^(?:3[.\s]*)?고위험/.test(calendar.replace(/\s/g,'')),numberedHigh=/^\s*3\.\s*/.test(text),wordHigh=/갱폼|로프|고소|해체|인양|양중|밀폐|화기|용접|고위험/.test(clean),high=calendarHigh||numberedHigh||wordHigh||Boolean(hazard);
 let icon=kindOf(clean),equipmentInferred=false,equipmentHint='',concreteMethod=null;
 if(pouring&&!(icon==='roller'&&!pump&&!excavator)){const context=concreteContext(text);concreteMethod=context.method;equipmentInferred=context.inferred;equipmentHint=context.inferred?context.basis+(concreteMethod==='unspecified'?'':' · '+(concreteMethod==='excavator'?'굴착기':'펌프카')+' 표시 추정'):'';icon=concreteMethod==='excavator'?'excavator':'concrete';}
 else if(excavator){icon='excavator';}
 else if(landscaping&&icon==='other'&&!/(?:굴착기|굴삭기|백호|포크레인)\s*(?:미사용|없음|제외|사용하지)/.test(text)){icon='excavator';equipmentInferred=true;equipmentHint='식재·조경: 굴착기 사용 추정 · 장비 확인 필요';}
 if(high&&icon==='other')icon='hazard';
 const groundPour=pouring&&concreteContext(text.replace(/펌프\s*카|콘크리트\s*펌프|붐\s*펌프|라인\s*펌프|굴착기|굴삭기|백호|포크레인/g,'')).method==='excavator';
 const upper=text.match(/로프|펜트\s*하우스|PENTHOUSE|스카이|고소\s*작업|외벽|(?<![지하\d])(?:[2-9]|[1-9]\d+)층|갱폼.{0,6}인상|상부|옥상|최상층/i),lower=text.match(/식재|수목|조경|녹지|잔디|굴착|굴삭|백호|포크레인|하역|지상|하부|토공|포장/);
 return {icon,riskLevel:high?'high':'normal',riskBasis:calendarHigh?'캘린더 고위험 분류':numberedHigh?'원문의 고위험 분류 번호':hazard?'현장 고위험 종류':wordHigh?'원문의 고위험 작업 표현':'일반 작업 분류',hazardId:hazard?.id||null,hazardName:hazard?.name||null,hazardColor:high?(hazard?.color||'#b4233d'):null,equipmentInferred,equipmentHint,concreteMethod,workLevel:upper?'upper':lower||groundPour?'lower':'unknown',workLevelBasis:upper?.[0]||lower?.[0]||(groundPour?'지상 통행 공간 타설':'')};
}
export function isPumpConcrete(task){if(task.icon==='roller')return false;const text=[task.original||task.title,task.equipment,task.detail].filter(Boolean).join(' ');if(task.concreteMethod&&task.concreteMethod!=='unspecified')return ['pump','mixed'].includes(task.concreteMethod);return /타설/.test(text)&&['pump','mixed'].includes(concreteContext(text).method);}
function workWindow(task){const text=[task.title,task.original,task.detail].filter(Boolean).join(' '),m=text.match(/(\d{1,2})(?::(\d{2})|시(?:\s*(\d{1,2})분)?)\s*[~∼-]\s*(\d{1,2})(?::(\d{2})|시(?:\s*(\d{1,2})분)?)/);if(!m||Number(m[1])>23||Number(m[4])>24||Number(m[2]||m[3]||0)>59||Number(m[5]||m[6]||0)>59)return null;const start=Number(m[1])*60+Number(m[2]||m[3]||0),end=Number(m[4])*60+Number(m[5]||m[6]||0);return start>=0&&start<end&&end<=1440?{start,end}:null;}
export function verticalConflictPairs(tasks,regions=[]){
 const result=[],byId=new Map(regions.map(r=>[r.id,r]));
 const geometry=t=>t.shape==='area'&&t.points?.length>=3?{points:t.points}:!t.manuallyPlaced&&!['surrounding','between'].includes(t.placement)?byId.get(t.regionId):null;
 for(let i=0;i<tasks.length;i++)for(let j=i+1;j<tasks.length;j++){
  const a=tasks[i],b=tasks[j];if(a.date!==b.date)continue;
  const facts=t=>classifyWork([t.original||t.title,t.detail,t.equipment,t.icon==='rope'?'로프 작업':t.icon==='sky'?'고소 작업':t.icon==='excavator'||t.icon==='🚜'?'굴착 작업':t.icon==='roller'?'포장 작업':''].filter(Boolean).join(' '));
  const aa=facts(a),bb=facts(b);
  if(!((aa.workLevel==='upper'&&bb.workLevel==='lower')||(bb.workLevel==='upper'&&aa.workLevel==='lower')))continue;
  const wa=workWindow(a),wb=workWindow(b);if(wa&&wb&&(wa.end<=wb.start||wb.end<=wa.start))continue;
  const ga=geometry(a),gb=geometry(b);let position=null,footprint=null;
  if(ga&&gb){try{const pieces=globalThis.polygonClipping.intersection(regionPieces(ga),regionPieces(gb));if(pieces.length&&regionArea({pieces})>1e-10){footprint={pieces,points:pieces[0][0]};position=regionPoint(footprint);}}catch{continue;}}
  else if(ga&&Number.isFinite(b.x)&&Number.isFinite(b.y)&&insideRegion([b.x,b.y],ga))position=[b.x,b.y];
  else if(gb&&Number.isFinite(a.x)&&Number.isFinite(a.y)&&insideRegion([a.x,a.y],gb))position=[a.x,a.y];
  else if(!regions.length&&a.regionId&&a.regionId===b.regionId&&[a.x,a.y,b.x,b.y].every(Number.isFinite))position=[(a.x+b.x)/2,(a.y+b.y)/2];
  if(!position)continue;
  const upper=aa.workLevel==='upper'?a:b,lower=upper===a?b:a;
  const reason='상하 작업 확인: '+upper.title+' (상부 단서) / '+lower.title+' (하부 단서) · '+(wa&&wb?'예정 시간 겹침':'시간 미확인')+' · 실제 높이·동시작업 여부 확인 필요';
  result.push({id:[a.id,b.id].sort().join(':'),taskIds:[a.id,b.id],x:position[0],y:position[1],reason,footprint});
 }return result;
}
export function verticalConflicts(tasks,regions=[]){const result=new Map();for(const pair of verticalConflictPairs(tasks,regions))for(const id of pair.taskIds){const reasons=result.get(id)||[];reasons.push(pair.reason);result.set(id,reasons);}return result;}
function placeName(text){return text.normalize('NFKC').toUpperCase().replace(/(?<![A-Z])GATE(?=$|[^A-Z]|[A-Z](?![A-Z]))/g,'게이트').replace(/(?<![A-Z])RAMP(?=$|[^A-Z]|[A-Z](?![A-Z]))/g,'램프').replace(/(?<![\d:A-Z])(\d{1,3}|[A-Z])\s*(?:번\s*)?(게이트|램프)(?!\s*#?\s*[\dA-Z])/g,'$2$1').replace(/(게이트|램프)\s*#?\s*(\d{1,3}|[A-Z])(?:번)?/g,'$1$2');}
function hit(text,alias){const a=alias.replace(/\s/g,'');let from=0,i;while((i=text.indexOf(a,from))!==-1){if(!(/^\d/.test(a)&&i>0&&/\d/.test(text[i-1]))&&!(/\d$/.test(a)&&/\d/.test(text[i+a.length]||''))&&!(/[A-Z]$/.test(a)&&/[A-Z0-9]/.test(text[i+a.length]||'')))return true;from=i+1;}return false;}
export function matchRegions(text,regions){
 const facilities=[];const normalized=placeName(text).replace(/(?:근린생활시설|근생)\s*(?:제\s*)?\d{1,3}(?:\s*[,、·/]\s*(?:(?:근린생활시설|근생)\s*)?(?:제\s*)?\d{1,3})*(?:\s*동)?/g,part=>{facilities.push(...[...part.matchAll(/\d+/g)].map(m=>'근생'+Number(m[0])));return ' ';});
 const facilityText=facilities.join('|');
 const ranged=normalized.replace(/(?<!\d)(\d{1,4})\s*[~〜∼-]\s*(\d{1,4})\s*동/g,(all,a,b)=>{const from=Number(a),to=Number(b);return to>=from&&to-from<=100?Array.from({length:to-from+1},(_,i)=>(from+i)+'동').join(' '):all;});
 const expanded=ranged.replace(/(?<!\d)(\d{1,4}(?:\s*[,、·/]\s*\d{1,4})+)\s*동/g,(_,list)=>list.split(/\s*[,、·/]\s*/).map(n=>n+'동').join(' '));
 const located=expanded.replace(/(?<![\d:/])(\d{1,4}(?:\s*[,、·]\s*\d{1,4})+)(\s*)([가-힣]*)/g,(all,list,space,word,offset)=>{
  if(/^(?:동|층|호|시|분|일|월|년|명|대|톤|개|미터|시간)/.test(word)||/(?:시간|시각|날짜|일자|수량|대수|인원)\s*$/.test(expanded.slice(Math.max(0,offset-12),offset)))return all;
  return list.split(/\s*[,、·]\s*/).map(n=>n+'동').join(' ')+space+word;
 });
 const clean=located.replace(/(?<=\d)\s+(?=\d)/g,'|').replace(/\s/g,'');
 const numbers=regions.map(r=>({region:r,number:r.name?.normalize('NFKC').replace(/\s/g,'').match(/^(\d{1,4})동?$/)?.[1]}));
 return regions.filter(r=>{
  const names=[r.name,...(r.aliases||[])];const number=numbers.find(n=>n.region===r)?.number;
  if(number?.length===3){const short=String(Number(number.slice(1))),exact=numbers.some(n=>n.number&&Number(n.number)===Number(short));const peers=numbers.filter(n=>n.number?.length===3&&Number(n.number.slice(1))===Number(short));if(!exact&&peers.length===1)names.push(short+'동');}
  return names.filter(a=>a?.trim()).some(a=>{const canonical=placeName(a);const facility=canonical.replace(/근린생활시설/g,'근생').replace(/\s/g,'').replace(/^근생제?/,'근생').replace(/(근생\d+)동$/,'$1');return /^근생\d+$/.test(facility)?hit(facilityText,facility):hit(clean,canonical);});
 });
}
export function mapCalendar(calendar=''){return !/^(?:7[.\s]*)?(?:회의[,·\s]*행사|회의[·,\s]*행사[·,\s]*대내외점검|대내외점검)/.test(calendar.normalize('NFKC').replace(/\s/g,''));}
export const placementVersion='r038';
export function interpretAll(entry,regions,outline=null,hazards=[]){
 if(excludedSchedule(entry))return [];const candidate=interpret(entry,regions,outline,hazards);
 const matches=matchRegions(entry.text,regions);
 // Relative locations need confirmation; do not pretend the named buildings are the work location.
 if(matches.length<2||/사이|사잇|중간/.test(entry.text))return [candidate];
 return matches.map(region=>{const point=candidate.placement==='surrounding'?surroundingPoint(region,regions,outline):regionPoint(region);const reasons=candidate.reasons.filter(r=>!r.includes('여러 영역')&&!r.includes('주변 위치'));if(!point)reasons.push('영역 바깥의 주변 위치 확인 필요');return {...candidate,regionId:region.id,x:point?.[0]??null,y:point?.[1]??null,reasons};});
}

export function inside(point,polygon){let yes=false;for(let i=0,j=polygon.length-1;i<polygon.length;j=i++){const a=polygon[i],b=polygon[j];if((a[1]>point[1])!==(b[1]>point[1])&&point[0]<(b[0]-a[0])*(point[1]-a[1])/(b[1]-a[1])+a[0])yes=!yes;}return yes;}
export function insideRegion(point,region){return regionPieces(region).some(p=>inside(point,p[0])&&!p.slice(1).some(hole=>inside(point,hole)));}
export function regionPoint(region,slot=0){if(region.pieces){for(const polygon of regionPieces(region)){const xs=polygon[0].map(p=>p[0]),ys=polygon[0].map(p=>p[1]);for(let step=0;step<900;step++){const x=step===0?.5:((step+slot*13)%30+.5)/30,y=step===0?.5:(Math.floor((step+slot*13)%900/30)+.5)/30,q=[Math.min(...xs)+(Math.max(...xs)-Math.min(...xs))*x,Math.min(...ys)+(Math.max(...ys)-Math.min(...ys))*y];if(inside(q,polygon[0])&&!polygon.slice(1).some(h=>inside(q,h)))return q;}}return region.points[0];}const p=region.points;const xs=p.map(a=>a[0]),ys=p.map(a=>a[1]);const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);const center=[(minX+maxX)/2,(minY+maxY)/2];if(slot>0){for(let step=0;step<50;step++){const angle=(slot+step)*2.399963;const radius=.16+(slot%3)*.09;const q=[center[0]+(maxX-minX)*radius*Math.cos(angle),center[1]+(maxY-minY)*radius*Math.sin(angle)];if(inside(q,p))return q;}}if(inside(center,p))return center;for(let y=1;y<30;y++)for(let x=1;x<30;x++){const q=[minX+(maxX-minX)*x/30,minY+(maxY-minY)*y/30];if(inside(q,p))return q;}return p[0];}
// Closest boundary pair, including shared edges; reject actual overlap rather than guessing.
export function betweenPoint(a,b){
 const ringsA=regionPieces(a).flatMap(p=>p),ringsB=regionPieces(b).flatMap(p=>p);
 const projection=(p,u,v)=>{const dx=v[0]-u[0],dy=v[1]-u[1],length=dx*dx+dy*dy,t=length?Math.max(0,Math.min(1,((p[0]-u[0])*dx+(p[1]-u[1])*dy)/length)):0;return [u[0]+t*dx,u[1]+t*dy];};
 const onBoundary=(p,rings)=>rings.some(r=>r.some((u,i)=>{const q=projection(p,u,r[(i+1)%r.length]);return Math.hypot(p[0]-q[0],p[1]-q[1])<1e-9;}));
 if(ringsA.flat().some(p=>insideRegion(p,b)&&!onBoundary(p,ringsB))||ringsB.flat().some(p=>insideRegion(p,a)&&!onBoundary(p,ringsA)))return null;
 const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);let distance=Infinity,points=[];
 const consider=(p,q)=>{const d=(p[0]-q[0])**2+(p[1]-q[1])**2,m=[(p[0]+q[0])/2,(p[1]+q[1])/2];if(d<distance-1e-12){distance=d;points=[m];}else if(Math.abs(d-distance)<1e-12)points.push(m);};
 for(const ra of ringsA)for(const rb of ringsB)for(let i=0;i<ra.length;i++)for(let j=0;j<rb.length;j++){const u=ra[i],v=ra[(i+1)%ra.length],w=rb[j],z=rb[(j+1)%rb.length];if(cross(u,v,w)*cross(u,v,z)<-1e-14&&cross(w,z,u)*cross(w,z,v)<-1e-14)return null;consider(u,projection(u,w,z));consider(v,projection(v,w,z));consider(projection(w,u,v),w);consider(projection(z,u,v),z);}
 if(!points.length)return null;const point=[points.reduce((n,p)=>n+p[0],0)/points.length,points.reduce((n,p)=>n+p[1],0)/points.length];return insideRegion(point,a)&&!onBoundary(point,ringsA)||insideRegion(point,b)&&!onBoundary(point,ringsB)?null:point;
}
// Sample short offsets outside a named footprint, retaining the site outline and other fixed buildings.
export function surroundingPoint(region,regions,outline=null){
 const center=regionPoint(region),candidates=[];
 for(const polygon of regionPieces(region))for(const ring of polygon)for(let i=0;i<ring.length;i++){
  const a=ring[i],b=ring[(i+1)%ring.length],dx=b[0]-a[0],dy=b[1]-a[1],length=Math.hypot(dx,dy);if(length<1e-10)continue;
  for(const t of [.25,.5,.75])for(const side of [-1,1])for(const distance of [.008,.015,.025]){
   const q=[a[0]+dx*t-side*dy/length*distance,a[1]+dy*t+side*dx/length*distance];
   if(q.some(v=>v<0||v>1)||insideRegion(q,region)||outline?.length&&!inside(q,outline))continue;
   if(regions.some(r=>r.id!==region.id&&r.fixed&&insideRegion(q,r)))continue;
   candidates.push({point:q,score:Math.hypot(q[0]-center[0],q[1]-center[1])+distance});
  }
 }
 candidates.sort((a,b)=>a.score-b.score);return candidates[0]?.point||null;
}
export function interpret(entry,regions,outline=null,hazards=[]){
 if(typeof entry?.text!=='string'||!validDate(entry.date))throw Error('일정 원문·날짜를 확인해주세요.');
 const matches=matchRegions(entry.text,regions),relative=/사이|사잇|중간/.test(entry.text),surrounding=/주변|인근|근처/.test(entry.text),region=!relative&&matches.length===1?matches[0]:null;
 const point=relative?(matches.length===2?betweenPoint(matches[0],matches[1]):null):(region?(surrounding?surroundingPoint(region,regions,outline):regionPoint(region)):null);
 const classification=classifyWork(entry.text,entry.calendar||'',hazards);
 const reasons=[];if(!point)reasons.push(relative?'두 영역 사이의 위치 확인 필요':surrounding&&matches.length?'영역 바깥의 주변 위치 확인 필요':matches.length?'여러 영역이 언급되어 위치 확인 필요':'등록된 동·시설을 찾지 못했습니다.');
 if(/북|남|동측|서측|동쪽|서쪽/.test(entry.text))reasons.push('방향 표현은 현장 방위 확인 후 조정해주세요.');
 if(classification.riskLevel==='high')reasons.push('고위험 작업의 상하·주변 작업 확인 필요 (자동 간섭 판정 아님)');
 return {title:entry.text.replace(/\n/g,' ').slice(0,80),detail:'',date:entry.date,...classification,regionId:region?.id||null,x:point?.[0]??null,y:point?.[1]??null,original:entry.text,calendar:entry.calendar||'',placement:relative?'between':surrounding?'surrounding':'inside',reasons};
}
