import {regionPieces,regionArea} from './region-geometry.js';
import {validDate} from './calendar.js';
export const kindInfo={formwork:['갱폼','#c2410c'],rope:['로프 작업','#be185d'],tower:['타워크레인','#6d28d9'],mobile:['이동식 크레인','#7c3aed'],concrete:['타설','#0369a1'],mixer:['레미콘','#1d4ed8'],excavator:['굴착기','#b45309'],forklift:['지게차·하역','#047857'],dump:['덤프','#4d7c0f'],other:['기타','#475569']};
export function kindOf(text){return /갱폼/.test(text)?'formwork':/로프/.test(text)?'rope':/타워/.test(text)?'tower':/크레인|인양|양중/.test(text)?'mobile':/레미콘/.test(text)?'mixer':/타설|콘크리트/.test(text)?'concrete':/지게차|하역/.test(text)?'forklift':/덤프/.test(text)?'dump':/굴착|백호/.test(text)?'excavator':'other';}
function hit(text,alias){const a=alias.replace(/\s/g,'');let from=0,i;while((i=text.indexOf(a,from))!==-1){if(!(/^\d/.test(a)&&i>0&&/\d/.test(text[i-1]))&&!(/\d$/.test(a)&&/\d/.test(text[i+a.length]||'')))return true;from=i+1;}return false;}
export function matchRegions(text,regions){
 const facilities=[];const normalized=text.normalize('NFKC').replace(/(?:근린생활시설|근생)\s*(?:제\s*)?\d{1,3}(?:\s*[,、·/]\s*(?:(?:근린생활시설|근생)\s*)?(?:제\s*)?\d{1,3})*(?:\s*동)?/g,part=>{facilities.push(...[...part.matchAll(/\d+/g)].map(m=>'근생'+Number(m[0])));return ' ';});
 const facilityText=facilities.join('|');
 const ranged=normalized.replace(/(?<!\d)(\d{1,4})\s*[~〜∼-]\s*(\d{1,4})\s*동/g,(all,a,b)=>{const from=Number(a),to=Number(b);return to>=from&&to-from<=100?Array.from({length:to-from+1},(_,i)=>(from+i)+'동').join(' '):all;});
 const expanded=ranged.replace(/(?<!\d)(\d{1,4}(?:\s*[,、·/]\s*\d{1,4})+)\s*동/g,(_,list)=>list.split(/\s*[,、·/]\s*/).map(n=>n+'동').join(' '));
 const located=expanded.replace(/(?<![\d:/])(\d{1,4}(?:\s*[,、·]\s*\d{1,4})+)(\s*)([가-힣]*)/g,(all,list,space,word,offset)=>{
  if(/^(?:동|층|호|시|분|일|월|년|명|대|톤|개|미터|시간)/.test(word)||/(?:시간|시각|날짜|일자|수량|대수|인원)\s*$/.test(expanded.slice(Math.max(0,offset-12),offset)))return all;
  return list.split(/\s*[,、·]\s*/).map(n=>n+'동').join(' ')+space+word;
 });
 const clean=located.replace(/(?<=\d)\s+(?=\d)/g,'|').replace(/\s/g,'');
 const numbers=regions.map(r=>({region:r,number:r.name?.normalize('NFKC').replace(/\s/g,'').match(/^(\d{1,4})동?$/)?.[1]}));
 return regions.filter(r=>{
  const names=[r.name,...(r.aliases||[])];const number=numbers.find(n=>n.region===r)?.number;
  if(number?.length===3){const short=String(Number(number.slice(1))),exact=numbers.some(n=>n.number&&Number(n.number)===Number(short));const peers=numbers.filter(n=>n.number?.length===3&&Number(n.number.slice(1))===Number(short));if(!exact&&peers.length===1)names.push(short+'동');}
  return names.filter(a=>a?.trim()).some(a=>{const facility=a.normalize('NFKC').replace(/근린생활시설/g,'근생').replace(/\s/g,'').replace(/^근생제?/,'근생').replace(/(근생\d+)동$/,'$1');return /^근생\d+$/.test(facility)?hit(facilityText,facility):hit(clean,a);});
 });
}
export function mapCalendar(calendar=''){return !/^(?:7[.\s]*)?(?:회의[,·\s]*행사|회의[·,\s]*행사[·,\s]*대내외점검|대내외점검)/.test(calendar.normalize('NFKC').replace(/\s/g,''));}
export function interpretAll(entry,regions){
 const candidate=interpret(entry,regions);if(!mapCalendar(entry.calendar))return [];
 const matches=matchRegions(entry.text,regions);
 // Relative locations need confirmation; do not pretend the named buildings are the work location.
 if(matches.length<2||/사이|사잇|중간/.test(entry.text))return [candidate];
 return matches.map(region=>{const point=regionPoint(region);return {...candidate,regionId:region.id,x:point[0],y:point[1],reasons:candidate.reasons.filter(r=>!r.includes('여러 영역'))};});
}

export function inside(point,polygon){let yes=false;for(let i=0,j=polygon.length-1;i<polygon.length;j=i++){const a=polygon[i],b=polygon[j];if((a[1]>point[1])!==(b[1]>point[1])&&point[0]<(b[0]-a[0])*(point[1]-a[1])/(b[1]-a[1])+a[0])yes=!yes;}return yes;}
export function insideRegion(point,region){return regionPieces(region).some(p=>inside(point,p[0])&&!p.slice(1).some(hole=>inside(point,hole)));}
export function regionPoint(region,slot=0){if(region.pieces){for(const polygon of regionPieces(region)){const xs=polygon[0].map(p=>p[0]),ys=polygon[0].map(p=>p[1]);for(let step=0;step<900;step++){const x=step===0?.5:((step+slot*13)%30+.5)/30,y=step===0?.5:(Math.floor((step+slot*13)%900/30)+.5)/30,q=[Math.min(...xs)+(Math.max(...xs)-Math.min(...xs))*x,Math.min(...ys)+(Math.max(...ys)-Math.min(...ys))*y];if(inside(q,polygon[0])&&!polygon.slice(1).some(h=>inside(q,h)))return q;}}return region.points[0];}const p=region.points;const xs=p.map(a=>a[0]),ys=p.map(a=>a[1]);const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);const center=[(minX+maxX)/2,(minY+maxY)/2];if(slot>0){for(let step=0;step<50;step++){const angle=(slot+step)*2.399963;const radius=.16+(slot%3)*.09;const q=[center[0]+(maxX-minX)*radius*Math.cos(angle),center[1]+(maxY-minY)*radius*Math.sin(angle)];if(inside(q,p))return q;}}if(inside(center,p))return center;for(let y=1;y<30;y++)for(let x=1;x<30;x++){const q=[minX+(maxX-minX)*x/30,minY+(maxY-minY)*y/30];if(inside(q,p))return q;}return p[0];}
// Closest boundary pair, including shared edges; reject actual overlap rather than guessing.
export function betweenPoint(a,b){
 const ringsA=regionPieces(a).flatMap(p=>p),ringsB=regionPieces(b).flatMap(p=>p);
 const projection=(p,u,v)=>{const dx=v[0]-u[0],dy=v[1]-u[1],length=dx*dx+dy*dy,t=length?Math.max(0,Math.min(1,((p[0]-u[0])*dx+(p[1]-u[1])*dy)/length)):0;return [u[0]+t*dx,u[1]+t*dy];};
 const onBoundary=(p,rings)=>rings.some(r=>r.some((u,i)=>{const q=projection(p,u,r[(i+1)%r.length]);return Math.hypot(p[0]-q[0],p[1]-q[1])<1e-9;}));
 if(ringsA.flat().some(p=>insideRegion(p,b)&&!onBoundary(p,ringsB))||ringsB.flat().some(p=>insideRegion(p,a)&&!onBoundary(p,ringsA)))return null;
 const cross=(a,b,c)=>(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);let distance=Infinity,points=[];
 const consider=(p,q)=>{const d=(p[0]-q[0])**2+(p[1]-q[1])**2,m=[(p[0]+q[0])/2,(p[1]+q[1])/2];if(d<distance-1e-12){distance=d;points=[m];}else if(Math.abs(d-distance)<1e-12)points.push(m);};
 for(const ra of ringsA)for(const rb of ringsB)for(let i=0;i<ra.length;i++)for(let j=0;j<rb.length;j++){const u=ra[i],v=ra[(i+1)%ra.length],w=rb[j],z=rb[(j+1)%rb.length];if(cross(u,v,w)*cross(u,v,z)<-1e-14&&cross(w,z,u)*cross(w,z,v)<-1e-14)return null;consider(u,projection(u,w,z));consider(v,projection(v,w,z));consider(projection(w,u,v),w);consider(projection(z,u,v),z);}
 if(!points.length)return null;const point=[points.reduce((n,p)=>n+p[0],0)/points.length,points.reduce((n,p)=>n+p[1],0)/points.length];return insideRegion(point,a)&&!onBoundary(point,ringsA)||insideRegion(point,b)&&!onBoundary(point,ringsB)?null:point;
}
export function interpret(entry,regions){
 if(typeof entry?.text!=='string'||!validDate(entry.date))throw Error('일정 원문·날짜를 확인해주세요.');
 const matches=matchRegions(entry.text,regions),relative=/사이|사잇|중간/.test(entry.text),region=!relative&&matches.length===1?matches[0]:null;
 const point=relative?(matches.length===2?betweenPoint(matches[0],matches[1]):null):(region?regionPoint(region):null);
 const reasons=[];if(!point)reasons.push(relative?'두 영역 사이의 위치 확인 필요':matches.length?'여러 영역이 언급되어 위치 확인 필요':'등록된 동·시설을 찾지 못했습니다.');
 if(/북|남|동측|서측|동쪽|서쪽/.test(entry.text))reasons.push('방향 표현은 현장 방위 확인 후 조정해주세요.');
 if(/갱폼|로프|고소|해체|인양|밀폐|화기/.test(entry.text))reasons.push('고위험 작업의 상하·주변 작업 확인 필요 (자동 간섭 판정 아님)');
 return {title:entry.text.replace(/\n/g,' ').slice(0,80),detail:'',date:entry.date,icon:kindOf(entry.text),regionId:region?.id||null,x:point?.[0]??null,y:point?.[1]??null,original:entry.text,calendar:entry.calendar||'',reasons};
}
