import {createHash,randomBytes} from 'node:crypto';
import {validDate} from './public/calendar.js';
import {interpretAll,regionPoint,placementVersion,excludedSchedule} from './public/interpret.js';
const text=(v,max=300)=>typeof v==='string'?v.trim().slice(0,max):typeof v==='number'&&Number.isFinite(v)?String(v):'';
const first=(o,keys)=>keys.map(k=>o?.[k]).find(v=>v!==undefined&&v!==null&&v!=='');
export function scheduleDate(v){
 if(v&&typeof v==='object')v=first(v,['date','dateTime','datetime','startDate','value']);
 if((typeof v==='number'||typeof v==='string'&&/^\d{10,13}$/.test(v))&&Number(v)>=1e9){const date=new Date(Number(v)*(Number(v)<1e11?1000:1));if(!Number.isFinite(+date))return null;return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);}
 const s=text(v,80);const m=s.match(/^(\d{4})-?(\d{2})-?(\d{2})(?:$|[T\s])/);if(!m)return null;
 const d=m.slice(1).join('-');if(!validDate(d))return null;
 if(/[T\s]\d{2}:\d{2}.*(?:Z|[+-]\d{2}:?\d{2})$/.test(s)){const date=new Date(s);if(!Number.isFinite(+date))return null;return new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);}
 return d;
}
// Only known schedule fields are retained. Credentials, URLs and arbitrary JSON never leave the helper.
export function extractSchedules(payload){
 const events=[],seen=new Set();let visited=0,unscoped=0;
 function walk(value,context={},depth=0){
  if(!value||typeof value!=='object'||depth>12||++visited>30000)return;
  if(Array.isArray(value)){for(const item of value.slice(0,2000))walk(item,context,depth+1);return;}
  const calendarId=text(first(value,['calendarId','calendarUid','calendarNo','calendarID','calendarUniqueId','calId','calNo'])??value.calendar?.id??context.id,120);
  const calendarName=text(first(value,['calendarName','calendarTitle'])??value.calendar?.name??context.name,100);
  const title=text(first(value,['summary','subject','title','eventTitle','scheduleTitle','scheduleName','eventName']));
  const date=scheduleDate(first(value,['start','startDateTime','startDatetime','startDate','beginDate','dtstart','startTime','startDt','startYmd']));
  const id=text(first(value,['eventId','scheduleId','eventUid','scheduleNo','eventNo','icalUid','uid','id']),120);
  if(title&&date&&id){
   if(!calendarId)unscoped++;
   else{
    const dates=[date];
    if(value.icalUid){
     const ranges=Array.isArray(value.repeatDateList)&&value.repeatDateList.length?value.repeatDateList.slice(0,366):[value];dates.length=0;
     for(const range of ranges){const from=scheduleDate(range.startDate),until=scheduleDate(range.endDate)||from;if(!from||!until||until<from)continue;
      for(let day=from,n=0;day<=until&&n<366;n++){dates.push(day);const next=new Date(day+'T00:00:00Z');next.setUTCDate(next.getUTCDate()+1);day=next.toISOString().slice(0,10);}
     }
    }
    for(const day of dates){const key=JSON.stringify([calendarId,id,day]);if(!seen.has(key)&&events.length<2000){seen.add(key);events.push({id,calendarId,calendarName:calendarName||calendarId,title,date:day,description:text(first(value,['description','detail','memo']),800),cancelled:value.cancelled===true||value.isCancelled===true||value.deleted===true||value.isDeleted===true||/^(cancelled|canceled|cancel|deleted|delete|removed)$/i.test(text(value.status,30))});}}
   }
  }
  for(const [key,item] of Object.entries(value)){if(/token|cookie|password|secret|auth|session|headers/i.test(key))continue;if(item&&typeof item==='object')walk(item,{id:calendarId,name:calendarName},depth+1);}
 }
 walk(payload);
 // scheduleViewList omits calendar names. Recover only a consistent numbered classification
 // from titles within the same calendar; mixed or unnumbered groups retain their ID.
 const names={1:'1. 타설 작업',2:'2. 갱폼 작업',3:'3. 고위험작업',4:'4. 장비작업',5:'5. 비정상작업',6:'6. 자재상하차',7:'7. 회의, 행사, 대내외점검'};
 for(const group of Map.groupBy(events,e=>e.calendarId).values()){const numbered=new Set(group.map(e=>e.title.match(/^([1-7])\.\s*/)?.[1]).filter(Boolean));if(numbered.size===1){const name=names[[...numbered][0]];for(const event of group)if(event.calendarName===event.calendarId)event.calendarName=name;}}
 return {events,unscoped};
}
export const networkSourceId=(path,method,calendarId)=>createHash('sha256').update(JSON.stringify([path,method,calendarId])).digest('hex').slice(0,20);
export function mergeNetworkSchedules(room,events,site,scope){
 if(!scope||!validDate(scope.date)||!Array.isArray(events)||events.length>2000)throw Error('자동 수집 범위를 확인해주세요.');
 let added=0,updated=0,skipped=0,removed=0;
 const selected=events.filter(e=>e.calendarId===scope.calendarId&&e.date===scope.date&&text(e.id,120)&&text(e.title));
 const hash=value=>createHash('sha256').update(JSON.stringify(value)).digest('hex');
 const names=new Set(selected.map(e=>e.calendarName));room.tasks=room.tasks.filter(t=>{const drop=t.sourceKey&&!t.manuallyPlaced&&t.date===scope.date&&names.has(t.calendar)&&excludedSchedule(t);if(drop)removed++;return !drop;});
 const plans=selected.map(event=>{const base=hash(['works-network',event.calendarId,event.id,event.date]),legacy=hash(['works-network',event.calendarId,event.id]),original=(event.title+'\n'+(event.description||'')).trim().slice(0,1200),candidates=event.cancelled?[]:interpretAll({text:original,date:event.date,calendar:event.calendarName},site.regions,site.outline,site.hazards);return {event,base,legacy,candidates,keys:candidates.map(c=>candidates.length===1?base:hash([base,c.regionId]))};});
 const belongs=(t,p)=>t.date===scope.date&&(t.sourceEventKey===p.base||t.sourceKey===p.base||t.sourceKey===p.legacy||p.keys.includes(t.sourceKey));
 // Only a successfully read complete day/range may remove missing appointments.
 // Hand-entered work, other calendars and dates outside that range are untouched.
 if(scope.replaceMissing){const keep=new Set(plans.filter(p=>p.candidates.length).flatMap(p=>[p.base,p.legacy,...p.keys]));room.tasks=room.tasks.filter(t=>{const drop=t.date===scope.date&&t.sourceKey&&t.networkCalendarId===scope.calendarId&&!keep.has(t.sourceEventKey||t.sourceKey)&&!keep.has(t.sourceKey);if(drop)removed++;return !drop;});}
 for(const plan of plans){
  const {event,base,legacy,candidates,keys}=plan,fingerprint=hash(event),previous=room.tasks.filter(t=>belongs(t,plan)),used=new Set();
  for(let index=0;index<candidates.length;index++){
   const candidate=candidates[index],key=keys[index];
   const old=previous.find(t=>!used.has(t)&&t.regionId===candidate.regionId)||previous.find(t=>!used.has(t)&&t.sourceKey===key)||previous.find(t=>!used.has(t));
   if(old)used.add(old);
   if(old?.networkVersion===fingerprint&&old.placementSiteRevision===(site.revision||0)&&old.placementVersion===placementVersion&&old.sourceKey===key&&old.sourceEventKey===base){skipped++;continue;}
   if(!old&&room.tasks.length>=2000){skipped++;continue;}
   candidate.title=event.title.slice(0,80);candidate.detail=(event.description||'').slice(0,180);
   const metadata={networkCalendarId:event.calendarId,networkVersion:fingerprint,networkCancelled:false,sourceKey:key,sourceEventKey:base,placementSiteRevision:site.revision||0,placementVersion};
   if(old){
    const geometry={x:old.x,y:old.y,regionId:old.regionId};Object.assign(old,candidate,metadata);
    if(old.manuallyPlaced||old.shape!=='point'){Object.assign(old,geometry);old.reasons=old.reasons.filter(s=>!s.includes('동·시설')&&!s.includes('여러 영역')&&!s.includes('위치 확인 필요'));}
    updated++;
   }else{
    if(candidate.regionId&&candidate.placement==='inside'){const r=site.regions.find(r=>r.id===candidate.regionId);const p=regionPoint(r,room.tasks.filter(t=>t.regionId===r.id).length);candidate.x=p[0];candidate.y=p[1];}
    room.tasks.push({...candidate,id:randomBytes(6).toString('hex'),equipment:'웍스 일정',shape:'point',points:[],...metadata});added++;
   }
  }
  const stale=new Set(previous.filter(t=>!used.has(t)));if(stale.size){room.tasks=room.tasks.filter(t=>!stale.has(t));removed+=stale.size;}
 }
 return {added,updated,skipped,removed};
}
