// A deliberate click captures one visible appointment, never the whole account/calendar database.
export const captureExpression=`(()=>{
 if(location.hostname!=='calendar.worksmobile.com')throw Error('Calendar only');
 if(window.__mouseonCalendarCapture?.handler)return {ok:true};
 const state=window.__mouseonCalendarCapture||{items:[]};
 const banner=document.createElement('div');banner.id='mouseon-calendar-banner';
 Object.assign(banner.style,{position:'fixed',bottom:'16px',left:'50%',transform:'translateX(-50%)',zIndex:'2147483647',background:'#153f33',color:'#fff',padding:'14px 22px',borderRadius:'9px',font:'14px sans-serif'});
 banner.textContent='MouseOn 읽기 시험 · 가져올 일정 제목을 클릭하세요. 일정은 수정하지 않습니다. ';const exit=document.createElement('button');exit.textContent='선택 종료';banner.append(exit);document.body.append(banner);
 state.handler=e=>{
  if(banner.contains(e.target))return;
  if(e.target.closest('input,textarea,[contenteditable=true]'))return;
  e.preventDefault();e.stopImmediatePropagation();
  const leaf=(e.target.innerText||e.target.textContent||'').trim();
  if(!leaf||leaf.length>1200){banner.firstChild.textContent='일정 제목의 글자를 눌러주세요. ';return;}
  const candidate=e.composedPath().find(n=>n instanceof HTMLElement && /event|schedule|appointment/i.test(n.className||'') && n.innerText?.trim().length<=1200);
  const text=(candidate?.innerText||leaf).trim();
  if(state.items.length>=50){banner.firstChild.textContent='최대 50개까지 선택할 수 있습니다. ';return;}
  if(!state.items.some(x=>x.text===text))state.items.push({text});
  banner.firstChild.textContent=state.items.length+'개 선택됨 · 미리보기 화면에서 내용을 확인하세요. ';
 };
 exit.onclick=()=>{document.removeEventListener('click',state.handler,true);state.handler=null;banner.remove();};
 document.addEventListener('click',state.handler,true);window.__mouseonCalendarCapture=state;return {ok:true};
})()`;

export const worksReadErrors={
 WORKS_DATE_MISMATCH:'선택한 날짜를 화면에서 확인하지 못했습니다. 웍스를 하루 보기로 열고 앱과 같은 날짜를 선택해주세요.',
 WORKS_NO_EVENT_ELEMENTS:'현재 화면에서 일정 요소를 찾지 못했습니다. 화면 구조 진단 파일을 보내주시면 실제 태그에 맞춰 수집기를 수정할 수 있습니다. 기존 작업은 삭제하지 않습니다.',
 WORKS_LOGIN_REQUIRED:'로그인 후 캘린더 본문을 열어주세요. 로그인 화면에서는 일정을 읽지 않습니다.',
 WORKS_WRONG_HOST:'연동용 브라우저에서 calendar.worksmobile.com 캘린더를 열어주세요.',
 WORKS_SCRIPT_ERROR:'일정 읽기 스크립트 실행 중 오류가 발생했습니다. 화면 구조 진단을 진행해주세요.'
};
function collectBatch(requestedDate,calendar,root=document,verifiedDate=false){
 const fail=code=>({readError:{code}});
 try{
  if(location.hostname!=='calendar.worksmobile.com')return fail('WORKS_WRONG_HOST');
  if(/login/i.test(location.pathname)||[...root.querySelectorAll('input[type=password]')].some(n=>n.getBoundingClientRect().width&&n.getBoundingClientRect().height))return fail('WORKS_LOGIN_REQUIRED');
  const parts=requestedDate.split('-').map(Number);
  const headings=[...root.querySelectorAll('.date_navigation .date_cover .date,h1,h2,h3,[role=heading],time')].filter(n=>n.getBoundingClientRect().width&&n.getBoundingClientRect().height).map(n=>n.innerText||n.getAttribute('datetime')||'');
  const displayed=[...headings,(root.body.innerText||'').slice(0,3000)].join(' ');
  const matches=[...displayed.matchAll(/(\d{4})\s*[.년/\-]\s*(\d{1,2})\s*[.월/\-]\s*(\d{1,2})(?!\d)/g)];
  if(!verifiedDate&&!matches.some(m=>parts.every((v,i)=>v===Number(m[i+1]))))return fail('WORKS_DATE_MISMATCH');
  const selectors=['[data-event-id]','[data-schedule-id]','.fc-event','.calendar-event','.schedule-item','[class*=event_item]','[class*=eventItem]','[class*=schedule_item]'];
  const workTitles=[...root.querySelectorAll('a.sch_title')].filter(n=>n.getBoundingClientRect().width>0&&n.getBoundingClientRect().height>0);
  const candidates=(workTitles.length?workTitles:[...new Set(selectors.flatMap(s=>[...root.querySelectorAll(s)]))]).filter(n=>{const r=n.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(n).visibility!=='hidden';});
  const leaves=candidates.filter(n=>!candidates.some(other=>other!==n&&n.contains(other)));const items=[],seen=new Set();
  for(const n of leaves){const text=(n.innerText||n.getAttribute('title')||'').trim();if(!text||text.length>1200)continue;const calendarName=n.getAttribute('data-calendar-name');if(calendar!=='화면에 표시된 일정'&&calendarName&&calendarName!==calendar)continue;const start=n.getAttribute('data-start')||n.getAttribute('data-date');if(start&&start.slice(0,10)!==requestedDate)continue;const sourceId=n.getAttribute('data-event-id')||n.getAttribute('data-schedule-id')||null,signature=sourceId||text;if(seen.has(signature))continue;seen.add(signature);const categories={1:'1. 타설 작업',2:'2. 갱폼 작업',3:'3. 고위험작업',4:'4. 장비작업',5:'5. 비정상작업',6:'6. 자재상하차',7:'7. 회의, 행사, 대내외점검'},prefix=text.match(/^([1-7])\.\s*/)?.[1],category=calendar==='화면에 표시된 일정'?(calendarName||categories[prefix]||calendar):calendar;items.push({text,date:requestedDate,calendar:category,sourceId});if(items.length>=200)break;}
  if(!items.length)return fail('WORKS_NO_EVENT_ELEMENTS');
  return {format:'mouseon-works-preview/v1',entries:items,truncated:items.length>=200,coverage:'visible-only',warnings:['현재 화면에 로드된 일정만 읽었습니다. 캘린더 선택과 누락 여부를 확인하세요. 전체 수집·수정·취소 동기화는 아직 검증 전입니다.']};
 }catch{return fail('WORKS_SCRIPT_ERROR');}
}
export function batchExpression(date,calendar){return `(${collectBatch.toString()})(${JSON.stringify(date)},${JSON.stringify(calendar)})`;}
export function decodePageResult(result){
 if(result.exceptionDetails){const name=result.exceptionDetails.exception?.className;const category=['SyntaxError','TypeError','ReferenceError','EvalError','SecurityError'].includes(name)?name:'ScriptError';throw Error('[WORKS_EVALUATION_FAILED] '+category+' · 브라우저가 화면 읽기 코드를 실행하지 못했습니다. 진단 영역 지정도 같은 오류가 나는지 확인해주세요.');}
 const value=result.result?.value;
 if(value?.readError){const code=Object.hasOwn(worksReadErrors,value.readError.code)?value.readError.code:'WORKS_SCRIPT_ERROR';throw Error('['+code+'] '+worksReadErrors[code]);}
 if(value?.diagnosticError)throw Error(value.diagnosticError);
 return value;
}

// Reads only the displayed calendar day. Navigation uses the calendar's own date controls.
async function navigateAndRead(requestedDate,collect){
 const fail=code=>({readError:{code}}),pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
 if(location.hostname!=='calendar.worksmobile.com')return fail('WORKS_WRONG_HOST');
 function documents(){const out=[document];for(let i=0;i<out.length&&out.length<8;i++)for(const frame of out[i].querySelectorAll('iframe,frame'))try{const doc=frame.contentDocument;if(doc&&frame.contentWindow.location.hostname==='calendar.worksmobile.com'&&!out.includes(doc))out.push(doc);}catch{}return out;}
 const visible=n=>Boolean(n.getBoundingClientRect().width&&n.getBoundingClientRect().height)&&getComputedStyle(n).visibility!=='hidden';
 function day(doc){for(const node of doc.querySelectorAll('.date_navigation .date_cover .date,h1,h2,h3,[role=heading],time')){if(!visible(node))continue;const match=(node.innerText||node.getAttribute('datetime')||'').match(/(\d{4})\s*[.년/\-]\s*(\d{1,2})\s*[.월/\-]\s*(\d{1,2})(?!\d)/);if(match)return match.slice(1).map((v,i)=>i?v.padStart(2,'0'):v).join('-');}return null;}
 let navigated=false;for(let step=0;step<15;step++){
  const docs=documents();if(docs.some(doc=>[...doc.querySelectorAll('input[type=password]')].some(visible)))return fail('WORKS_LOGIN_REQUIRED');
  let dated=docs.map(doc=>({doc,date:day(doc)})).find(item=>item.date);
  if(!dated){if(step===0){const daily=docs.flatMap(doc=>[...doc.querySelectorAll('button,[role=tab],a')]).find(node=>visible(node)&&node.textContent.trim()==='일간');daily?.click();}await pause(150);continue;}
  if(dated.date!==requestedDate){
   const delta=(Date.parse(requestedDate+'T00:00:00Z')-Date.parse(dated.date+'T00:00:00Z'))/86400000;if(!Number.isFinite(delta)||Math.abs(delta)>14)return fail('WORKS_DATE_MISMATCH');
   const button=dated.doc.querySelector(delta>0?'.date_navigation .btn_next':'.date_navigation .btn_prev');if(!button)return fail('WORKS_DATE_MISMATCH');if(button.disabled){await pause(150);continue;}const previous=dated.date;button.click();navigated=true;for(let i=0;i<6&&day(dated.doc)===previous;i++)await pause(80);continue;
  }
  if(navigated){await pause(500);navigated=false;continue;}if(docs.some(doc=>[...doc.querySelectorAll('[aria-busy=true],.loading_layer,.calendar_loading')].some(visible))){await pause(150);continue;}
  const entries=[],seen=new Set();let truncated=false;
  for(const doc of docs){const own=day(doc);if(own&&own!==requestedDate)continue;const result=collect(requestedDate,'화면에 표시된 일정',doc,true);if(result.readError?.code==='WORKS_LOGIN_REQUIRED')return result;truncated ||= result.truncated===true;for(const entry of result.entries||[]){const key=JSON.stringify([entry.calendar,entry.sourceId||entry.text]);if(!seen.has(key)){seen.add(key);entries.push(entry);}}}
  // Wait for asynchronous day navigation to finish rendering its appointments.
  if(entries.length)return {format:'mouseon-works-preview/v1',entries,coverage:truncated?'visible-only':'displayed-day',date:requestedDate,warnings:['로그인된 캘린더 화면에 로드된 해당 날짜 일정만 읽었습니다.']};
  const empty=docs.some(doc=>[...doc.querySelectorAll('.no_schedule,.no_event,.calendar_empty,[data-calendar-empty]')].some(node=>visible(node)&&/일정.*없|등록된.*없/.test(node.textContent)));
  if(empty&&step>=3)return {format:'mouseon-works-preview/v1',entries:[],coverage:'displayed-day',date:requestedDate,emptyConfirmed:true,warnings:[]};
  await pause(150);
 }
 return fail('WORKS_NO_EVENT_ELEMENTS');
}
export function automaticBatchExpression(date){return `(${navigateAndRead.toString()})(${JSON.stringify(date)},(${collectBatch.toString()}))`;}
