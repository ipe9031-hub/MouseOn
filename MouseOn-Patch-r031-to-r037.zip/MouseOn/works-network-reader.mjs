import {createHash} from 'node:crypto';
import {extractSchedules,networkSourceId,scheduleDate} from './works-network.mjs';
import {validDate} from './public/calendar.js';
const HOST='calendar.worksmobile.com';
const allowed=url=>{try{const u=new URL(url);return u.protocol==='https:'&&u.hostname===HOST&&!u.username&&!u.password;}catch{return false;}};
const serviceAllowed=url=>{try{const u=new URL(url);return u.protocol==='https:'&&/(^|\.)(worksmobile\.com|naverworks\.com)$/.test(u.hostname)&&!u.username&&!u.password;}catch{return false;}};
export function createNetworkReader({now=()=>Date.now(),setTimer=setInterval,clearTimer=clearInterval,readVisible=null}={}){
 const screenId='screen-calendar',groupId='site-work-calendars';let desiredDate=null,visibleBusy=false,visibleDue=0,visibleError='',visibleInterval=60;
 let session=null,unsubscribe=null,timer=null,timeout=null,running=false,phase='stopped',message='',scope=null,generation=0,lastRead=null,waiting=false,scopeAfter=0;
 const sources=new Map(),pending=new Map(),schemaKeys=new Set(),responseHosts=new Map();let requests=0,responses=0,bodyFailures=0;let jsonResponses=0,unscopedEvents=0,requestSequence=0;
 function inspectKeys(v,depth=0){if(!v||typeof v!=='object'||depth>6||schemaKeys.size>=100)return;if(Array.isArray(v)){if(v.length)inspectKeys(v[0],depth+1);return;}for(const [k,item]of Object.entries(v)){if(/token|cookie|password|secret|auth|session|headers/i.test(k))continue;if(/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(k))schemaKeys.add(k);inspectKeys(item,depth+1);}}
 function siteGroup(ids=null){
  const candidates=[...sources.values()].filter(source=>source.id!==screenId&&(ids?ids.includes(source.calendarId):/^[1-6]\s*[.．]|^(?:타설|갱폼|고위험|장비작업|비정상|자재상하차|조출|야간)/.test(source.calendarName)));
  if(!candidates.length)return null;const seen=new Set(),events=[];
  for(const source of candidates)for(const event of source.events){const key=JSON.stringify([event.calendarId,event.id,event.date]);if(!seen.has(key)){seen.add(key);events.push(event);}}
  return {id:groupId,method:'GROUP',calendarId:groupId,calendarName:'조회된 현장 작업 일정 전체',calendarIds:[...new Set(candidates.map(source=>source.calendarId))],events,coverage:candidates.flatMap(source=>source.coverage||[]),receivedAt:Math.max(...candidates.map(source=>source.receivedAt||0))};
 }
 function selectedSource(){return scope?.sourceId===groupId?siteGroup(scope.calendarIds):sources.get(scope?.sourceId);}
 function shownSources(){
  if(scope?.sourceId===groupId){const group=siteGroup(scope.calendarIds);return group?[group]:[];}
  if(sources.has(screenId)&&(!scope||scope.sourceId===screenId))return [sources.get(screenId)];
  if(!scope){const group=siteGroup();if(group)return [group];}
  return [...sources.values()];
 }
 function status(){return {phase,message,autoGroupCalendars:true,canReadScreen:Boolean(readVisible),refreshing:waiting,diagnostic:{requests,responses,bodyFailures,hosts:[...responseHosts.values()],jsonResponses,unscopedEvents,schemaKeys:[...schemaKeys].sort()},automatic:Boolean(timer),scope,generation,lastRead,sources:shownSources().map(s=>({id:s.id,method:s.method,calendarId:s.calendarId,calendarName:s.calendarName,count:s.events.length,coverage:s.coverage||[],dates:s.dates||[...new Set(s.events.map(e=>e.date))].sort()})),snapshot:scope&&lastRead&&phase!=='login'?{generation,at:lastRead,scope,coverage:selectedSource()?.coverage||[],events:(selectedSource()?.events||[]).filter(e=>scope.includeFuture?e.date>=scope.date:e.date===scope.date)}:null};}

 async function stop(){if(timer)clearTimer(timer);timer=null;clearTimeout(timeout);timeout=null;waiting=false;unsubscribe?.();unsubscribe=null;const previous=session;session=null;if(previous)try{await previous.close();}catch{}sources.clear();pending.clear();scope=null;lastRead=null;desiredDate=null;visibleDue=0;visibleError='';phase='stopped';message='자동 수집을 중지했습니다.';return status();}
 function accept(request,payload){
  jsonResponses++;inspectKeys(payload);const parsed=extractSchedules(payload);unscopedEvents+=parsed.unscoped;const groups=Map.groupBy(parsed.events,e=>e.calendarId);
  // Only the known complete schedule-list response with an explicit requested range is authoritative.
  const complete=request.path==='/api/scheduleViewList'&&request.from&&request.until&&Array.isArray(payload)&&payload.length<=2000&&parsed.events.length<2000&&parsed.unscoped===0&&payload.every(e=>e&&typeof e==='object'&&e.calendarId&&(e.icalUid||e.eventId||e.scheduleId)&&(e.summary||e.title)&&scheduleDate(e.startDate||e.start));
  if(complete)for(const source of sources.values())if(source.method===request.method&&source.path===request.path&&!groups.has(source.calendarId))groups.set(source.calendarId,[]);
  let refreshed=false;
  for(const [calendarId,incoming] of groups){
   if(sources.size>=30&&!sources.has(networkSourceId(request.path,request.method,calendarId)))continue;
   const id=networkSourceId(request.path,request.method,calendarId),previous=sources.get(id);if((previous?.sequence||0)>request.sequence)continue;
   const events=complete?[...(previous?.events||[]).filter(e=>e.date<request.from||e.date>request.until),...incoming]:incoming;
   const source={id,path:request.path,method:request.method,calendarId,calendarName:incoming[0]?.calendarName||previous?.calendarName||calendarId,sequence:request.sequence,receivedAt:now(),events,coverage:complete?[{calendarId,from:request.from,until:request.until}]:[]};sources.set(id,source);
   if((scope?.sourceId===id||scope?.sourceId===groupId&&scope.calendarIds.includes(calendarId))&&request.sequence>scopeAfter&&(complete?request.until>=scope.date&&(scope.includeFuture||request.from<=scope.date):events.some(e=>scope.includeFuture?e.date>=scope.date:e.date===scope.date)))refreshed=true;
  }
  if(refreshed){generation++;lastRead=now();waiting=false;clearTimeout(timeout);timeout=null;phase='collecting';message='선택한 캘린더의 일정 데이터를 갱신했습니다.';}
  if(!scope&&sources.size){waiting=false;clearTimeout(timeout);timeout=null;phase='choose';message='일정 데이터가 확인됐습니다. 현장 캘린더와 날짜를 선택해주세요.';}
  else if(!sources.size){phase='waiting';message='일정 데이터 응답을 확인하고 있습니다.';}
 }
 async function receive(event){
  const {method,params:p}=event;
  if(method==='Network.responseReceived'){
   if(!['XHR','Fetch'].includes(p.type))return;responses++;try{const host=new URL(p.response.url).hostname,key=host+'|'+p.response.mimeType+'|'+p.response.status;const old=responseHosts.get(key);if(old)old.count++;else if(responseHosts.size<20)responseHosts.set(key,{host,mime:p.response.mimeType,status:p.response.status,count:1});}catch{}if(!serviceAllowed(p.response?.url))return;
   const tracked=pending.get(p.requestId),calendarRequest=tracked&&(/schedule|calendar|event/i.test(tracked.path)||scope&&networkSourceId(tracked.path,tracked.method,scope.calendarId)===scope.sourceId);
   if(scope?.sourceId!==screenId&&[401,403].includes(p.response.status)&&calendarRequest){if(timer)clearTimer(timer);timer=null;waiting=true;phase='login';message='일정 접근 인증을 확인해주세요. 자동 반영을 중단했습니다.';return;}
   if(p.response.status!==200||!/json|text\/plain|javascript/i.test(p.response.mimeType||''))return;
   const previous=pending.get(p.requestId);if(!previous)return;
   previous.response=true;return;
  }
  if(method==='Network.requestWillBeSent'){
   if(!['XHR','Fetch'].includes(p.type))return;requests++;if(!serviceAllowed(p.request?.url)||!['GET','POST'].includes(p.request.method)||!allowed(p.documentURL))return;
   if(pending.size>=100)pending.delete(pending.keys().next().value);
   const url=new URL(p.request.url),params=new URLSearchParams(url.search);let body={};try{body=JSON.parse(p.request.postData||'{}');}catch{body=Object.fromEntries(new URLSearchParams(p.request.postData||''));}
   const from=String(body.viewFrom||params.get('viewFrom')||'').slice(0,10),end=String(body.viewUntil||params.get('viewUntil')||''),untilDate=end.slice(0,10);let until=untilDate;
   if(validDate(untilDate)&&/^[T ]00:00(?::00)?$/.test(end.slice(10))){const d=new Date(untilDate+'T00:00:00Z');d.setUTCDate(d.getUTCDate()-1);until=d.toISOString().slice(0,10);}
   pending.set(p.requestId,{method:p.request.method,path:url.pathname,...(validDate(from)&&validDate(until)&&from<=until?{from,until}:{}),response:false,at:now(),sequence:++requestSequence});return;
  }
  if(method==='Network.loadingFailed'){pending.delete(p.requestId);return;}
  if(method!=='Network.loadingFinished')return;
  const request=pending.get(p.requestId);pending.delete(p.requestId);
  if(!request?.response||now()-request.at>30000||p.encodedDataLength>2*1024*1024||!session)return;
  const current=session;
  try{
   const result=await current.call('Network.getResponseBody',{requestId:p.requestId});
   if(current!==session)return;
   const raw=result.base64Encoded?Buffer.from(result.body,'base64').toString('utf8'):result.body;
   if(typeof raw!=='string'||Buffer.byteLength(raw)>2*1024*1024)return;
   accept(request,JSON.parse(raw.replace(/^\)\]\}\',?\s*/,'')));
  }catch{bodyFailures++;if(current===session&&!sources.size){phase='waiting';message='일정 응답이 아직 확인되지 않았습니다. 로그인·캘린더 선택을 확인해주세요.';}}
 }
 async function reload(){
  if(!session||running)return;running=true;const current=session;
  try{
   let location;try{location=await current.evaluate('location.href');}catch{return;}if(typeof location!=='string'||location==='about:blank')return;
   if(!allowed(location)||!new URL(location).pathname.startsWith('/web/calendar/'))throw Error('login');
   waiting=true;phase=scope?'collecting':'waiting';message='일정 데이터 응답을 기다리고 있습니다.';clearTimeout(timeout);
   timeout=setTimeout(()=>{if(session===current&&waiting){phase=!sources.size&&jsonResponses?'unsupported':'unconfirmed';message='요청 '+requests+'개 · 응답 '+responses+'개 · JSON '+jsonResponses+'개: 일정 데이터가 확인되지 않았습니다. 기존 작업은 유지합니다. 통신 구조 진단을 저장해주세요.';}},15000);timeout.unref?.();
   pending.clear();await current.call('Page.reload',{ignoreCache:true});
  }catch{
   if(session!==current)return;if(timer)clearTimer(timer);timer=null;waiting=true;phase='login';message='연동 브라우저의 로그인 상태를 확인해주세요. 자동 반영을 중단했습니다.';
  }finally{running=false;}
 }

 async function fallback(date=desiredDate,force=false){
  if(!readVisible||!session||!validDate(date)||visibleBusy||!force&&(scope?.sourceId===screenId||now()<visibleDue))return status();
  if(!force&&scope&&scope.sourceId!==screenId&&!['unsupported','unconfirmed'].includes(phase))return status();
  visibleBusy=true;visibleDue=now()+4000;const current=session;
  try{
   const result=await readVisible(current,date);if(current!==session)return status();
   if(!Array.isArray(result?.entries)||!result.entries.length&&!(result.coverage==='displayed-day'&&result.date===date&&result.emptyConfirmed))throw Error('캘린더 화면에서 읽을 일정을 찾지 못했습니다.');
   const events=result.entries.filter(e=>e.date===date&&typeof e.text==='string'&&e.text.trim()).map(e=>({id:e.sourceId||createHash('sha256').update(JSON.stringify([e.calendar,e.text])).digest('hex'),calendarId:screenId,calendarName:e.calendar||'화면에 표시된 일정',title:e.text.slice(0,300),date,description:'',cancelled:false}));
   if(!events.length&&!result.emptyConfirmed)throw Error('선택한 날짜의 일정이 화면에 로드되지 않았습니다.');
   sources.set(screenId,{id:screenId,method:'SCREEN',calendarId:screenId,calendarName:'현재 캘린더 화면',receivedAt:now(),dates:[date],events,coverage:result.coverage==='displayed-day'&&result.date===date?[{calendarId:screenId,from:date,until:date}]:[]});visibleError='';waiting=false;clearTimeout(timeout);timeout=null;
   if(scope){const wasScreen=scope.sourceId===screenId;if(!wasScreen&&timer){clearTimer(timer);timer=null;}scope={sourceId:screenId,calendarId:screenId,calendarName:'현재 캘린더 화면',date};generation++;lastRead=now();phase='collecting';if(!timer){timer=setTimer(()=>{void refreshVisible();},visibleInterval*1000);timer.unref?.();}}
   else phase='choose';message='캘린더 화면에서 '+events.length+'개 일정을 읽었습니다.';
  }catch(error){
   if(current===session){visibleError=error.message;if(/WORKS_LOGIN_REQUIRED|WORKS_WRONG_HOST/.test(visibleError)){if(timer)clearTimer(timer);timer=null;phase='login';message=visibleError;}else if(force||['unsupported','unconfirmed'].includes(phase)){message=visibleError;if(scope)phase='unconfirmed';}}
  }finally{visibleBusy=false;}
  return status();
 }
 async function refreshVisible(){
  if(!session||visibleBusy)return;const current=session;try{await current.call('Page.reload',{ignoreCache:true});}catch{phase='login';message='로그인된 캘린더 창을 다시 열어주세요.';return;}
  await fallback(scope?.date||desiredDate,true);
 }
 return {
  status,fallback,
  async start(newSession,input={}){await stop();session=newSession;desiredDate=validDate(input.date)?input.date:null;generation=0;requests=responses=bodyFailures=0;responseHosts.clear();jsonResponses=0;unscopedEvents=0;schemaKeys.clear();phase='waiting';message='일정 데이터 통신을 찾고 있습니다.';unsubscribe=session.subscribe(event=>{void receive(event);});try{await session.call('Network.enable',{maxTotalBufferSize:4*1024*1024,maxResourceBufferSize:2*1024*1024});await reload();if(desiredDate)await fallback(desiredDate,true);return status();}catch(error){if(readVisible&&desiredDate){const result=await fallback(desiredDate,true);if(result.sources.length)return result;}await stop();throw Error('일정 통신 관찰을 시작하지 못했습니다.');}},
  async select(input){
   let source=input.sourceId===groupId?siteGroup(scope?.sourceId===groupId?scope.calendarIds:null):sources.get(input.sourceId);if(source?.id===screenId){await fallback(input.date,true);if(visibleError)throw Error(visibleError);source=sources.get(screenId);}if(!source||!validDate(input.date)||!source.events.some(e=>e.date===input.date)&&!(source.coverage||[]).some(c=>c.from<=input.date&&c.until>=input.date))throw Error('수집된 캘린더와 일정이 있는 날짜를 선택해주세요.');
   const seconds=Number(input.intervalSeconds||60);if(![30,60,120,300].includes(seconds))throw Error('수집 간격을 확인해주세요.');
   if(timer)clearTimer(timer);scopeAfter=requestSequence;scope={sourceId:source.id,calendarId:source.calendarId,calendarName:source.calendarName,date:input.date,...(source.calendarIds?{calendarIds:source.calendarIds}:{}),...(input.includeFuture?{includeFuture:true}:{})};generation++;lastRead=source.receivedAt||now();waiting=source.id!==screenId;clearTimeout(timeout);timeout=null;
   visibleInterval=seconds;desiredDate=input.date;timer=setTimer(()=>{void (source.id===screenId?refreshVisible():reload());},seconds*1000);timer.unref?.();phase='collecting';message=source.id===screenId?'캘린더 화면의 작업을 자동으로 읽어 반영합니다.':'선택한 현장 캘린더의 일정 데이터를 자동으로 수집합니다.';if(source.id!==screenId)await reload();return status();
  },reload,stop
 };
}
