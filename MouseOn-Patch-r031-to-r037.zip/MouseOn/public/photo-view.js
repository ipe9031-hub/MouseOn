// All picture surfaces use the same viewport-based 100% scale.
export function photoFrame(view,image,zoom=1){
 const ratio=(image.naturalWidth||16)/(image.naturalHeight||10);
 const width=Math.max(1,view.width,view.height*ratio)*zoom;
 return {width,height:width/ratio,ratio,limitX:Math.max(0,(width-view.width)/2),limitY:Math.max(0,(width/ratio-view.height)/2)};
}
export function zoomScrubber(button,{get,set,start=()=>{},key=()=>null}){
 let drag=null,suppressUntil=0;
 button.style.touchAction='none';button.style.cursor='ns-resize';
 button.title='위로 끌어 확대 · 아래로 끌어 축소 · 누르면 100%';
 button.addEventListener('pointerdown',e=>{if(e.button!==0||drag)return;e.stopPropagation();suppressUntil=0;drag={pointer:e.pointerId,y:e.clientY,value:get(),key:key(),moved:false};button.setPointerCapture(e.pointerId);});
 button.addEventListener('pointermove',e=>{
  if(!drag||drag.pointer!==e.pointerId)return;
  if(drag.key!==key()){finish(e);return;}
  const distance=drag.y-e.clientY;if(!drag.moved&&Math.abs(distance)<3)return;
  if(!drag.moved){drag.moved=true;start();}e.preventDefault();e.stopPropagation();
  set(drag.value*Math.exp(distance*.005));
 });
 function finish(e){if(!drag||e.pointerId!==drag.pointer)return;const previous=drag;drag=null;if(previous.moved&&document.activeElement===button)button.blur();if(!previous.moved&&e.type==='pointerup'){suppressUntil=0;button.click();}suppressUntil=performance.now()+700;if(button.hasPointerCapture(e.pointerId))button.releasePointerCapture(e.pointerId);e.stopPropagation();}
 button.addEventListener('pointerup',finish);button.addEventListener('pointercancel',finish);button.addEventListener('lostpointercapture',finish);
 button.addEventListener('click',e=>{if(e.detail>0&&performance.now()<suppressUntil){e.preventDefault();e.stopImmediatePropagation();}},true);
 window.addEventListener('blur',()=>{if(drag){suppressUntil=performance.now()+700;const id=drag.pointer;drag=null;if(button.hasPointerCapture(id))button.releasePointerCapture(id);}});
}

export function editorPhotoView({viewport,stage,image,dialog,id,isMobile,spaceHeld,beforeNavigate=()=>{},afterFit=()=>{}}){
 let zoom=1,x=0,y=0,pan=null,touches=new Map(),pinch=null,suppressUntil=0;
 const tools=document.createElement('div');tools.className='editor-photo-zoom';tools.id=id+'PhotoZoom';
 tools.innerHTML='<button type="button" aria-label="사진 축소">−</button><button type="button" class="photo-zoom-level" aria-label="사진 배율">100%</button><button type="button" aria-label="사진 확대">＋</button>';
 dialog.append(tools);const [minus,level,plus]=tools.children;
 const minimum=()=>isMobile()?1:.2;
 function fit(){
  zoom=Math.max(minimum(),Math.min(8,zoom));const frame=photoFrame(viewport.getBoundingClientRect(),image,zoom);
  x=Math.max(-frame.limitX,Math.min(frame.limitX,x));y=Math.max(-frame.limitY,Math.min(frame.limitY,y));
  stage.style.width=frame.width+'px';stage.style.height=frame.height+'px';stage.style.aspectRatio=frame.ratio;
  stage.style.transform=`translate(-50%,-50%) translate(${x}px,${y}px)`;
  level.textContent=Math.round(zoom*100)+'%';minus.disabled=zoom<=minimum();plus.disabled=zoom>=8;afterFit();
 }
 function reset(){zoom=1;x=y=0;pan=pinch=null;touches.clear();fit();}
 level.onclick=()=>{beforeNavigate();reset();};minus.onclick=()=>{beforeNavigate();zoom/=1.2;fit();};plus.onclick=()=>{beforeNavigate();zoom*=1.2;fit();};
 zoomScrubber(level,{get:()=>zoom,key:()=>image.src,start:beforeNavigate,set:value=>{zoom=value;fit();}});
 viewport.addEventListener('wheel',e=>{e.preventDefault();e.stopImmediatePropagation();beforeNavigate();const r=viewport.getBoundingClientRect(),cx=e.clientX-r.x-r.width/2,cy=e.clientY-r.y-r.height/2,next=Math.max(minimum(),Math.min(8,zoom*Math.exp(-e.deltaY*.0015))),factor=next/zoom;x=cx-(cx-x)*factor;y=cy-(cy-y)*factor;zoom=next;fit();},{passive:false,capture:true});
 viewport.addEventListener('pointerdown',e=>{
  if(e.pointerType==='touch'){
   touches.set(e.pointerId,{x:e.clientX,y:e.clientY});if(touches.size<2)return;
   const [a,b]=[...touches.values()],r=viewport.getBoundingClientRect();beforeNavigate();pan=null;pinch={distance:Math.max(1,Math.hypot(a.x-b.x,a.y-b.y)),zoom,x,y,cx:(a.x+b.x)/2-r.x-r.width/2,cy:(a.y+b.y)/2-r.y-r.height/2};
   for(const pointer of touches.keys())viewport.setPointerCapture(pointer);
  }else{if(e.button!==1&&!(e.button===0&&spaceHeld()))return;beforeNavigate();pan={pointer:e.pointerId,startX:e.clientX,startY:e.clientY,x,y};viewport.setPointerCapture(e.pointerId);}
  suppressUntil=performance.now()+700;e.preventDefault();e.stopImmediatePropagation();
 },true);
 viewport.addEventListener('pointermove',e=>{
  if(touches.has(e.pointerId))touches.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(pinch){e.preventDefault();e.stopImmediatePropagation();if(touches.size<2)return;const [a,b]=[...touches.values()],r=viewport.getBoundingClientRect();zoom=Math.max(minimum(),Math.min(8,pinch.zoom*Math.hypot(a.x-b.x,a.y-b.y)/pinch.distance));const factor=zoom/pinch.zoom;x=(a.x+b.x)/2-r.x-r.width/2-(pinch.cx-pinch.x)*factor;y=(a.y+b.y)/2-r.y-r.height/2-(pinch.cy-pinch.y)*factor;fit();}
  else if(pan?.pointer===e.pointerId){e.preventDefault();e.stopImmediatePropagation();x=pan.x+e.clientX-pan.startX;y=pan.y+e.clientY-pan.startY;fit();}
 },true);
 const finish=e=>{touches.delete(e.pointerId);if(pinch||pan?.pointer===e.pointerId){e.preventDefault();e.stopImmediatePropagation();suppressUntil=performance.now()+700;pan=null;if(!touches.size)pinch=null;if(viewport.hasPointerCapture(e.pointerId))viewport.releasePointerCapture(e.pointerId);}};
 viewport.addEventListener('pointerup',finish,true);viewport.addEventListener('pointercancel',finish,true);
 viewport.addEventListener('click',e=>{if(performance.now()<suppressUntil){e.preventDefault();e.stopImmediatePropagation();}},true);
 dialog.addEventListener('close',()=>{pan=pinch=null;touches.clear();});window.addEventListener('blur',()=>{pan=pinch=null;touches.clear();});
 return {fit,reset};
}
