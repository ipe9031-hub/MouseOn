import {regionPieces,regionRings,regionArea,withPieces} from './region-geometry.js';
import './vendor/polygon-clipping.js';
import {polygonArea,conformRegions,validMesh,meshProblem,nodeKey} from './region-mesh.js';
import {inside,insideRegion,regionPoint} from './interpret.js';
const clip=globalThis.polygonClipping;
export const defaultOutline=()=>[[0,0],[1,0],[1,1],[0,1]];
export function validateOutline(points){if(!Array.isArray(points)||points.length<3||points.length>160||!validMesh([{points}]))throw Error('외곽선을 3점 이상 찍고 교차하지 않도록 지정해주세요.');return points;}
function halfPlane(points,a,b){const nx=b[0]-a[0],ny=b[1]-a[1],limit=(b[0]*b[0]+b[1]*b[1]-a[0]*a[0]-a[1]*a[1])/2;const out=[];for(let i=0;i<points.length;i++){const p=points[i],q=points[(i+1)%points.length],u=nx*p[0]+ny*p[1]-limit,v=nx*q[0]+ny*q[1]-limit;if(u<=1e-12)out.push(p);if((u<0&&v>0)||(u>0&&v<0)){const t=u/(u-v);out.push([p[0]+(q[0]-p[0])*t,p[1]+(q[1]-p[1])*t]);}}return out;}
export function partitionSite(outline,regions){
 validateOutline(outline);const fixed=regions.filter(r=>r.fixed),free=regions.filter(r=>!r.fixed),seeds=free.map(r=>r.seed||regionPoint(r));
 const occupied=fixed.flatMap(regionPieces);
 const next=free.map((r,i)=>{let cell=[[-2,-2],[3,-2],[3,3],[-2,3]];for(let j=0;j<seeds.length;j++)if(i!==j){if(Math.hypot(seeds[i][0]-seeds[j][0],seeds[i][1]-seeds[j][1])<1e-6)throw Error('영역의 중심이 너무 가깝습니다. 다른 위치에 추가해주세요.');cell=halfPlane(cell,seeds[i],seeds[j]);}
  if(cell.length<3)throw Error('새 영역을 만들 공간이 부족합니다.');let result=clip.intersection([outline],[cell]);if(occupied.length)result=clip.difference(result,occupied);if(!result.length)throw Error('새 영역을 만들 공간이 부족합니다.');return withPieces({...r,seed:seeds[i]},result);});
 const ordered=regions.map(r=>r.fixed?r:next.find(n=>n.id===r.id));const conformed=conformRegions(ordered);if(!validMesh(conformed))throw Error('영역이 너무 작아 나눌 수 없습니다.');return conformed;
}
export function insertManualRegion(outline,regions,points,id){
 if(regions.length>=100)throw Error('영역은 최대 100개입니다.');
 validateOutline(points);validateOutline(outline);
 const footprint=clip.intersection([points],[outline]);if(!footprint.length)throw Error('현장 외곽선 안에 걸치는 영역을 그려주세요.');
 // The completed shape owns overlapping space; retain the remaining pieces of its neighbors.
 const next=[];for(const r of regions){const difference=clip.difference(regionPieces(r),footprint);if(difference.length){const cut=retainBoundaryPoints(withPieces(r,difference),[r]);cut.seed=regionPoint(cut);next.push(cut);}else throw Error('다른 영역이 완전히 사라지지 않도록 범위를 줄여주세요.');}
 const added=retainBoundaryPoints(withPieces({id,name:'',aliases:[],fixed:true},footprint),[{points}]);added.seed=regionPoint(added);next.push(added);const result=next;if(!validMesh(result))throw Error('경계가 너무 좁거나 교차합니다. 점을 다시 조정해주세요.');return result;
}

export function addSiteRegion(outline,regions,id){
 validateOutline(outline);if(regions.length>=100)throw Error('영역은 최대 100개입니다.');
 if(!regions.length)return [{id,name:'',aliases:[],seed:regionPoint({points:outline}),points:structuredClone(outline)}];
 if(regions.every(r=>r.fixed)){const free=clip.difference([outline],regions.flatMap(regionPieces));if(!free.length){const largest=[...regions].sort((a,b)=>regionArea(b)-regionArea(a))[0],vertices=regionRings(largest).flat(),xs=vertices.map(p=>p[0]),ys=vertices.map(p=>p[1]),cx=(Math.min(...xs)+Math.max(...xs))/2,cy=(Math.min(...ys)+Math.max(...ys))/2,axis=Math.max(...xs)-Math.min(...xs)>=Math.max(...ys)-Math.min(...ys)?0:1;const bounds=axis===0?[[cx,-1],[2,-1],[2,2],[cx,2]]:[[-1,cy],[2,cy],[2,2],[-1,2]],half=clip.intersection(regionPieces(largest),[bounds]);if(!half.length)throw Error('새 영역을 만들 공간이 부족합니다.');const next=regions.map(r=>r.id===largest.id?retainBoundaryPoints(withPieces(r,clip.difference(regionPieces(r),half)),[r]):structuredClone(r)),added=withPieces({id,name:'',aliases:[],fixed:false},half);added.seed=regionPoint(added);next.push(added);if(!validMesh(next))throw Error('새 영역을 만들 공간이 부족합니다.');return next;}const region=withPieces({id,name:'',aliases:[],fixed:false},free);region.seed=regionPoint(region);return conformRegions([...regions,region]);}
 const largestCell=[...regions].filter(r=>!r.fixed).sort((a,b)=>regionArea(b)-regionArea(a))[0],boxX=largestCell.points.map(p=>p[0]),boxY=largestCell.points.map(p=>p[1]),cx=(Math.min(...boxX)+Math.max(...boxX))/2,cy=(Math.min(...boxY)+Math.max(...boxY))/2;
 for(const axis of [(Math.max(...boxX)-Math.min(...boxX))>=(Math.max(...boxY)-Math.min(...boxY))?0:1,1,0]){
  const delta=axis===0?(Math.max(...boxX)-Math.min(...boxX))/4:(Math.max(...boxY)-Math.min(...boxY))/4,a=[cx,cy],b=[cx,cy];a[axis]-=delta;b[axis]+=delta;
  if(insideRegion(a,largestCell)&&insideRegion(b,largestCell))try{return partitionSite(outline,[...regions.map(r=>r.id===largestCell.id?{...r,seed:a}:r),{id,name:'',aliases:[],seed:b,points:outline}]);}catch{}
 }
 const seeds=regions.map(r=>r.seed||regionPoint(r)),xs=outline.map(p=>p[0]),ys=outline.map(p=>p[1]),candidates=[];
 for(let y=1;y<24;y++)for(let x=1;x<24;x++){const p=[Math.min(...xs)+(Math.max(...xs)-Math.min(...xs))*x/24,Math.min(...ys)+(Math.max(...ys)-Math.min(...ys))*y/24];if(inside(p,outline)&&!regions.some(r=>r.fixed&&insideRegion(p,r)))candidates.push({p,score:Math.min(...seeds.map(s=>Math.hypot(s[0]-p[0],s[1]-p[1]))) });}
 // Choose inside the largest cell near its center; alternative candidates avoid disconnected concave cells.
 const largest=largestCell,center=regionPoint(largest);
 candidates.sort((a,b)=>{const score=c=>c.score*(insideRegion(c.p,largest)?1.4:1)-Math.hypot(c.p[0]-center[0],c.p[1]-center[1])*.15;return score(b)-score(a);});
 for(const {p}of candidates.slice(0,100))try{return partitionSite(outline,[...regions,{id,name:'',aliases:[],seed:p,points:outline}]);}catch{}
 throw Error('이 외곽선에서는 새 영역을 자동으로 나누지 못했습니다. 외곽선을 단순하게 조정하거나 경계를 직접 편집해주세요.');
}
export function withinOutline(regions,outline){if(!outline?.length||!regions.length)return true;const outside=clip.difference(regions.flatMap(regionPieces),[outline]);return outside.reduce((sum,p)=>sum+Math.abs(polygonArea(p[0])),0)<1e-7;}
// Project outside points onto the closest outline segment, including concave boundaries.
function nearestOnRings(rings,point,viewport){const width=viewport.width||1,height=viewport.height||1;let nearest=null,distance=Infinity,edge=null;for(const ring of rings)for(let i=0;i<ring.length;i++){const a=ring[i],b=ring[(i+1)%ring.length],dx=(b[0]-a[0])*width,dy=(b[1]-a[1])*height,length=dx*dx+dy*dy;if(length<1e-16)continue;const t=Math.max(0,Math.min(1,(((point[0]-a[0])*width)*dx+((point[1]-a[1])*height)*dy)/length)),p=[a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])],d=Math.hypot((point[0]-p[0])*width,(point[1]-p[1])*height);if(d<distance){distance=d;nearest=p;edge=[a,b];}}return {point:nearest,distance,edge};}
export function snapToOutline(outline,point,tolerance=0,viewport={width:1,height:1}){
 if(!outline?.length)return [...point];const nearest=nearestOnRings([outline],point,viewport);
 return nearest.point&&(!inside(point,outline)||nearest.distance<=tolerance)?nearest.point:[...point];
}
// Tolerance is measured in rendered CSS pixels, independently of aspect ratio and screen size.
export function snapRegionEditPoint(outline,regions,id,point,viewport,tolerance=5){
 const width=viewport.width||1,height=viewport.height||1,outer=nearestOnRings([outline],point,viewport);
 if(outer.point&&(!inside(point,outline)||outer.distance<=tolerance))return outer.point;
 const rings=regions.filter(r=>r.id!==id).flatMap(regionRings);let vertex=null,distance=Infinity;
 for(const p of rings.flat()){const d=Math.hypot((point[0]-p[0])*width,(point[1]-p[1])*height);if(d<=tolerance&&d<distance){vertex=p;distance=d;}}
 if(vertex)return [...vertex];const edge=nearestOnRings(rings,point,viewport);return edge.point&&edge.distance<=tolerance?edge.point:[...point];
}
export function constrainToOutline(outline,changes){if(!outline?.length)return changes;return changes.map(({from,to})=>{
 if(outline.some(p=>Math.hypot(p[0]-from[0],p[1]-from[1])<1e-8))return {from,to:[...from]};
 for(let i=0;i<outline.length;i++){const a=outline[i],b=outline[(i+1)%outline.length],dx=b[0]-a[0],dy=b[1]-a[1],d=dx*dx+dy*dy;if(d<1e-16)continue;const t=((from[0]-a[0])*dx+(from[1]-a[1])*dy)/d;if(t>=0&&t<=1&&Math.hypot(from[0]-a[0]-t*dx,from[1]-a[1]-t*dy)<1e-8){const u=Math.max(0,Math.min(1,((to[0]-a[0])*dx+(to[1]-a[1])*dy)/d));return {from,to:[a[0]+u*dx,a[1]+u*dy]};}}
 return {from,to:snapToOutline(outline,to,.008)};
 });}

// Retain the source's own boundary points, including intentional collinear points.
// Only exact duplicate consecutive coordinates and zero-length edges are removed by withPieces.
function retainBoundaryPoints(region,sources){
 const vertices=sources.flatMap(regionRings).flat();
 return withPieces(region,regionPieces(region).map(piece=>piece.map(ring=>ring.flatMap((a,i)=>{
  const b=ring[(i+1)%ring.length],dx=b[0]-a[0],dy=b[1]-a[1],length=dx*dx+dy*dy;if(length===0)return [a];
  const points=vertices.map(p=>({p,t:((p[0]-a[0])*dx+(p[1]-a[1])*dy)/length})).filter(({p,t})=>t>1e-12&&t<1-1e-12&&nodeKey(p)!==nodeKey(a)&&nodeKey(p)!==nodeKey(b)&&Math.abs(dx*(p[1]-a[1])-dy*(p[0]-a[0]))<=1e-13*Math.sqrt(length)).sort((x,y)=>x.t-y.t);
  return [a,...points.map(v=>v.p)];
 }))));
}
// Edit one footprint and let its neighbors retain the remaining space, including enclosed holes.
export function reshapeSiteRegion(outline,regions,id,shape){
 const old=regions.find(r=>r.id===id);if(!old)throw Error('영역을 먼저 선택해주세요.');
 shape=withPieces(shape,regionPieces(shape));if(polygonArea(old.points)*polygonArea(shape.points)<0)throw Error('영역이 뒤집히는 위치로 점을 옮길 수 없습니다.');
 const shapeIssue=meshProblem([shape]);if(shapeIssue)throw Error(shapeIssue);
 const footprint=clip.intersection(regionPieces(shape),[outline]);if(!footprint.length)throw Error('영역이 현장 안에 남아 있어야 합니다.');
 const edited=retainBoundaryPoints(withPieces({...old,fixed:true,...(shape.labelPosition?{labelPosition:shape.labelPosition}:{})},footprint),[shape]);const issue=meshProblem([edited]);if(issue)throw Error(issue);edited.seed=regionPoint(edited);
 const released=clip.difference(regionPieces(old),footprint),others=regions.filter(r=>r.id!==id).map(r=>structuredClone(r));
 for(const piece of released){
  if(!others.length)break;const center=regionPoint(withPieces({},[piece]));
  const target=[...others].sort((a,b)=>{
   const score=r=>{const remainder=clip.difference(regionPieces(r),footprint);return (remainder.length?0:-10)+nearestOnRings(regionRings(r),center,{width:1,height:1}).distance;};return score(a)-score(b);
  })[0];others[others.findIndex(r=>r.id===target.id)]=withPieces(target,clip.union(regionPieces(target),[piece]));
 }
 const result=regions.map(r=>{
  if(r.id===id)return edited;const other=others.find(o=>o.id===r.id),rest=clip.difference(regionPieces(other),footprint);
  if(!rest.length)throw Error('다른 영역이 완전히 사라지는 위치입니다. 조금 이동하거나 경계를 조절해주세요.');
  const cut=retainBoundaryPoints(withPieces(other,rest),[r]);cut.seed=regionPoint(cut);return cut;
 });
 if(!validMesh(result))throw Error(meshProblem(result));return result;
}

// Insert in the nearest boundary segment's order, but keep the chosen position itself.
export function addRegionPointAt(outline,regions,id,position,viewport={width:1,height:1}){
 const selected=regions.find(r=>r.id===id);if(!selected)throw Error('영역을 먼저 선택해주세요.');
 const point=latchRegionPoint(outline,regions,id,position,viewport),width=viewport.width||1,height=viewport.height||1;let best=null;
 for(const [ri,ring]of regionRings(selected).entries())for(let i=0;i<ring.length;i++){const a=ring[i],b=ring[(i+1)%ring.length],dx=(b[0]-a[0])*width,dy=(b[1]-a[1])*height,d=dx*dx+dy*dy;if(!d)continue;const t=Math.max(0,Math.min(1,(((point[0]-a[0])*width)*dx+((point[1]-a[1])*height)*dy)/d)),distance=Math.hypot((point[0]-a[0])*width-t*dx,(point[1]-a[1])*height-t*dy);if(!best||distance<best.distance)best={ri,i,distance};}
 if(!best)throw Error('점을 추가할 영역 경계가 없습니다.');const existing=regionRings(selected).flat().find(p=>screenDistance(p,point,viewport)<=6);if(existing)return {regions:structuredClone(regions),point:[...existing],existing:true};
 const shape=structuredClone(selected);regionRings(shape)[best.ri].splice(best.i+1,0,point);return {regions:reshapeSiteRegion(outline,regions,id,shape),point};
}

// Interaction distances are rendered CSS pixels, so zoom never changes the allowance.
export function outlineInputAllowed(outline,point,viewport,margin=10){
 if(!outline?.length)return true;
 return inside(point,outline)||nearestOnRings([outline],point,viewport).distance<=margin;
}
const screenDistance=(a,b,v)=>Math.hypot((a[0]-b[0])*v.width,(a[1]-b[1])*v.height);
function snapCandidate(outline,regions,id,point,viewport,extra=[],radius=6){
 const rings=[...(outline?.length?[outline]:[]),...regions.filter(r=>r.id!==id).flatMap(regionRings),...extra];
 let best=null;for(const p of rings.flat()){const distance=screenDistance(point,p,viewport);if(distance<=radius&&(!best||distance<best.distance))best={point:p,distance,kind:'vertex'};}
 if(best)return best;const edge=nearestOnRings(rings,point,viewport);return edge.point&&edge.distance<=radius?{...edge,kind:'edge'}:null;
}
// Hold once caught, release only after a deliberate pull. No point is merged or deleted.
export function latchRegionPoint(outline,regions,id,point,viewport,state={},extra=[]){
 if(state.kind==='edge'&&state.edge){const held=nearestOnRings([state.edge],point,viewport);if(held.distance<=12)return held.point;}else if(state.target&&screenDistance(point,state.target,viewport)<=12)return [...state.target];
 state.target=null;state.edge=null;const candidate=snapCandidate(outline,regions,id,point,viewport,extra);
 if(candidate){state.target=[...candidate.point];state.kind=candidate.kind;state.edge=candidate.edge||null;return [...state.target];}
 return snapToOutline(outline,point,0,viewport);
}
export function latchRegionTranslation(outline,regions,id,delta,viewport,state={}){
 const region=regions.find(r=>r.id===id),vertices=regionRings(region).flat();
 if(state.index!==undefined&&state.target){const p=vertices[state.index],raw=[p[0]+delta[0],p[1]+delta[1]];const held=state.kind==='edge'&&state.edge?nearestOnRings([state.edge],raw,viewport):{point:state.target,distance:screenDistance(raw,state.target,viewport)};if(held.distance<=12)return [held.point[0]-p[0],held.point[1]-p[1]];}
 delete state.index;state.target=null;let best=null;
 vertices.forEach((p,index)=>{const candidate=snapCandidate(outline,regions,id,[p[0]+delta[0],p[1]+delta[1]],viewport);if(candidate&&(!best||candidate.distance<best.distance))best={...candidate,index};});
 if(!best)return delta;state.index=best.index;state.target=[...best.point];state.kind=best.kind;state.edge=best.edge||null;const source=vertices[best.index];return [best.point[0]-source[0],best.point[1]-source[1]];
}
// A whole-region drag uses one translation for every ring, including holes and its label.
export function translateSiteRegion(outline,regions,id,delta){
 const original=regions.find(r=>r.id===id);if(!original)throw Error('영역을 먼저 선택해주세요.');
 const moved=factor=>{const next=mapRegionForTranslation(original,delta,factor);return next;};
 const fits=shape=>{const rest=clip.difference(regionPieces(shape),[outline]);return !rest.length||regionArea(withPieces({},rest))<=1e-12;};
 let factor=1;if(!fits(moved(1))){let lo=0,hi=1;for(let i=0;i<32;i++){const mid=(lo+hi)/2;if(fits(moved(mid)))lo=mid;else hi=mid;}factor=lo;}
 let shape=moved(factor);if(factor<1){for(const point of regionRings(shape).flat()){const nearest=nearestOnRings([outline],point,{width:1,height:1});if(nearest.point&&nearest.distance<1e-8){const adjusted=[delta[0]*factor+nearest.point[0]-point[0],delta[1]*factor+nearest.point[1]-point[1]],candidate=mapRegionForTranslation(original,adjusted,1);if(fits(candidate)){shape=candidate;break;}}}}return reshapeSiteRegion(outline,regions,id,shape);
}
function mapRegionForTranslation(region,delta,factor){
 const next=withPieces(region,regionPieces(region).map(piece=>piece.map(ring=>ring.map(p=>[p[0]+delta[0]*factor,p[1]+delta[1]*factor]))));
 if(region.labelPosition)next.labelPosition=[Math.max(0,Math.min(1,region.labelPosition[0]+delta[0]*factor)),Math.max(0,Math.min(1,region.labelPosition[1]+delta[1]*factor))];return next;
}
