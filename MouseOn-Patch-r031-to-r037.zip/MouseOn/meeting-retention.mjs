// Keep yesterday, today and every future task, using the site's Korean calendar date.
export function retainedTasks(tasks,now=new Date()){
 const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Seoul',year:'numeric',month:'2-digit',day:'2-digit'}).format(now),cutoff=new Date(today+'T00:00:00Z');cutoff.setUTCDate(cutoff.getUTCDate()-1);const first=cutoff.toISOString().slice(0,10);
 return tasks.filter(task=>typeof task.date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(task.date)||task.date>=first);
}
