MouseOn r029
Close MouseOn and calendar helper. Back up your existing folder.
Merge the MouseOn folder into the existing MouseOn folder, replacing files.
Do not delete data. Relaunch, then Ctrl+F5 on PC / reload on phone.
Read Works again to reinterpret automatic positions, including old neighborhood facility mistakes.
Map context menu includes photo registration: files remain as unconfirmed thumbnails at the selected coordinate.
