MouseOn r018
실행 창과 웍스 창을 닫고 기존 폴더를 백업하세요.
MouseOn 안 내용물을 기존 MouseOn 안에 병합·덮어쓴 뒤 다시 실행하세요.
PC Ctrl+F5, 모바일 새로고침. data 폴더는 삭제하지 마세요.
