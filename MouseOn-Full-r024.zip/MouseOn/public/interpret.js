import {regionPieces,regionArea} from './region-geometry.js';
import {validDate} from './calendar.js';
export const kindInfo={formwork:['갱폼','#c2410c'],rope:['로프 작업','#be185d'],tower:['타워크레인','#6d28d9'],mobile:['이동식 크레인','#7c3aed'],concrete:['타설','#0369a1'],mixer:['레미콘','#1d4ed8'],excavator:['굴착기','#b45309'],forklift:['지게차·하역','#047857'],dump:['덤프','#4d7c0f'],other:['기타','#475569']};
export function kindOf(text){return /갱폼/.test(text)?'formwork':/로프/.test(text)?'rope':/타워/.test(text)?'tower':/크레인|인양|양중/.test(text)?'mobile':/레미콘/.test(text)?'mixer':/타설|콘크리트/.test(text)?'concrete':/지게차|하역/.test(text)?'forklift':/덤프/.test(text)?'dump':/굴착|백호/.test(text)?'excavator':'other';}
function hit(text,alias){const a=alias.replace(/\s/g,'');let from=0,i;while((i=text.indexOf(a,from))!==-1){if(!(/^\d/.test(a)&&i>0&&/\d/.test(text[i-1]))&&!(/\d$/.test(a)&&/\d/.test(text[i+a.length]||'')))return true;from=i+1;}return false;}
export function matchRegions(text,regions){const clean=text.replace(/\s/g,'');return regions.filter(r=>[r.name,...r.aliases].filter(a=>a.trim()).some(a=>hit(clean,a)));}
export function inside(point,polygon){let yes=false;for(let i=0,j=polygon.length-1;i<polygon.length;j=i++){const a=polygon[i],b=polygon[j];if((a[1]>point[1])!==(b[1]>point[1])&&point[0]<(b[0]-a[0])*(point[1]-a[1])/(b[1]-a[1])+a[0])yes=!yes;}return yes;}
export function insideRegion(point,region){return regionPieces(region).some(p=>inside(point,p[0])&&!p.slice(1).some(hole=>inside(point,hole)));}
export function regionPoint(region,slot=0){if(region.pieces){for(const polygon of regionPieces(region)){const xs=polygon[0].map(p=>p[0]),ys=polygon[0].map(p=>p[1]);for(let step=0;step<900;step++){const x=step===0?.5:((step+slot*13)%30+.5)/30,y=step===0?.5:(Math.floor((step+slot*13)%900/30)+.5)/30,q=[Math.min(...xs)+(Math.max(...xs)-Math.min(...xs))*x,Math.min(...ys)+(Math.max(...ys)-Math.min(...ys))*y];if(inside(q,polygon[0])&&!polygon.slice(1).some(h=>inside(q,h)))return q;}}return region.points[0];}const p=region.points;const xs=p.map(a=>a[0]),ys=p.map(a=>a[1]);const minX=Math.min(...xs),maxX=Math.max(...xs),minY=Math.min(...ys),maxY=Math.max(...ys);const center=[(minX+maxX)/2,(minY+maxY)/2];if(slot>0){for(let step=0;step<50;step++){const angle=(slot+step)*2.399963;const radius=.16+(slot%3)*.09;const q=[center[0]+(maxX-minX)*radius*Math.cos(angle),center[1]+(maxY-minY)*radius*Math.sin(angle)];if(inside(q,p))return q;}}if(inside(center,p))return center;for(let y=1;y<30;y++)for(let x=1;x<30;x++){const q=[minX+(maxX-minX)*x/30,minY+(maxY-minY)*y/30];if(inside(q,p))return q;}return p[0];}
export function interpret(entry,regions){
 if(typeof entry?.text!=='string'||!validDate(entry.date))throw Error('일정 원문·날짜를 확인해주세요.');
 const matches=matchRegions(entry.text,regions),region=matches.length===1?matches[0]:null;
 const reasons=[];if(!region)reasons.push(matches.length?'여러 영역이 언급되어 위치 확인 필요':'등록된 동·시설을 찾지 못했습니다.');
 if(/북|남|동측|서측|동쪽|서쪽/.test(entry.text))reasons.push('방향 표현은 현장 방위 확인 후 조정해주세요.');
 if(/갱폼|로프|고소|해체|인양|밀폐|화기/.test(entry.text))reasons.push('고위험 작업의 상하·주변 작업 확인 필요 (자동 간섭 판정 아님)');
 const point=region?regionPoint(region):null;return {title:entry.text.replace(/\n/g,' ').slice(0,80),detail:'',date:entry.date,icon:kindOf(entry.text),regionId:region?.id||null,x:point?.[0]??null,y:point?.[1]??null,original:entry.text,calendar:entry.calendar||'',reasons};
}
