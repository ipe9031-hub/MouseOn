MouseOn r025
Close MouseOn and calendar helper. Back up the existing folder.
Merge the MouseOn folder into your existing MouseOn folder, replacing files.
Do not delete data. Relaunch, then PC Ctrl+F5 / phone reload.
Erase now clears drawings and exits pen mode. Drawing cancel button removed.
Mobile photo frame outline removed.
