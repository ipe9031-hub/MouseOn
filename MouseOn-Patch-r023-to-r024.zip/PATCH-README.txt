MouseOn r024 — Supabase sharing trial
Close MouseOn and calendar helper before applying.
Merge the MouseOn folder into your existing MouseOn folder, replacing files.
Do not delete your local data folder. Launch Start-MouseOn-Internet.bat again.
Site settings > Cloud sharing: use the Auth user account created in Supabase.
Save and load are manual. Live account upload/restore still needs verification.
