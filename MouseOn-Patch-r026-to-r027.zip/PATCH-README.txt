MouseOn r027
Close MouseOn and calendar helper. Back up your existing folder.
Merge the MouseOn folder into the existing MouseOn folder, replacing files.
Do not delete data. Relaunch, then Ctrl+F5 on PC / reload on phone.
Region settings: tap the map for the compact Create building region / Edit region menu.
Neighborhood facilities are matched separately from apartment building numbers.
