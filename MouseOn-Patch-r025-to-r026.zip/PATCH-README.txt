MouseOn r026
Close MouseOn and calendar helper, then back up your existing folder.
Merge the MouseOn folder into the existing MouseOn folder, replacing files.
Do not delete data. Relaunch, then Ctrl+F5 on PC / reload on phone.
Works: read jobs directly onto saved building regions. Unresolved jobs appear under the location-check button.
Region editor: small points, nearest-point enlargement, continuous point insertion, undo, movable sticky tool menus and draggable labels.
