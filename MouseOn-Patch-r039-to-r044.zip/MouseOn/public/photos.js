// Small local previews keep large original photos out of map thumbnail downloads.
export async function photoThumbnail(file){
 let bitmap,url;try{
  try{bitmap=await createImageBitmap(file);}catch{url=URL.createObjectURL(file);bitmap=new Image();bitmap.src=url;await bitmap.decode();}
  const scale=Math.min(1,128/bitmap.width,128/bitmap.height),canvas=document.createElement('canvas');canvas.width=Math.max(1,Math.round(bitmap.width*scale));canvas.height=Math.max(1,Math.round(bitmap.height*scale));canvas.getContext('2d').drawImage(bitmap,0,0,canvas.width,canvas.height);const preview=canvas.toDataURL('image/jpeg',.58);return preview.length<=9000?preview:'';
 }catch{return '';}finally{bitmap?.close?.();if(url)URL.revokeObjectURL(url);}
}
const placements=new WeakMap();
const overlap=(a,b)=>Math.max(0,Math.min(a.right,b.right)-Math.max(a.left,b.left))*Math.max(0,Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top));
export function arrangePhotoCards(scene,viewport,leader){
 const bounds=scene.getBoundingClientRect(),view=viewport.getBoundingClientRect();if(!bounds.width||!bounds.height)return;
 let cache=placements.get(scene);if(!cache){cache=new Map();placements.set(scene,cache);}
 const blocks=[...scene.querySelectorAll('.marker')].map(e=>e.getBoundingClientRect());leader.replaceChildren();
 for(const pin of scene.querySelectorAll('.photo-pin')){
  const x=bounds.left+Number(pin.dataset.x)*bounds.width,y=bounds.top+Number(pin.dataset.y)*bounds.height,button=pin.querySelector('button'),w=button.offsetWidth,h=button.offsetHeight;
  const key=JSON.stringify([pin.dataset.x,pin.dataset.y]),cached=cache.get(pin.dataset.photoId);
  const candidates=[];for(const d of [14,54,100,154])for(const [dx,dy]of [[d,-h/2],[d,d],[-w-d,-h/2],[-w-d,d],[-w/2,-h-d],[-w/2,d]]){
   const box={left:x+dx,top:y+dy,right:x+dx+w,bottom:y+dy+h};let score=Math.hypot(dx,dy);
   const clipped=box.left<view.left+5||box.right>view.right-5||box.top<view.top+5||box.bottom>view.bottom-5;if(clipped)score+=100000;
   for(const block of blocks)score+=overlap(box,{left:block.left-6,top:block.top-6,right:block.right+6,bottom:block.bottom+6})*1000;
   candidates.push({dx,dy,box,score});
  }
  candidates.sort((a,b)=>a.score-b.score);let best=candidates[0];if(cached?.key===key){const dx=cached.dx*bounds.width,dy=cached.dy*bounds.height;best={dx,dy,box:{left:x+dx,top:y+dy,right:x+dx+w,bottom:y+dy+h}};}else cache.set(pin.dataset.photoId,{key,dx:best.dx/bounds.width,dy:best.dy/bounds.height});button.style.left=best.dx+'px';button.style.top=best.dy+'px';blocks.push(best.box);
  const line=document.createElementNS('http://www.w3.org/2000/svg','line');for(const [key,value]of Object.entries({x1:(x-bounds.left)/bounds.width*1000,y1:(y-bounds.top)/bounds.height*1000,x2:(x+best.dx+w/2-bounds.left)/bounds.width*1000,y2:(y+best.dy+h/2-bounds.top)/bounds.height*1000}))line.setAttribute(key,value);line.classList.toggle('confirmed',pin.classList.contains('confirmed'));leader.append(line);
 }
}
