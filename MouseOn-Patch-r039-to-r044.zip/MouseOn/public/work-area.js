import {regionRings} from './region-geometry.js';
import {insideRegion} from './interpret.js';
export function limitWorkMove(task,point,regions,frame={width:1000,height:1000}){
 const region=regions.find(r=>r.id===task?.regionId);if(!region||insideRegion(point,region))return point;
 const width=Math.max(1,frame.width),height=Math.max(1,frame.height);let best=null;
 for(const ring of regionRings(region))for(let i=0;i<ring.length;i++){
  const a=ring[i],b=ring[(i+1)%ring.length],dx=(b[0]-a[0])*width,dy=(b[1]-a[1])*height,px=(point[0]-a[0])*width,py=(point[1]-a[1])*height,t=Math.max(0,Math.min(1,(px*dx+py*dy)/(dx*dx+dy*dy||1))),q=[a[0]+t*(b[0]-a[0]),a[1]+t*(b[1]-a[1])],distance=Math.hypot((point[0]-q[0])*width,(point[1]-q[1])*height);
  if(!best||distance<best.distance)best={q,distance};
 }
 if(!best||best.distance<=50)return point;const t=50/best.distance;return best.q.map((v,i)=>v+(point[i]-v)*t);
}
