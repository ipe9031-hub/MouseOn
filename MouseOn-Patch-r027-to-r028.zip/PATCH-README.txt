MouseOn r028
Close MouseOn and calendar helper. Back up your existing folder.
Merge the MouseOn folder into the existing MouseOn folder, replacing files.
Do not delete data. Relaunch, then Ctrl+F5 on PC / reload on phone.
Gear opens settings only; enter Region settings to edit areas.
Noto Sans KR is available in the site font selector and bundled for offline use.
