import {SupabaseShare,ShareError} from './supabase-share.mjs';
import {captureSharedSnapshot,prepareSharedRestore} from './cloud-snapshot.mjs';
import http from 'node:http';
import {defaultHazards} from './public/hazards.js';
import {mergeNetworkSchedules} from './works-network.mjs';
import { networkInterfaces } from 'node:os';
import fs from 'node:fs';
import path from 'node:path';
import { randomBytes, scryptSync } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';
import QRCode from 'qrcode';
import {siteStore,validateSite} from './site-store.mjs';
import {interpret,interpretAll,regionPoint} from './public/interpret.js';
import {createHash} from 'node:crypto';
import { isTower } from './public/icons.js';
import { schedule, validDate } from './public/calendar.js';
import { createAccess } from './access.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const data = path.resolve(process.env.DATA_DIR || path.join(root, 'data'));
fs.mkdirSync(path.join(data, 'images'), { recursive: true });
const rooms = new Map();
const sites=siteStore(data);
let cloudShare=null,cloudConfigError=false;
try{const configFile=path.join(root,'supabase.config.json'),configured=fs.existsSync(configFile)?JSON.parse(fs.readFileSync(configFile,'utf8')):{};const url=process.env.SUPABASE_URL||configured.url,key=process.env.SUPABASE_PUBLISHABLE_KEY||configured.publishableKey;if(url&&key)cloudShare=new SupabaseShare({url,key,allowLocal:process.env.NODE_ENV==='test'&&process.env.SUPABASE_TEST_LOCAL==='1'});}catch{cloudConfigError=true;}
let worksHelper=null;
let worksAutomatic={roomId:null,enabled:false,lastGeneration:0,message:'',totals:{added:0,updated:0}};let worksPolling=false,worksConfiguring=false;
async function helperNetwork(action,input){
 if(!worksHelper)throw Error('Start-MouseOn 실행기로 다시 실행해주세요.');
 const result=await fetch(worksHelper.origin+'/network/'+action,{method:action==='status'?'GET':'POST',headers:{'X-Probe-Key':worksHelper.key,'Content-Type':'application/json'},...(action==='status'?{}:{body:JSON.stringify(input||{})}),signal:AbortSignal.timeout(15000)});
 const value=await result.json();if(!result.ok)throw Error(value.error||'일정 데이터 연결에 실패했습니다.');return value;
}
async function refreshAutomatic(){
 if(!worksAutomatic.enabled||worksPolling)return;worksPolling=true;const current=worksAutomatic;
 try{
  const status=await helperNetwork('status');if(current!==worksAutomatic)return;
  if(!status.automatic){worksAutomatic.enabled=false;worksAutomatic.message=status.message;return;}
  const snapshot=status.snapshot;if(!snapshot||snapshot.generation<=current.lastGeneration)return;
  const room=getRoom(current.roomId);if(!room){worksAutomatic.enabled=false;return;}
  const changes=mergeNetworkSchedules(room,snapshot.events,sites.read(),snapshot.scope);
  if(changes.added||changes.updated){room.revision++;save(room);broadcast(room.id,{type:'state',room,notice:`웍스 일정 자동 수집 · 신규 ${changes.added}개 · 변경 ${changes.updated}개`});}
  current.lastGeneration=snapshot.generation;current.totals.added+=changes.added;current.totals.updated+=changes.updated;current.message=`신규 ${current.totals.added}개 · 변경 ${current.totals.updated}개 반영`;
 }catch{if(current===worksAutomatic){current.enabled=false;current.message='자동 반영이 중단됐습니다. 연동 브라우저와 연결 상태를 확인한 뒤 다시 시작해주세요.';}}
 finally{worksPolling=false;}
}
setInterval(()=>{void refreshAutomatic();},3000).unref();

process.on('message',m=>{if(m?.type==='worksHelper'){try{const u=new URL(m.url);if(u.hostname==='127.0.0.1'&&u.protocol==='http:'&&typeof m.key==='string')worksHelper={origin:u.origin,key:m.key};}catch{}}});
async function bodyJSON(req,max=1024*1024){let size=0;const parts=[];for await(const chunk of req){size+=chunk.length;if(size>max)throw Error('요청이 너무 큽니다.');parts.push(chunk);}return JSON.parse(Buffer.concat(parts).toString());}
const isHost=req=>!hostSetup||Boolean(process.env.MOUSEON_HOST_TOKEN&&req.headers['x-mouseon-host']===process.env.MOUSEON_HOST_TOKEN);
const publicSite=(site,id)=>({...site,image:site.image?'/api/site/image?room='+id+'&v='+site.revision:null});

const hostSetup=process.env.MOUSEON_HOST_SETUP==='1';
if(process.env.MOUSEON_INTERNET==='1' && !hostSetup && !process.env.MOUSEON_PASSWORD) throw new Error('Internet mode requires a meeting password.');
const access=createAccess(process.env.MOUSEON_PASSWORD);
const roomAccess=new Map();
function gate(id){
 if(!validId(id))return null;
 if(roomAccess.has(id))return roomAccess.get(id);
 const file=path.join(data,id+'.access.json');
 if(!fs.existsSync(file))return null;
 const value=createAccess(JSON.parse(fs.readFileSync(file)), 'mouseon_session_'+id);roomAccess.set(id,value);return value;
}
function requestGate(req,url){
 const id=url.searchParams.get('room') || url.pathname.match(/^\/api\/rooms\/([a-f0-9]{12})/)?.[1];
 return hostSetup?gate(id):access;
}
let tunnel={status:process.env.MOUSEON_INTERNET==='1'?'starting':'local',url:null,message:''};
process.on('message',m=>{if(m?.type==='tunnel')tunnel=m.state;});
const validId = id => /^[a-f0-9]{12}$/.test(id || '');
function getRoom(id) {
  if (!validId(id)) return null;
  if (rooms.has(id)) return rooms.get(id);
  const file = path.join(data, id + '.json');
  if (!fs.existsSync(file)) return null;
  const room = JSON.parse(fs.readFileSync(file)); rooms.set(id, room); return room;
}
function save(room) {
  const file = path.join(data, room.id + '.json');
  fs.writeFileSync(file + '.tmp', JSON.stringify(room)); fs.renameSync(file + '.tmp', file);
}
function createRoom() {
  const room = { id: randomBytes(6).toString('hex'), revision: 0, image: null, topImage: null, strokes: [], tasks: [
    { id: 't1', title: '101동 철근 인양', detail: '09:00 · 101동 북측 · 시공팀', equipment: '크레인 1호', icon: '🏗️', x: .30, y: .32 },
    { id: 't2', title: '103동 자재 인양', detail: '11:00 · 103동 · 시공팀', equipment: '크레인 1호', icon: '🏗️', x: .70, y: .34 },
    { id: 't3', title: '야적장 정리', detail: '14:00 · 자재 야적장 · 시공팀', equipment: '크레인 1호', icon: '🏗️', x: .74, y: .75 },
    { id: 't4', title: '102동 콘크리트 타설', detail: '10:00 · 102동 · 골조팀', equipment: '펌프카 1호', icon: '🚧', x: .30, y: .70 }
  ] };
  const configured=sites.read();if(configured.revision>0)room.tasks=[];
  room.tasks.forEach((task,i)=>task.date=schedule().dates[i%schedule().dates.length]);
  if(configured.image){room.topImage='/api/site/image?room='+room.id+'&v='+configured.revision;room.image=room.topImage;}
  rooms.set(room.id, room); save(room); return room;
}
const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json', 'Cache-Control':'no-store' }); res.end(JSON.stringify(obj)); };
function imageExt(b) {
  if (b.subarray(0, 8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return 'png';
  if (b[0] === 255 && b[1] === 216 && b[2] === 255) return 'jpg';
  if (b.toString('ascii', 0, 4) === 'RIFF' && b.toString('ascii', 8, 12) === 'WEBP') return 'webp';
  return null;
}
const drawingCookie=req=>req.headers.cookie?.match(/(?:^|;\s*)mouseon_ink=([a-f0-9]{48})(?:;|$)/)?.[1]||null;
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if(req.method==='GET' && url.pathname==='/api/access'&&!drawingCookie(req)){const secure=req.headers['x-forwarded-proto']==='https';res.setHeader('Set-Cookie','mouseon_ink='+randomBytes(24).toString('hex')+'; HttpOnly; SameSite=Lax; Path=/; Max-Age=31536000'+(secure?'; Secure':''));}
    if(req.method==='GET' && url.pathname==='/api/access') return json(res,200,{hostSetup,canClearInk:isHost(req),passwordRequired:hostSetup||access.required,authenticated:hostSetup?Boolean(requestGate(req,url)?.allowed(req)):access.allowed(req)});
    if(req.method==='POST' && url.pathname==='/api/login') {
 const selected=requestGate(req,url);if(!selected)return json(res,404,{error:'회의를 찾을 수 없습니다. 새 회의를 만들어주세요.'});return selected.login(req,res);
 }
 if(hostSetup && req.method==='POST' && url.pathname==='/api/rooms'){
  if(!process.env.MOUSEON_HOST_TOKEN || req.headers['x-mouseon-host']!==process.env.MOUSEON_HOST_TOKEN)return json(res,403,{error:'PC의 실행 파일로 열린 주최자 화면에서 회의를 생성해주세요.'});
  let body='';for await(const chunk of req){body+=chunk;if(body.length>2048)return json(res,413,{error:'요청이 너무 큽니다.'});}
  let password;try{password=JSON.parse(body).password;}catch{}
  if(typeof password!=='string'||password.length<4||password.length>128)return json(res,400,{error:'비밀번호를 4~128자로 정해주세요.'});
  const salt=randomBytes(16).toString('hex'), secret={salt,hash:scryptSync(password,salt,32).toString('hex')};
  const room=createRoom();fs.writeFileSync(path.join(data,room.id+'.access.json'),JSON.stringify(secret),{mode:0o600});
  const selected=gate(room.id);return selected.grant(req,res,room);
 }
    if((url.pathname.startsWith('/api/') || url.pathname.startsWith('/images/')) && !(hostSetup && url.pathname==='/api/network' && req.headers['x-mouseon-host']===process.env.MOUSEON_HOST_TOKEN) && !requestGate(req,url)?.allowed(req)) return json(res,401,{error:'회의 비밀번호를 입력하고 참여해주세요.'});
    if(req.method==='POST' && req.headers.origin && ![`http://${req.headers.host}`,`https://${req.headers.host}`].includes(req.headers.origin))return json(res,403,{error:'허용되지 않은 요청입니다.'});
    if(url.pathname.startsWith('/api/cloud/')){
      if(!isHost(req))return json(res,403,{error:'주최자 PC에서만 클라우드 공유를 설정할 수 있습니다.'});
      const id=url.searchParams.get('room'),room=getRoom(id);if(!room)return json(res,404,{error:'회의를 먼저 열어주세요.'});
      if(req.method==='GET'&&url.pathname==='/api/cloud/status')return json(res,200,cloudShare?cloudShare.status:{configured:false,signedIn:false,configurationError:cloudConfigError});
      if(!cloudShare)return json(res,503,{error:'이 실행 환경의 Supabase 연결을 준비하고 있습니다. 기존 현장은 유지합니다.',code:'config'});
      try{
        if(req.method==='POST'&&url.pathname==='/api/cloud/login'){const input=await bodyJSON(req,4096);if(typeof input.email!=='string'||typeof input.password!=='string'||input.email.length>254||input.password.length>1024)throw new ShareError('계정 정보를 확인해주세요.','input');return json(res,200,await cloudShare.login(input.email,input.password));}
        if(req.method==='POST'&&url.pathname==='/api/cloud/logout'){cloudShare.logout();return json(res,200,{signedIn:false});}
        if(req.method==='GET'&&url.pathname==='/api/cloud/sites')return json(res,200,{sites:await cloudShare.list()});
        if(req.method==='POST'&&url.pathname==='/api/cloud/push'){const input=await bodyJSON(req),site=sites.read(),captured=captureSharedSnapshot(data,site,room),revision=room.revision;const saved=await cloudShare.push({id:input.id||randomBytes(16).toString('hex').replace(/^(........)(....)(....)(....)(............)$/,'$1-$2-$3-$4-$5'),name:site.name,revision:input.revision??0,...captured});return json(res,200,{...saved,hasNewLocalChanges:room.revision!==revision||sites.read().revision!==site.revision});}
        if(req.method==='POST'&&url.pathname==='/api/cloud/pull'){const input=await bodyJSON(req),beforeSite=sites.read(),beforeRoom=structuredClone(room);if(input.roomRevision!==room.revision||input.siteRevision!==beforeSite.revision)throw new ShareError('현재 현장이 바뀌었습니다. 화면을 확인한 뒤 다시 불러와주세요.','conflict');
          const pulled=await cloudShare.pull(input.id);if(room.revision!==beforeRoom.revision||sites.read().revision!==beforeSite.revision)throw new ShareError('불러오는 동안 현재 현장이 바뀌었습니다. 기존 내용은 유지합니다.','conflict');
          const prepared=prepareSharedRestore(data,pulled.row.snapshot,pulled.files),backupFolder=path.join(data,'cloud-backups');fs.mkdirSync(backupFolder,{recursive:true});fs.writeFileSync(path.join(backupFolder,Date.now()+'-'+randomBytes(4).toString('hex')+'.json'),JSON.stringify({site:beforeSite,room:beforeRoom}),{mode:0o600});
          const siteFile=path.join(data,'site','site.json'),siteWasPresent=fs.existsSync(siteFile),siteBytes=siteWasPresent?fs.readFileSync(siteFile):null;
          let restored;try{restored=sites.save(prepared.site,beforeSite.revision,prepared.siteImage);room.tasks=prepared.meeting.tasks;room.strokes=prepared.meeting.strokes;room.pointers=[];room.image=prepared.resolve(prepared.meeting.image,id,restored.revision);room.topImage=prepared.resolve(prepared.meeting.topImage,id,restored.revision);room.revision++;save(room);}catch(error){Object.assign(room,beforeRoom);if(siteWasPresent)fs.writeFileSync(siteFile,siteBytes);else if(fs.existsSync(siteFile))fs.unlinkSync(siteFile);throw error;}
          broadcast(id,{type:'site',site:publicSite(restored,id)});broadcast(id,{type:'state',room,notice:'공유 현장을 불러왔습니다.'});return json(res,200,{id:pulled.row.id,name:pulled.row.name,revision:pulled.row.revision});
        }
        return json(res,404,{error:'지원하지 않는 클라우드 요청입니다.'});
      }catch(error){const status=error.code==='conflict'?409:error.code==='login'?401:error instanceof ShareError?400:502;return json(res,status,{error:error instanceof ShareError?error.message:'클라우드 연결을 완료하지 못했습니다. 기존 현장은 유지합니다.',code:error.code||'cloud_error'});}
    }
    if(url.pathname.startsWith('/api/site')||url.pathname.startsWith('/api/works')){
      const id=url.searchParams.get('room');const room=getRoom(id);if(!room)return json(res,404,{error:'회의를 찾을 수 없습니다.'});
      if(req.method==='GET'&&url.pathname==='/api/site')return json(res,200,publicSite(sites.read(),id));
      if(req.method==='GET'&&url.pathname==='/api/site/image'){const image=sites.read().image;if(!image||!/^[a-f0-9]{32}\.(png|jpg|webp)$/.test(image))return json(res,404,{error:'저장된 탑뷰가 없습니다.'});res.writeHead(200,{'Content-Type':image.endsWith('.png')?'image/png':image.endsWith('.webp')?'image/webp':'image/jpeg','Cache-Control':'no-store'});return fs.createReadStream(path.join(data,'images',image)).pipe(res);}
      if(!isHost(req))return json(res,403,{error:'주최자 PC에서만 현장 설정과 웍스 수집을 사용할 수 있습니다.'});
      if(req.method==='POST'&&url.pathname==='/api/site/topview'){
        const expected=Number(url.searchParams.get('revision'));if(!Number.isInteger(expected)||expected!==sites.read().revision)return json(res,409,{error:'현장 설정이 변경됐습니다. 설정을 다시 열고 사진을 교체해주세요.'});
        let size=0;const chunks=[];for await(const chunk of req){size+=chunk.length;if(size>50*1024*1024){req.resume();return json(res,413,{error:'탑뷰는 50MB까지 등록할 수 있습니다.'});}chunks.push(chunk);}
        const buffer=Buffer.concat(chunks),ext=imageExt(buffer);if(!ext)return json(res,415,{error:'JPG, PNG, WebP 사진만 등록할 수 있습니다.'});
        if(expected!==sites.read().revision)return json(res,409,{error:'업로드 중 설정이 변경됐습니다. 다시 확인해주세요.'});
        const filename=randomBytes(16).toString('hex')+'.'+ext;fs.writeFileSync(path.join(data,'images',filename),buffer);
        try{const saved=sites.save(sites.read(),expected,filename),wasTop=room.image===room.topImage;room.topImage=publicSite(saved,id).image;if(wasTop){room.image=room.topImage;room.strokes=[];room.pointers=[];}room.revision++;save(room);broadcast(id,{type:'site',site:publicSite(saved,id)});broadcast(id,{type:'state',room,notice:'기본 탑뷰를 저장했습니다. 기존 영역은 보존되며 새 전경에 맞게 확인해주세요.'});return json(res,200,publicSite(saved,id));}catch(e){return json(res,400,{error:e.message});}
      }
      if(req.method==='GET'&&url.pathname==='/api/site/backup'){
        const site=sites.read();return json(res,200,{format:'mouseon-site/v1',site,imageBase64:site.image?fs.readFileSync(path.join(data,'images',site.image)).toString('base64'):null});
      }
      if(req.method==='POST'&&url.pathname==='/api/site'){
        try{const input=await bodyJSON(req);let image;
          if(input.useCurrentImage){const match=room.topImage?.match(/^\/images\/([a-f0-9]{32}\.(png|jpg|webp))(?:\?|$)/);if(match&&fs.existsSync(path.join(data,'images',match[1])))image=match[1];else if(room.topImage?.startsWith('/api/site/image')&&sites.read().image)image=sites.read().image;else throw Error('먼저 현장 탑뷰를 올려주세요.');}
          const site=sites.save(input.site,input.revision,image);broadcast(room.id,{type:'site',site:publicSite(site,id)});return json(res,200,publicSite(site,id));
        }catch(e){return json(res,400,{error:e.message});}
      }
      if(req.method==='POST'&&url.pathname==='/api/site/restore'){
        try{const input=await bodyJSON(req,72*1024*1024);if(input.format!=='mouseon-site/v1')throw Error('현장 백업 형식이 아닙니다.');validateSite(input.site);
          let image=null;if(input.imageBase64){const b=Buffer.from(input.imageBase64,'base64'),ext=imageExt(b);if(!ext||b.length>50*1024*1024)throw Error('백업 이미지 형식·크기를 확인해주세요.');image=randomBytes(16).toString('hex')+'.'+ext;fs.writeFileSync(path.join(data,'images',image),b);}
          const site=sites.save(input.site,input.revision,image);broadcast(room.id,{type:'site',site:publicSite(site,id)});return json(res,200,publicSite(site,id));
        }catch(e){return json(res,400,{error:e.message});}
      }
      if(url.pathname.startsWith('/api/works/network/')){
        const action=url.pathname.slice('/api/works/network/'.length);
        if(!(['start','select','stop'].includes(action)&&req.method==='POST')&&!(action==='status'&&req.method==='GET'))return json(res,404,{error:'지원하지 않는 요청입니다.'});
        const changing=action!=='status';if(changing&&worksConfiguring)return json(res,409,{error:'이전 연결 설정이 끝난 뒤 다시 시도해주세요.'});if(changing)worksConfiguring=true;
        try{
          const input=action==='status'?null:await bodyJSON(req);
          if(action==='start'||action==='stop')worksAutomatic={roomId:null,enabled:false,lastGeneration:0,message:'',totals:{added:0,updated:0}};
          if(action==='select'){
            if(typeof input.autoApply!=='boolean')throw Error('자동 반영 여부를 확인해주세요.');
            worksAutomatic={roomId:id,enabled:false,lastGeneration:0,message:'',totals:{added:0,updated:0}};
          }
          const status=await helperNetwork(action,input);
          if(action==='select'){
            worksAutomatic={roomId:id,enabled:input.autoApply,lastGeneration:0,message:input.autoApply?'자동 반영을 시작합니다.':'원문 미리보기만 갱신합니다.',totals:{added:0,updated:0}};await refreshAutomatic();
          }
          return json(res,200,{...status,automaticApply:worksAutomatic.roomId===id?worksAutomatic:{enabled:false,message:worksAutomatic.roomId?'다른 회의에서 자동 반영 중입니다.':'자동 반영 안 함'}});
        }catch(e){return json(res,400,{error:e.message});}finally{if(changing)worksConfiguring=false;}
      }
      if(req.method==='GET'&&url.pathname==='/api/works/status')return json(res,200,{ready:Boolean(worksHelper)});
      if(req.method==='POST'&&url.pathname==='/api/works/open'){
        if(!worksHelper)return json(res,503,{error:'연동 실행기를 사용할 수 없습니다. Start-MouseOn으로 다시 실행해주세요.'});
        try{const input=await bodyJSON(req);const r=await fetch(worksHelper.origin+'/open',{method:'POST',headers:{'X-Probe-Key':worksHelper.key,'Content-Type':'application/json'},body:JSON.stringify({browser:input.browser}),signal:AbortSignal.timeout(25000)});return json(res,r.status,await r.json());}catch{return json(res,502,{error:'연동 브라우저 실행에 실패했습니다.'});}
      }
      if(req.method==='POST'&&['/api/works/diagnostic-start','/api/works/diagnostic-read'].includes(url.pathname)){
        if(!worksHelper)return json(res,503,{error:'Start-MouseOn 실행기로 다시 실행해주세요. 연동 브라우저가 필요합니다.'});
        try{const input=await bodyJSON(req);const target=url.pathname.endsWith('diagnostic-start')?'/diagnostic-start':'/diagnostic-read';const r=await fetch(worksHelper.origin+target,{method:'POST',headers:{'X-Probe-Key':worksHelper.key,'Content-Type':'application/json'},body:JSON.stringify({includeText:Boolean(input.includeText)}),signal:AbortSignal.timeout(15000)});return json(res,r.status,await r.json());}catch{return json(res,502,{error:'진단 연결에 실패했습니다. 캘린더 창과 영역 지정을 확인해주세요.'});}
      }
      if(req.method==='POST'&&url.pathname==='/api/works/preview'){
        try{const input=await bodyJSON(req);if(!validDate(input.date)||typeof input.calendar!=='string'||input.calendar.length>100)throw Error('날짜·캘린더 이름을 확인해주세요.');
          let result;if(input.demo){result={entries:[{text:'101동 북측 타설',date:input.date,calendar:input.calendar},{text:'야적장 지게차 하역',date:input.date,calendar:input.calendar}],warnings:['실제 수집이 아닌 샘플 원문입니다.']};}
          else {if(!worksHelper)throw Error('연동 실행기로 시작해주세요.');const r=await fetch(worksHelper.origin+'/batch',{method:'POST',headers:{'X-Probe-Key':worksHelper.key,'Content-Type':'application/json'},body:JSON.stringify(input),signal:AbortSignal.timeout(15000)});result=await r.json();if(!r.ok)throw Error(result.error||'수집 실패');}
          const entries=result.entries.map(e=>({...interpret(e,sites.read().regions),sourceId:e.sourceId||null}));return json(res,200,{entries,warnings:result.warnings,engine:'규칙 기반 위치·작업 분류 시험 · AI/전체 동기화 미검증'});
        }catch(e){return json(res,400,{error:e.message});}
      }
      if(req.method==='POST'&&url.pathname==='/api/works/apply'){
        try{const input=await bodyJSON(req);if(!Array.isArray(input.entries)||input.entries.length<1||input.entries.length>200)throw Error('반영할 일정을 확인해주세요.');
          const site=sites.read();let added=0,skipped=0;
          const planned=input.entries.flatMap(entry=>{
            if(typeof entry.original!=='string'||!entry.original.trim()||entry.original.length>1200||!validDate(entry.date)||typeof entry.calendar!=='string'||entry.calendar.length>100)throw Error('원문 형식 오류');
            const candidates=interpretAll({text:entry.original,date:entry.date,calendar:entry.calendar},site.regions);
            const sourceEventKey=createHash('sha256').update(JSON.stringify([entry.calendar,entry.date,entry.sourceId||entry.original])).digest('hex');
            return candidates.map(candidate=>({...candidate,sourceEventKey,sourceKey:candidates.length===1?sourceEventKey:createHash('sha256').update(JSON.stringify([sourceEventKey,candidate.regionId])).digest('hex')}));
          });
          const findOld=t=>room.tasks.find(old=>old.sourceKey===t.sourceKey||old.sourceKey===t.sourceEventKey&&(!old.regionId||old.regionId===t.regionId)||old.sourceEventKey===t.sourceEventKey&&old.regionId===t.regionId);
          const claimed=new Set(),plannedKeys=new Set();let newCount=0;for(const t of planned){if(plannedKeys.has(t.sourceKey))continue;plannedKeys.add(t.sourceKey);const old=findOld(t);if(!old||claimed.has(old.id))newCount++;else claimed.add(old.id);}if(room.tasks.length+newCount>200)throw Error('작업은 최대 200개입니다.');
          for(const t of planned){const old=findOld(t);if(old){
            if(!old.manuallyPlaced&&old.shape==='point'&&(!Number.isFinite(old.x)||!Number.isFinite(old.y))&&Number.isFinite(t.x)&&Number.isFinite(t.y)){const region=site.regions.find(r=>r.id===t.regionId),p=region?regionPoint(region,room.tasks.filter(other=>other.regionId===region.id).length):[t.x,t.y];Object.assign(old,{x:p[0],y:p[1],regionId:t.regionId,reasons:t.reasons,sourceEventKey:t.sourceEventKey});}
            skipped++;continue;
          }if(t.regionId){const region=site.regions.find(r=>r.id===t.regionId);if(region){const point=regionPoint(region,room.tasks.filter(old=>old.regionId===t.regionId).length);t.x=point[0];t.y=point[1];}}room.tasks.push({...t,id:randomBytes(6).toString('hex'),equipment:'웍스 일정',shape:'point',points:[]});added++;}
          room.revision++;save(room);broadcast(id,{type:'state',room,notice:`일정 ${added}개 반영 · 기존 ${skipped}개 유지`});return json(res,200,{added,skipped});
        }catch(e){return json(res,400,{error:e.message});}
      }
      return json(res,404,{error:'지원하지 않는 요청입니다.'});
    }
    const clearInk=url.pathname.match(/^\/api\/rooms\/([a-f0-9]{12})\/ink\/clear$/);
    if(req.method==='POST'&&clearInk){
      if(!isHost(req))return json(res,403,{error:'전체 지우기는 주최자 PC에서만 사용할 수 있습니다.'});
      const room=getRoom(clearInk[1]);if(!room)return json(res,404,{error:'회의를 찾지 못했습니다.'});
      let input;try{input=await bodyJSON(req,2048);}catch{return json(res,400,{error:'지우기 요청을 확인해주세요.'});}const person=typeof input.person==='string'&&input.person.trim()?input.person.trim().slice(0,30):'주최자';
      room.strokes=[];room.pointers=[];room.revision++;save(room);broadcast(room.id,{type:'state',room,notice:person+'님이 그림을 모두 지웠습니다.'});return json(res,200,{ok:true});
    }
    if (req.method === 'GET' && url.pathname === '/api/network') {
      const port=server.address().port;
      const addresses=[...new Set(Object.values(networkInterfaces()).flat().filter(n=>n && n.family==='IPv4' && !n.internal && /^(10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[01])\.)/.test(n.address)).map(n=>'http://'+n.address+':'+port))];
      return json(res,200,{addresses, tunnel});
    }
    if (req.method === 'POST' && url.pathname === '/api/rooms') return json(res, 201, createRoom());
    if (req.method === 'GET' && url.pathname === '/api/qr') {
      const value = url.searchParams.get('url') || '';
      if (value.length > 2048 || !/^https?:\/\//.test(value)) return json(res, 400, { error: '잘못된 참여 주소입니다.' });
      res.writeHead(200, { 'Content-Type': 'image/png' }); return res.end(await QRCode.toBuffer(value, { width: 240, margin: 1 }));
    }
    const upload = url.pathname.match(/^\/api\/rooms\/([a-f0-9]{12})\/image$/);
    if (req.method === 'POST' && upload) {
      const room = getRoom(upload[1]); if (!room) return json(res, 404, { error: '회의를 찾을 수 없습니다.' });
      if (!['top','photo'].includes(url.searchParams.get('kind'))) return json(res, 400, {error:'이미지 종류가 잘못되었습니다.'});
      const chunks = []; let size = 0;
      for await (const chunk of req) {
        size += chunk.length;
        if (size > 50 * 1024 * 1024) { req.resume(); return json(res, 413, {error:'사진은 50MB까지 올릴 수 있습니다.'}); }
        chunks.push(chunk);
      }
      const buffer = Buffer.concat(chunks), ext = imageExt(buffer);
      if (!ext) return json(res, 415, {error:'JPG, PNG, WebP 사진만 지원합니다.'});
      const name = randomBytes(16).toString('hex') + '.' + ext;
      fs.writeFileSync(path.join(data, 'images', name), buffer);
      const image = '/images/' + name + (hostSetup?'?room='+room.id:'');
      if (url.searchParams.get('kind') === 'top') room.topImage = image;
      room.image = image; room.strokes = [];room.pointers=[]; room.revision++; save(room);
      broadcast(room.id, {type:'state', room, notice: url.searchParams.get('kind') === 'top' ? '새 탑뷰가 표시되었습니다.' : '문제 사진이 표시되었습니다.'});
      return json(res, 200, {image});
    }
    if (req.method !== 'GET') return json(res, 405, {error:'지원하지 않는 요청입니다.'});
    let file;
    if (/^\/images\/[a-f0-9]{32}\.(png|jpg|webp)$/.test(url.pathname)) file = path.join(data, url.pathname);
    else if (['/','/app.js','/style.css','/design.css','/sample.svg','/calendar.js','/icons.js','/interpret.js','/region-layout.js','/region-mesh.js','/region-geometry.js','/site-partition.js','/hazards.js','/vendor/polygon-clipping.js','/vendor/polygon-clipping-LICENSE.md','/fonts/NanumGothic-Regular.ttf','/fonts/OFL.txt','/fonts/NotoSansKR-Variable.woff2','/fonts/NotoSansKR-OFL.txt'].includes(url.pathname)) file = path.join(root,'public',url.pathname === '/' ? 'index.html' : url.pathname);
    if (!file || !fs.existsSync(file)) return json(res,404,{error:'찾을 수 없습니다.'});
    const types = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp','.ttf':'font/ttf','.woff2':'font/woff2','.txt':'text/plain; charset=utf-8','.md':'text/plain; charset=utf-8'};
    res.writeHead(200, {'Content-Type':types[path.extname(file)], 'X-Content-Type-Options':'nosniff', 'Cache-Control':'no-cache'});
    fs.createReadStream(file).pipe(res);
  } catch (err) { console.error(err.message); if (!res.headersSent) json(res,500,{error:'요청 처리 중 오류가 발생했습니다.'}); else res.end(); }
});
const wss = new WebSocketServer({server, maxPayload: 64 * 1024});
function broadcast(id, message, except) {
  const value = JSON.stringify(message);
  for (const client of wss.clients) if (client.roomId === id && client !== except && client.readyState === WebSocket.OPEN) client.send(value);
}
const coord = v => typeof v === 'number' && Number.isFinite(v) && v >= 0 && v <= 1;
wss.on('connection', (ws, req) => {
  if(!(hostSetup?gate(new URL(req.url,'http://localhost').searchParams.get('room')):access)?.allowed(req)){ws.close(1008,'회의 비밀번호를 입력해주세요.');return;}
  if(req.headers.origin && ![`http://${req.headers.host}`,`https://${req.headers.host}`].includes(req.headers.origin)){ws.close(1008,'허용되지 않은 요청입니다.');return;}
  const url = new URL(req.url,'http://localhost'), room = getRoom(url.searchParams.get('room'));
  if (!room) { ws.close(1008,'회의를 찾을 수 없습니다.'); return; }
  ws.roomId = room.id; ws.person = (url.searchParams.get('name') || '참여자').slice(0,30); ws.peer = randomBytes(6).toString('hex');ws.inkOwner=createHash('sha256').update(room.id+':'+(drawingCookie(req)||randomBytes(24).toString('hex'))+':'+(/^[a-zA-Z0-9-]{16,64}$/.test(url.searchParams.get('ink')||'')?url.searchParams.get('ink'):ws.peer)).digest('hex');
  const others=[...wss.clients].filter(c=>c!==ws&&c.roomId===room.id);const base=ws.person;let suffix=2;while(others.some(c=>c.person===ws.person))ws.person=base+' '+suffix++;
  const palette=['#d45743','#347dc1','#2e9375','#9759bd','#ba7c20','#c04b90','#54802a','#497a83'];const used=new Set(others.map(c=>c.color));ws.color=palette.find(c=>!used.has(c))||`hsl(${(others.length*137.508)%360},65%,42%)`;
  ws.send(JSON.stringify({type:'state',room,identity:{person:ws.person,color:ws.color,inkOwner:ws.inkOwner}}));
  const count = () => broadcast(room.id,{type:'presence',count:[...wss.clients].filter(c=>c.roomId===room.id && c.readyState===WebSocket.OPEN).length});
  count();broadcast(room.id,{type:'notice',message:ws.person+'님이 참여했습니다.'}); ws.on('close',count);
  ws.on('message', raw => {
    try {
      if(!(hostSetup?gate(new URL(req.url,'http://localhost').searchParams.get('room')):access)?.allowed(req)){ws.close(1008,'참여 인증이 만료되었습니다.');return;}
      const m = JSON.parse(raw);
      if (m.type === 'stroke') {
        if (m.image !== room.image) return;
        if (!Array.isArray(m.points) || m.points.length < 1 || m.points.length > 100 || !m.points.every(p=>Array.isArray(p)&&p.length===2&&p.every(coord))) return;
        if (room.strokes.length >= 3000) return ws.send(JSON.stringify({type:'error',message:'그림이 많습니다. 그림을 지운 뒤 다시 그려주세요.'}));
        if(m.width!==undefined&&(!Number.isFinite(m.width)||m.width<1||m.width>24))return;
        const id=typeof m.id==='string'&&/^[a-zA-Z0-9-]{1,64}$/.test(m.id)?ws.peer+':'+m.id:null;
        
        const stroke = {points:m.points,color:ws.color,person:ws.person,owner:ws.inkOwner,width:m.width||3,id}; room.strokes.push(stroke); save(room);
        return broadcast(room.id,{type:'stroke',stroke,image:room.image},ws);
      }
      let notice;
      if(m.type==='clearOwnInk'){if(m.image!==room.image)return;const kept=room.strokes.filter(stroke=>stroke.owner!==ws.inkOwner);if(kept.length===room.strokes.length)return;room.strokes=kept;room.revision++;save(room);return broadcast(room.id,{type:'state',room,notice:ws.person+'님이 자신의 그림을 지웠습니다.'});}
      if(m.type==='addTask'){
        if(room.tasks.length>=200)return ws.send(JSON.stringify({type:'error',message:'한 회의에 작업은 200개까지 등록할 수 있습니다.'}));
        const t=m.task;
        if(!t||typeof t.title!=='string'||!t.title.trim()||t.title.length>80||!validDate(t.date)||!coord(t.x)||!coord(t.y)||typeof t.equipment!=='string'||t.equipment.length>50||typeof t.detail!=='string'||t.detail.length>180||!['🏗️','🚧','🚜','🚛','📦','🦺','tower','mobile','concrete','mixer','dump','excavator','forklift','other','formwork','rope','hazard'].includes(t.icon))return ws.send(JSON.stringify({type:'error',message:'작업 이름·날짜·위치를 확인해주세요.'}));
        if(!['point','area','route','unloading'].includes(t.shape)||!Array.isArray(t.points)||t.points.length>100||!t.points.every(p=>Array.isArray(p)&&p.length===2&&p.every(coord))||(t.shape==='area'&&t.points.length<3)||(t.shape==='route'&&t.points.length<2))return ws.send(JSON.stringify({type:'error',message:'영역은 3점 이상, 동선은 2점 이상 지정해주세요.'}));
        const extras=t.extras||[];if(!Array.isArray(extras)||extras.length>10||!extras.every(g=>['area','route','unloading','point'].includes(g.shape)&&Array.isArray(g.points)&&g.points.length<=100&&g.points.length>=(g.shape==='area'?3:g.shape==='route'?2:1)&&g.points.every(p=>Array.isArray(p)&&p.length===2&&p.every(coord))))return ws.send(JSON.stringify({type:'error',message:'추가 영역·동선의 경계점을 확인해주세요.'}));
        if(t.attention!==undefined&&(typeof t.attention!=='string'||t.attention.length>300))return;
        const hazard=t.hazardId?(sites.read().hazards||defaultHazards()).find(h=>h.id===t.hazardId):null;if(t.hazardId&&!hazard)return ws.send(JSON.stringify({type:'error',message:'고위험 작업 종류가 변경됐습니다. 다시 선택해주세요.'}));
        room.tasks.push({...(hazard?{hazardId:hazard.id,hazardName:hazard.name,hazardColor:hazard.color,icon:hazard.icon}:{}),extras:extras.map(g=>({shape:g.shape,points:g.points})),reasons:t.attention?.trim()?[t.attention.trim()]:[],id:randomBytes(6).toString('hex'),title:t.title.trim(),detail:t.detail,equipment:t.equipment.trim()||'기타 작업',icon:hazard?.icon||t.icon,date:t.date,x:t.x,y:t.y,shape:t.shape,points:t.points});
        notice=`${ws.person}님이 작업을 등록했습니다.`;
      } else if(m.type==='deleteTask'){
        const index=room.tasks.findIndex(t=>t.id===m.id);if(index<0)return;
        room.tasks.splice(index,1);notice=`${ws.person}님이 작업을 삭제했습니다.`;
      } else if (m.type === 'move' && coord(m.x) && coord(m.y)) {
        const task = room.tasks.find(t=>t.id===m.id); if (!task || room.image !== room.topImage) return;
        if(task.shape==='area'&&task.points?.length){const xs=task.points.map(p=>p[0]),ys=task.points.map(p=>p[1]),cx=(Math.min(...xs)+Math.max(...xs))/2,cy=(Math.min(...ys)+Math.max(...ys))/2,dx=Math.max(-Math.min(...xs),Math.min(1-Math.max(...xs),m.x-cx)),dy=Math.max(-Math.min(...ys),Math.min(1-Math.max(...ys),m.y-cy));task.points=task.points.map(([x,y])=>[x+dx,y+dy]);task.x=cx+dx;task.y=cy+dy;}else{task.x=m.x;task.y=m.y;}task.manuallyPlaced=true;if(m.regionId&&sites.read().regions.some(r=>r.id===m.regionId)){task.regionId=m.regionId;task.reasons=(task.reasons||[]).filter(s=>!s.includes('찾지 못')&&!s.includes('여러 영역'));} notice=`${ws.person}님이 작업 위치를 옮겼습니다.`;
      } else if (m.type === 'reorder') {
        if (m.revision !== room.revision) return ws.send(JSON.stringify({type:'state',room,notice:'다른 변경이 먼저 반영되었습니다. 최신 목록에서 다시 변경해주세요.'}));
        const task = room.tasks.find(t=>t.id===m.id); if (!task || isTower(task) || ![-1,1].includes(m.direction)) return;
        const indexes = room.tasks.map((t,i)=>t.equipment===task.equipment?i:-1).filter(i=>i>=0);
        const pos = indexes.indexOf(room.tasks.indexOf(task)), other = indexes[pos+m.direction]; if (other===undefined) return;
        const current = indexes[pos]; [room.tasks[current],room.tasks[other]]=[room.tasks[other],room.tasks[current]];
        notice=`${ws.person}님이 ${task.equipment} 작업 순서를 변경했습니다.`;
      } else if (m.type === 'top') { room.image=room.topImage; room.strokes=[];room.pointers=[]; notice='현장 탑뷰로 돌아왔습니다.';
      } else return;
      room.revision++; save(room); broadcast(room.id,{type:'state',room,notice});
    } catch { ws.send(JSON.stringify({type:'error',message:'변경을 처리하지 못했습니다.'})); }
  });
});
server.on('error', error => { console.error(error.code==='EADDRINUSE' ? 'Port already in use. Close the other MouseOn window and try again.' : error.message); wss.close(); process.exitCode=1; });
server.listen(Number(process.env.PORT || 3000), '0.0.0.0', () => { console.log('MouseOn server listening on port ' + server.address().port);process.send?.({type:'ready',port:server.address().port}); });
